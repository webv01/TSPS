module.exports = {
    devServer: {
        host: '127.0.0.1',
        port: 8999, //  端口号的配置
        open: true, // 自动打开浏览器

        // proxy: {
        //     '/': {
        //         target: 'http://127.0.0.1:8000',
        //         changOrigin: true,

        //     }
        // }
    }
}