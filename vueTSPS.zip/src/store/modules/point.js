export default {

    state: {

        //属性

        pointValue: '',
        point_id: '',

    },

    getters: {

        getpointValue: state => state.pointValue,
        getpointid: state => state.point_id

    },

    mutations: {

        //set方法

        setpointValue(state, demoValue) {

            state.pointValue = demoValue
            console.log("value:" + state.pointValue)

        },
        setpointid(state, demoValue) {

            state.point_id = demoValue
            console.log("point:" + state.point_id)

        }

    }

}