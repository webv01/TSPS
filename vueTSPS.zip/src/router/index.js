import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '@/views/Home/index'
import Dataview from '@/components/Data_view/index'
import HomePage from '@/components/HomePage/index'
import Hot from '@/ST/flow'
import User from '@/components/User/index'
import LoginPage from '@/components/Login/index'
import rounting from '@/components/Rounting/index'
import getPath from '@/components/Rounting/getPath'
import TrackPlay from '@/components/TrackPlay/index'
import Nyc_taxi from '@/components/Nyc/index'
import showline from '@/components/Nyc/showline'
import beijing from '@/components/Nyc/beijing'
import xingcheng1 from '@/Map/xingcheng1.2'
import xingcheng from '@/Map/cuijyan'
import Mark from '@/Map/Mark'
import datatest from '@/components/User/data_time'
// import test from '@/ST/flow_components/ex_data'
import test from '@/ST/show'
import Information from '@/ST/Information'
Vue.use(VueRouter)

const routes = [{
        path: '/Home',
        component: Home,
        children: [{
                path: '/HomePage',
                component: HomePage
            }, {
                path: '/Hot',
                component: Hot
            }, {
                path: '/data',
                component: Dataview
            }, {
                path: '/user',
                component: User,
            },
            { path: '/road', component: rounting }, {
                path: '/Information',
                component: Information,
            },
            {
                path: '/TrackPlay',
                component: TrackPlay,
            },
            {
                path: '/Nyc_taxi',
                component: Nyc_taxi,
            },
            {
                path: '/showline',
                component: showline,
            },
            {
                path: '/beijing',
                component: beijing,
            },
            {
                path: '/xingcheng',
                component: xingcheng,
            }, {
                path: '/xingcheng1',
                component: xingcheng1,
            },
            {
                path: '/datatest',
                component: datatest,
            },
            {
                path: '/datatest',
                component: datatest,
            }, {
                path: '/mark',
                component: Mark,
            }, {
                path: '/test',
                component: test,
            },
        ]
    },

    {
        path: '/',
        component: LoginPage,
    },




]

const router = new VueRouter({
    mode: 'history',
    routes
})

export default router