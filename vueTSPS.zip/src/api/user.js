import qs from "qs";
import axios from 'axios'

export default {
    /*
     *登入接口
     */
    async userlogin(username, password, valide_code) {
        console.log(valide_code)
        var param = qs.stringify({
            username: username,
            password: password,
            valide_code: valide_code
        });
        console.log("asdf")
        return await axios.post("http://127.0.0.1:8000/api/login", param)
    },
    /**
     * 注册接口
     */
    async userregister(username, password) {
        var param = qs.stringify({
            username: username,
            password: password,
        });
        return await axios.post("http://127.0.0.1:8000/api/register", param)
    }
}