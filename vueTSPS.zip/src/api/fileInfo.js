//api中fileInfo.js文件
export function uploadFile(data) {
    return request({
        url: '/test/uploadFile',
        method: 'post',
        data
    })
}

export function downLoad(query) {
    return request({
        url: '/test/downFile',
        method: 'get',
        params: query
    })
}