<template>
  <div>
    <div id="map">
      <!-- Popup -->

      <div id="popup" class="ol-popup" ref="popup" v-show="show">
        <a href="#" id="popup-closer" class="ol-popup-closer"></a>
        <pre1></pre1>

        <div id="popup-content"></div>


      </div>

    </div>


 
   
  </div>
</template>
<script>
import hot from "@/ST/draw/hot";
import pre1 from "@/ST/draw/pre";
import line2 from "@/components/Echarts/line_copy";
import plate from "@/components/Echarts/Plate";
import axios from "axios";
import "ol/ol.css";
import qs from "qs";
import Map from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import TileWMS from "ol/source/TileWMS";
import OSM from "ol/source/OSM";
import ol from "../utils/ol5/ol";
import { Icon, Stroke, Style, Circle, Fill, Text } from "ol/style";
import proj4 from "proj4";
export default {
  components: { hot, line2, plate, pre1 },
  data() {
    return {
      radio: 1,
      selct_point_input1: 123,
      selct_point_input2: 123,
      selct_point_input3: 123,
      radio_show_1: true,
      radio_show_2: false,
      dialogTableVisible: false,
      selct_point: [
        {
          ID: "",
          LOC: "",
        },
        {
          ID: "",
          LOC: "",
        },
      ],
      gridData: [
        {
          ID: "769403",
          LOC: "-118.311178, 34.151224",
        },
        {
          ID: "767542",
          LOC: "-118.25932, 34.20584",
        },
        {
          ID: "737529",
          LOC: "-118.28795, 34.15497",
        },
        {
          ID: "773869",
          LOC: "-118.28186, 34.12121",
        },
      ],
      show: false,

      muli_show: false,
      map: {},
      data: {},
      popupDeviceInfo: {},
      search_input: "",
      center: [-121.87806599999999, 37.303359],
    };
  },
  watch: {
    radio(newVal, oldVal) {
      // 监听 radio 变化

      // 在这里可以根据选中的值执行相应的操作
      if (newVal === "1") {
        this.radio_show_1 = true;
        this.radio_show_2 = false;
        // 执行流量查询操作
      } else if (newVal === "2") {
        this.radio_show_1 = false;
        this.radio_show_2 = true;
        // 执行距离操作
      }
    },
  },
  mounted() {
    this.initMap();
    this.getData();
  },
  methods: {
    clean() {
      (this.selct_point = [
        {
          ID: "",
          LOC: "",
        },
        {
          ID: "",
          LOC: "",
        },
      ]),
        (this.selct_point_input1 = ""),
        (this.selct_point_input2 = ""),
        (this.selct_point_input3 = "");
    },
    // send(){
    //     this.selct_point_input3=  this.selct_point_input1-this.selct_point_input2
    // },
    async send() {
      var param = qs.stringify({
        source_id: this.selct_point_input1,
        target_id: this.selct_point_input2,
      });

      const { data: ret } = await axios.post(
        "http://127.0.0.1:8000/st/METR_LA_caculate",
        param
      );
      // console.log(ret);
      this.selct_point_input3 = ret.data;
      // return ret
    },
    deal_search_input() {
      // #34.09478,-118.47605
      if (this.search_input != "") {
        let parts = this.search_input.split(",");
        const latitude = parseFloat(parts[0]);
        const longitude = parseFloat(parts[1]);
        this.center = [longitude, latitude];
        // console.log(this.center);
        // 新的视图设置，这里以 EPSG:3857（Spherical Mercator）为例

        let view = this.map.getView();
        view.setZoom(15); // 重新设置地图放大倍数
        view.setCenter([longitude, latitude]); // 重新设置中心点的坐标
        this.map.render();
      }
    },
    initMap() {
      var gaodeMapLayer = new ol.layer.Tile({
        title: "高德地图",
        source: new ol.source.XYZ({
          // url:"http://t4.tianditu.com/DataServer?T=vec_w&tk=4a76fd399e76e3e984e82953755c3410&x={x}&y={y}&l={z}",
          url: 'http://www.google.cn/maps/vt?lyrs=s@189&gl=cn&x={x}&y={y}&z={z}',
          // " https://tile.openstreetmap.org/{z}/{x}/{y}.png",
          wrapX: false,
        }),
      });
      let that = this;
      this.map = new ol.Map({
        layers: [gaodeMapLayer],
        view: new ol.View({
          center: that.center,
          zoom: 10, // 设置初始化时的地图缩放层级
          projection: "EPSG:4326", // 坐标系
        }),
        target: "map", // 地图dom
      });
    },

    async getData() {
      const { data: ret } = await axios.get(
        "http://127.0.0.1:8000/st/BAY_data"
      );
      this.data = [];

      for (var i = 0; i < ret.data.length; i++) {
        var data = {
          id: ret.data[i]["id"],
          geo: ret.data[i]["geo"],

        };
        this.data.push(data);
      }

      this.createMark();
    },
    setInnerText(element, text) {
      if (typeof element.textContent == "string") {
        element.textContent = text;
      } else {
        element.innerText = text;
      }
    },
    addFeatrueInfo(info) {
      var content = document.getElementById("popup-content");

      //新增a元素
      var elementA = document.createElement("a");
      elementA.className = "markerInfo";

      //elementA.innerText = info.att.title;
      this.setInnerText(elementA, "编号：" + info.id);
      // 新建的div元素添加a子节点
      content.appendChild(elementA);
      //新增div元素
      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      //elementDiv.innerText = info.att.text;
      this.setInnerText(
        elementDiv,
        "地点： (" + info.latitude + "," + info.longitude + ")"
      );
      // 为content添加div子节点
      content.appendChild(elementDiv);
    },
    createMark() {
      var features = new Array();
      for (var i = 0; i < this.data.length; i++) {
        let Ary = new ol.Feature({
          id: this.data[i].id,
          geometry: new ol.geom.Point(this.data[i].geo),

        });
        features.push(Ary);
      }

      // 矢量要素数据源
      var source = new ol.source.Vector({
        features: features,
      });

      // 聚合标注数据源
      var clusterSource = new ol.source.Cluster({
        distance: 0, //这个是通过 distance 来控制两个点聚合的间距
        source: source,
      });
      // 加载聚合标注的矢量图层
      var styleCache = {}; //用于保存特定数量的聚合群的要素样式
      var clusters = new ol.layer.Vector({
        source: clusterSource,
        style: function (feature, resolution) {
          var size = feature.get("features").length;
          var style = styleCache[size];
          style = [
                new ol.style.Style({
                  image: new Icon({
                    anchor: [0.3, 0.5], // 图标中心
                    src: require("./icon/位置 (2).png"),
                    scale: 0.08,

                    rotateWithView: true,
                  }),
                  text: new ol.style.Text({
                    font: "20px Calibri,sans-serif",
                    // text: size.toString(),
                    fill: new ol.style.Fill({
                      color: "#1e1e1e",
                      border: 50,
                      width: 10,
                    }),
                  }),
                }),
              ];
          return style;
        },
      });

      this.map.addLayer(clusters);
      // 弹窗
      this.map.on("singleclick", (e) => {
        let elPopup = this.$refs.popup;
        let mult_popup = this.$refs.muli_popup;

        let feature = this.map.forEachFeatureAtPixel(
          e.pixel,
          (feature) => feature
        );
        if (feature) {
          let coordinates = feature.getGeometry().getCoordinates();
          if (feature.getProperties().features.length == 1) {
            var popup = new ol.Overlay({
              element: elPopup,
              positioning: "bottom-center",
              stopEvent: false,
              // 信息框的上下位置
              offset: [0, 30],
            });

            this.map.addOverlay(popup);

            setTimeout(() => {
              var content = document.getElementById("popup-content");
              content.innerHTML = "";
              this.muli_show = false;
              this.show = true;
              //在popup中加载当前要素的具体信息
              this.addFeatrueInfo(feature.getProperties().features[0].values_);
              if (this.selct_point[0]["LOC"] != "") {
                if (this.selct_point[1]["LOC"] == "") {
                  (this.selct_point[1]["LOC"] =
                    feature.getProperties().features[0].values_.latitude +
                    "," +
                    feature.getProperties().features[0].values_.longitude),
                    (this.selct_point[1]["ID"] =
                      feature.getProperties().features[0].values_.sensor_id);
                  this.selct_point_input2 = this.selct_point[1]["ID"];
                }
              } else {
                (this.selct_point[0]["LOC"] =
                  feature.getProperties().features[0].values_.latitude +
                  "," +
                  feature.getProperties().features[0].values_.longitude),
                  (this.selct_point[0]["ID"] =
                    feature.getProperties().features[0].values_.sensor_id),
                  (this.selct_point_input1 = this.selct_point[0]["ID"]);
              }

              this.$store.commit(
                "setpointValue",
                feature.getProperties().features[0].values_.flow_pre
              );

              this.$store.commit(
                "setpointid",
                feature.getProperties().features[0].values_.sensor_id
              );

              popup.setPosition(coordinates);
            }, 0);

            console.log(this.show);
            // console.log(feature.getProperties().features[0].values_);
          } else {
            //有多个要素
            var mul_popup = new ol.Overlay({
              element: mult_popup,
              positioning: "bottom-center",
              stopEvent: false,
              // 信息框的上下位置
              offset: [0, 30],
            });
            this.map.addOverlay(mul_popup);
            var content = document.getElementById("popup-content_juhe");

            content.innerHTML =
              "多标记聚合！ 拥有" +
              feature.getProperties().features.length +
              "个传感器";
            this.show = false;
            this.muli_show = true;

            mul_popup.setPosition(coordinates);
          }
        }
      });
      let that = this;
      var closer = document.getElementById("popup-closer");

      var muli_closer = document.getElementById("muli_popup-closer");
      closer.onclick = function () {
        console.log("关闭");
        that.muli_show = false;
        that.show = false;

        return false;
      };
      muli_closer.onclick = function () {
        console.log("关闭");
        that.muli_show = false;
        that.show = false;

        return false;
      };
    },
  },
};
</script>

<style lang="less" scoped>
#mapCon {
  width: 100%;
  height: 95%;
  // position: absolute;
}

.ol-popup {
  // position: absolute;
  background-color: white;
  -webkit-filter: drop-shadow(0 1px 4px rgba(0, 0, 0, 0.2));
  filter: drop-shadow(0 1px 4px rgba(0, 0, 0, 0.2));
  padding: 15px;
  border-radius: 10px;
  border: 1px solid #cccccc;
  bottom: 45px;
  left: -50px;
}

.ol-popup:after,
.ol-popup:before {
  top: 100%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  // position: absolute;
  pointer-events: none;
}

.ol-popup:after {
  border-top-color: white;
  border-width: 10px;
  left: 48px;
  margin-left: -10px;
}

.ol-popup:before {
  border-top-color: #cccccc;
  border-width: 11px;
  left: 48px;
  margin-left: -11px;
}

.ol-popup-closer {
  text-decoration: none;
  position: absolute;
  top: 2px;
  right: 8px;
}

.ol-popup-closer:after {
  content: "✖";
}

#popup-content {
  font-size: 14px;
  font-family: "微软雅黑";
  width: 300px;
}
#popup-content_juhe {
  height: 100px;
  font-size: 14px;
  font-family: "微软雅黑";
  width: 300px;
}
#popup-content .markerInfo {
  font-weight: bold;
}

#title {
  border-radius: 10px;
  top: 10%;
  left: 1%;
  bottom: 3%;
  position: absolute;
  float: left;
  font-size: 30px;
  width: 50%;
  background-color: rgb(255, 255, 255);
  height: 9%;
  text-align: center;
}
#title2 {
  top: 10%;
  left: 2%;
  bottom: 3%;
  position: absolute;
  float: left;
  font-size: 30px;
  width: 19%;
  background-color: #fff;
  height: 85%;
  text-align: center;
}
#title3 {
  top: 10%;
  right: 2%;
  bottom: 3%;
  position: absolute;
  float: left;
  font-size: 30px;
  width: 19%;
  background-color: #fff;
  height: 85%;
  text-align: center;
}
.quarter-div-hen4 {
  position: relative;
  width: 100%;
  height: 100%;

  float: left;
  top: 15px;
}
.quarter-shu2 {
  position: relative;
  width: 100%;
  height: 50%;

  float: left;
}
.quarter-hen4 {
  position: relative;
  width: 25%;
  height: 100%;

  float: left;
}
.txt_item {
  font-size: 14px;
  font-family: "微软雅黑";
  // width: 200px;
}
</style>