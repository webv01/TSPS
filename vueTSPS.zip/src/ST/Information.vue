
<template>
  <div class="mainbox" style="background: #004368">
      <el-table
      
      :data="tableData"
      style="width: 100%; height: 80%; background: #004368; color: white"
      align-center>
      <el-table-column
        prop="name"
        label="文件"
        style="width: 20%"
        align-center>
      </el-table-column>
      <el-table-column
        prop="date"
        label="日期"
        style="width: 20%">
      </el-table-column>
      <el-table-column
      @click="download"
        prop="address"
        label="描述">
      </el-table-column>
       <el-table-column
      fixed="right"
      label="操作"
      width="100">
      <template slot-scope="scope">
        <el-button @click="handleClick(scope.row.tpye)" type="text">下载</el-button>
        <!-- <el-button type="text" size="small">编辑</el-button> -->
      </template>
    </el-table-column>
       <!-- <el-button type="primary" @click="download">下载文档</el-button>  -->
       <!-- <el-button type="primary" @click="download">下载文档</el-button> -->
    </el-table>
      
      
      <!-- <div>
    <el-button type="primary" @click="download">下载文档</el-button>
    <el-divider></el-divider>
    <span>少量的邪恶足以抵消全部高贵的品质, 害得人声名狼藉</span>
  </div> -->
  </div>
</template>
 <script>
import qs from "qs";
import axios from 'axios';

export default {
  data() {
    return {
      tableData: [{
            date: '2024-05-25',
            name: '作者简历',
            address: '系统开发者简介，快来下载',
            tpye:'file.pdf'
          }, {
            date: '2024-05-05',
            name: '系统操作手册',
            address: '系统功能与使用说明，快来下载',
            tpye:'file.pdf'
          }, 
        //   {
        //     date: '2016-05-01',
        //     name: '王小虎',
        //     address: '上海市普陀区金沙江路 1519 弄',
        //     tpye:'file.pdf'
        //   }, {
        //     date: '2016-05-03',
        //     name: '王小虎',
        //     address: '上海市普陀区金沙江路 1516 弄',
        //     tpye:'file.pdf'
        //   }
          ]
    };
  },
  mounted() {

  },
  methods: {
     handleClick(row) {
        this.download(row);
      },
   
    download(row){
	axios(row,{
		responseType: 'blob', //重要代码
	}).then(res =>{
		const url = window.URL.createObjectURL(new Blob([res.data]));
		const link = document.createElement('a');
        link.href = url;
        let fileName = row //保存到本地的文件名称
        link.setAttribute('download', fileName);
        document.body.appendChild(link);
        link.click();
	})
},

  },
};
</script>

<style lang="less" scoped>
#mainbox {
  display: flex;

  position: absolute;
  top: 10%;
  height: 100%;
  width: 100%;
}
.left_contain {
  flex: 2;
}
.right_contain_data {
  flex: 8;
}
/deep/.el-table thead tr > th {
  background: #004368;
//   color: rgb(255, 255, 255);
}
// 更改表格每行背景颜色
/deep/.el-table tbody tr > td {
  background: #004368;
//   color: rgb(255, 255, 255);
}
// 设置鼠标经过时背景颜色
/deep/.el-table tbody tr:hover > td {
  background-color: #013d57 !important;
}
/deep/.el-tree tbody tr > td {
  background-color: #013d57 !important;
}
/* 改变被点击节点背景颜色，字体颜色 */
/deep/.el-tree-node:focus > .el-tree-node__content {
  background-color: #266c8a !important;
  // color: rgb(180, 55, 55) !important;
}
/*节点失焦时的背景颜色*/
/deep/.el-tree--highlight-current
  .el-tree-node.is-current
  > .el-tree-node__content {
  background-color: #4a9de7 !important;
  color: rgb(41, 7, 7) !important;
}
/deep/.el-tree-node__content {
  &:hover {
    background-color: #266c8a !important;
  }
}

</style>



