import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import axios from 'axios'
import api from "./api/index"
import VueSession from 'vue-session'
Vue.use(VueSession)

import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
Vue.use(ElementUI);


//WebSocket封装方法
import * as socketApi from './api/socket'
Vue.prototype.socketApi = socketApi



Vue.config.productionTip = false
    // 引入全局的样式文件 
import './assets/css/global.less'

// 将全局的echarts对象挂载到Vue的原型对象上
// 别的组件中 this.$echarts
// axios.defaults.baseURL = 'http://localhost:8000/'
Vue.prototype.$echarts = window.echarts
    // 将axios挂载到Vue的原型对象上
axios.defaults.withCredentials = true;
// 在别的组件中 this.$http
Vue.prototype.$http = axios
    // 将api接口挂载到全局中
Vue.prototype.$api = api
import Katex from 'vue-katex-auto-render'
Vue.directive('katex', Katex);


import VueCookies from 'vue-cookies'
Vue.use(VueCookies)
new Vue({
    router,
    store,
    render: h => h(App)
}).$mount('#app')