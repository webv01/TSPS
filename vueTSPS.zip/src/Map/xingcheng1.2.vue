<template>
  <div>
    <div id="mapCon">
      <!-- Popup -->
      <div id="popup" class="ol-popup" ref="popup" v-show="show">
        <a href="#" id="popup-closer" class="ol-popup-closer"></a>
        <div id="popup-content"></div>
      </div>
    </div>
    <div id="title">
      <div class="quarter-div">
        <div class="quarter-div" >
          <img :src="url1" alt="" />
        </div>
        <div class="quarter-div" style="top: 30px;text-align: center;right:25px;  font-size: 24px;">GPS轨迹A </div>
      </div>

      <div class="quarter-div">
     
      </div>
        <div class="quarter-div">
        <div class="quarter-div" style="">
          <img :src="url2" alt="" />
        </div>
      <div class="quarter-div" style="top: 30px;text-align: center;right:25px;  font-size: 24px;">真实轨迹A </div>
      </div>
      <div class="quarter-div">

      </div>
        <div class="quarter-div">
        <div class="quarter-div" style="">
          <img :src="url3" alt="" />
        </div>
      <div class="quarter-div" style="top: 30px;text-align: center;right:25px;  font-size: 24px;">GPS轨迹B </div>
      </div>
      <div class="quarter-div">
 
      </div>
       <div class="quarter-div">
        <div class="quarter-div" style="">
          <img :src="url4" alt="" />
        </div>
      <div class="quarter-div" style="top: 30px;text-align: center;right:25px;  font-size: 24px;">真实轨迹B</div>
      </div>
    </div>
  </div>
</template>
<script>
import "ol/ol.css";
import Map from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import TileWMS from "ol/source/TileWMS";
import XYZ from "ol/source/XYZ";
import OSM from "ol/source/OSM";
import ol from "../utils/ol5/ol";
import { Icon, Stroke, Style, Circle, Fill, Text } from "ol/style";

import proj4 from "proj4";
import LineString from "ol/geom/LineString";

export default {
  name: "",

  data() {
    return {
      show: false,
      map: {},
      data: [],
      url1: require("./img/84-虚线 (1).png"),
      url2: require("./img/直线.png"),
      url3: require("./img/84-虚线.png"),
      url4: require("./img/直线 (1).png"),
    };
  },
  mounted() {
    this.initMap();
  },
  methods: {
    initMap() {
      var gaodeMapLayer = new ol.layer.Tile({
        title: "高德地图",
        source: new ol.source.XYZ({
          url: " https://tile.openstreetmap.org/{z}/{x}/{y}.png",
          wrapX: false,
        }),
      });

      this.map = new ol.Map({
        layers: [gaodeMapLayer],
        view: new ol.View({
          center: [-73.9849368,40.7410196],

          zoom: 15, // 设置初始化时的地图缩放层级
          projection: "EPSG:4326", // 坐标系
        }),
        target: "mapCon", // 地图dom
      });
      // this.setdata();
      this.showPoint();
    },
    showPoint() {
      var features = new Array();
      var routerline1 =
       [
        [-73.98487326,40.74101398],
         [-73.9824980,40.7407313],
        [-73.9791998,40.7384482],
 
    
      ];

    var routerline2 = [
        [-73.9855320,40.7400264],
        [-73.98221922,40.73947562],
        [-73.9810209,40.7381582],
        [-73.9803509,40.7379333],

      ];

      var routerline3 = [
        [-73.9824980,40.7407313],
        [-73.98150429,40.73957005],
        [-73.9791998,40.7384482],
      ];
      var routerline4 = [
        [-73.98150429,40.73957005],
        [-73.9810209,40.7381582],
 
      ];

    var routerline5 =
       [[-73.9810209,40.7381582],
        [-73.98006598,40.73942054]
         
        
    
      ];
          var routerline6 =
       [         [-73.9824980,40.7407313],
       [-73.98006598,40.73942054],
        [-73.9791998,40.7384482],
         
        
    
      ];
      var i = 0;
      
      for (var i = 0; i < routerline1.length; i++) {
        var coordinate = routerline1[i];

        var newDataObject = {
          geo: coordinate,
          point_location: "A" ,
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "Sensor " + String.fromCharCode(65 + i),
        };

        this.data.push(newDataObject);
      }      for (var i = 0; i < routerline2.length; i++) {
        var coordinate = routerline2[i];

        var newDataObject = {
          geo: coordinate,
          point_location: "A" ,
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "Sensor " + String.fromCharCode(65 + i),
        };

        this.data.push(newDataObject);
      }for (var i = 0; i < routerline3.length; i++) {
        var coordinate = routerline3[i];

        var newDataObject = {
          geo: coordinate,
          point_location: "A" ,
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "Sensor " + String.fromCharCode(65 + i),
        };

        this.data.push(newDataObject);
      }
     
       var newDataObject = {
          geo: [-73.98006598,40.73942054],
          point_location: "A2" ,
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "Sensor " + String.fromCharCode(65 + i),
        };

        this.data.push(newDataObject);
           var newDataObject = {
          geo:  [-73.98150429,40.73957005],
          point_location: "A3" ,
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "Sensor " + String.fromCharCode(65 + i),
        };

        this.data.push(newDataObject);       
        var newDataObject = {
          geo:  [-73.9810209,40.7381582],
          point_location: "A4" ,
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "Sensor " + String.fromCharCode(65 + i),
        };

        this.data.push(newDataObject);    
   
      this.createMark();
      var routeFeature = new ol.Feature({
        type: "route1",
        geometry: new ol.geom.LineString(routerline1),
      });
      var routeFeature1 = new ol.Feature({
        type: "route2",
        geometry: new ol.geom.LineString(routerline2),
      });
      var routeFeature2 = new ol.Feature({
        type: "route3",
        geometry: new ol.geom.LineString(routerline3),
      });
      var routeFeature3 = new ol.Feature({
        type: "route4",
        geometry: new ol.geom.LineString(routerline4),
      });
      var routeFeature4 = new ol.Feature({
        type: "route5",
        geometry: new ol.geom.LineString(routerline5),
      });
       var routeFeature5 = new ol.Feature({
        type: "route6",
        geometry: new ol.geom.LineString(routerline6),
      });
      var startMarker = new ol.Feature({
        type: "iconStart",
        geometry: new ol.geom.Point(routerline2[0]),
      });

      var source = new ol.source.Vector({
        features: [
          routeFeature,
          startMarker,
          routeFeature1,
          routeFeature2,
          routeFeature3,
          routeFeature4,routeFeature5
        ],
      });
      var styles = {
        route1: new Style({
          stroke: new Stroke({
            width: 7,
            color: "#FFA500",
            // "#dd7f1b",
          }),
        }),
        route2: new Style({
          stroke: new Stroke({
            width: 7,
            color: "#5c4086",
          }),
        }),
        route3: new Style({
          stroke: new Stroke({
            width: 5,
            color: "#3b388d",
            lineDash: [15,15, 15, 15],
          }),
        }),
        route4: new Style({
          stroke: new Stroke({
            width: 5,
            color: "#3b388d",
    
        
          }),
        }),route5: new Style({
          stroke: new Stroke({
            width: 5,
            color: "#478b51",
            
        
          }),
        }),route6: new Style({
          stroke: new Stroke({
            width: 5,
            color: "#478b51",
            lineDash: [15,15, 15, 15],
        
          }),
        }),
        iconStart: new Style({
          image: new Icon({
            anchor: [0.5, 0.5], // 图标中心
            src: require("./img/blueIcon.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
        }),
      };
      this.clusters = new ol.layer.Vector({
        source: new ol.source.Vector({
          features: [routeFeature, routeFeature1, routeFeature2, routeFeature3,routeFeature4,routeFeature5],
        }),
        style: function (feature) {
          return styles[feature.get("type")];
        },
      });




 
          this.map.addLayer(this.clusters);
        this.data=[ {
          geo: [-73.98487326,40.74101398] ,
          point_location:"A1" ,
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "A1(Company)" ,
        },{
          geo: [-73.9824980,40.7407313],
          point_location:"A1",
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "A2(Shopping)" ,
        },{
          geo: [-73.9791998,40.7384482],
          point_location: "A1",
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "A3(Gym)" ,
        },{
          geo:  [-73.9855320,40.7400264],
          point_location: "B1",
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "B1(Store)" ,
        },{
          geo: [-73.98221922,40.73947562],
          point_location: "B1",
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "B2(Coffee)" ,
        },{
          geo:  [-73.9803509,40.7379333],
          point_location: "B1",
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "B4(Home)" ,
        }
        
        
        ]



      
      this.createMark2();
    },
    setdata() {
      this.data = [
        {
          geo: [-73.9559225, 40.6513735],
          point_location: "A3",
          point_status_name: "葫芦岛校区",
          point_value: "学校",
          sensor_type_name: "71262",
        },
        {
          geo: [-73.9558701, 40.6513696],
          point_location: "B3",
          point_status_name: "超市、商场。美食、电影院",
          point_value: "景区",
          sensor_type_name: "71265",
        },
        {
          geo: [-73.9504903, 40.6553856],

          point_location: "B2",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
        {
          geo: [-73.95004012, 40.65515705],

          point_location: "A2",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },

        {
          geo: [-73.94733891, 40.65726851],

          point_location: "B1",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
        {
          geo: [-73.94736967, 40.65729141],

          point_location: "A1",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
      ];

      this.createMark();
    },
    setInnerText(element, text) {
      if (typeof element.textContent == "string") {
        element.textContent = text;
      } else {
        element.innerText = text;
      }
    },
    addFeatrueInfo(info) {
      var content = document.getElementById("popup-content");

      //新增a元素
      var elementA = document.createElement("a");
      elementA.className = "markerInfo";

      //elementA.innerText = info.att.title;
      this.setInnerText(elementA, "ID：" + info.name);
      // 新建的div元素添加a子节点
      content.appendChild(elementA);
      //新增div元素
      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      //elementDiv.innerText = info.att.text;
      this.setInnerText(elementDiv, "名称：" + info.pintName);
      // 为content添加div子节点
      content.appendChild(elementDiv);
      //新增div元素
      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      //elementDiv.innerText = info.att.text;
      this.setInnerText(elementDiv, "类别：" + info.value);
      // 为content添加div子节点
      content.appendChild(elementDiv);
      //新增div元素
      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      //elementDiv.innerText = info.att.text;
      this.setInnerText(elementDiv, "描述：" + info.status);
      // 为content添加div子节点
      content.appendChild(elementDiv);
    },
    createMark() {
      var features = new Array();
      for (var i = 0; i < this.data.length; i++) {
        let Ary = new ol.Feature({
          geometry: new ol.geom.Point(this.data[i].geo),

          status: this.data[i].point_status_name,
          name: this.data[i].sensor_type_name,
          value: this.data[i].point_value,
          pintName: this.data[i].point_location,
          type: this.data[i].point_location,
        });

        features.push(Ary);
        // features.push(
        //   new ol.Feature({
        //     geometry: new ol.geom.Point(this.data[i].geo),
        //   })
        // );
      }

      // 矢量要素数据源
      var source = new ol.source.Vector({
        features: features,
      });

      // 聚合标注数据源
      var clusterSource = new ol.source.Cluster({
        distance: 0, //这个是通过 distance 来控制两个点聚合的间距
        source: source,
      }); 
      var styles1 = {
        A1: new Style({
          image: new Circle({
      
        radius: 2,
                  stroke: new Stroke({
                    color: "black",
                  }),
           

         
          }),
          text: new Text({
            //位置
            textAlign: "right",
            //基准线
            textBaseline: "middle",
            //文字样式
            font: "normal 26px 微软雅黑",
            //文本内容
            text: "geometry",
            offsetX: -20,
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        B1: new Style({
          image: new Icon({
            anchor: [0.5, 0.5], // 图标中心
            src: require("./img/blueIcon.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
          text: new Text({
            //位置
            textAlign: "left",
            //基准线
            textBaseline: "bottom",
            font: "normal 26px 微软雅黑",
            //文本内容
            offsetX: 20,
            text: "B1",
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        A2: new Style({
          image: new Icon({
            anchor: [0.5, 0.7], // 图标中心
            src: require("./img/blue.png"),
            scale: 0.2,

            rotateWithView: true,
          }),
          text: new Text({
            //位置
            textAlign: "right",
            //基准线
            textBaseline: "middle",
            //文字样式
            font: "normal 26px 微软雅黑",
            //文本内容
            text: "a1(School)",
            offsetX: -20,
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        B2: new Style({
          image: new Icon({
            anchor: [0.5, 0.7], // 图标中心
            src: require("./img/blue.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
          text: new Text({
            //位置
            textAlign: "right",
            //基准线
            textBaseline: "middle",
            //文字样式
            font: "normal 26px 微软雅黑",
            //文本内容
            text: "  B2",
            offsetX: -20,
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        A3: new Style({
          image: new Icon({
            anchor: [0.5, 0.7], // 图标中心
            src: require("./img/red.png"),
            scale: 0.15,

            rotateWithView: true,
          }),
          text: new Text({
            //位置
            textAlign: "right",
            //基准线
            textBaseline: "middle",
            //文字样式
            font: "normal 26px 微软雅黑",
            //文本内容
            text: "a2(Bank)",
            offsetX: -20,
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        A4: new Style({
          image: new Icon({
            anchor: [0.4, 0.5], // 图标中心
            src: require("./img/ATM.png"),
            scale: 0.15,

            rotateWithView: true,
          }),
          text: new Text({
            //位置
            textAlign: "left",
            //基准线
            textBaseline: "bottom",
            //文字样式
            font: "normal 26px 微软雅黑",
            //文本内容
            offsetX: -50,
            offsetY: 50,
            text: "B3(ATM)",
            
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),A: new Style({
          image: new Circle({
      
        radius: 1,
                  stroke: new Stroke({
                    color: "black",
                  }),
           

         
          }),
    
        }),
      };

      var clusters = new ol.layer.Vector({
        source: source,
        style: (feature) => {
          return styles1[feature.get("type")];
        },

     
        zIndex: 999,
      });

      this.map.addLayer(clusters);
      // 弹窗

      this.map.on("singleclick", (e) => {
        let elPopup = this.$refs.popup;
        var popup = new ol.Overlay({
          element: elPopup,
          positioning: "bottom-center",
          stopEvent: false,
          // 信息框的上下位置
          offset: [0, 30],
        });
        this.map.addOverlay(popup);
        console.log(e.pixel);
        let feature = this.map.forEachFeatureAtPixel(
          e.pixel,
          (feature) => feature
        );
        console.log(feature.values_);
        if (feature) {
          let coordinates = feature.getGeometry().getCoordinates();
          // console.log(coordinates)
          setTimeout(() => {
            var content = document.getElementById("popup-content");
            content.innerHTML = "";
            this.show = true;
            //在popup中加载当前要素的具体信息
            this.addFeatrueInfo(feature.values_);

            popup.setPosition(coordinates);
          }, 0);
        } else {
          this.show = false;
        }
      });
   
    },
  createMark2() {
      var features = new Array();
      for (var i = 0; i < this.data.length; i++) {
        let Ary = new ol.Feature({
          geometry: new ol.geom.Point(this.data[i].geo),

          status: this.data[i].point_status_name,
          name: this.data[i].sensor_type_name,
          value: this.data[i].point_value,
          pintName: this.data[i].point_location,
          type: this.data[i].point_location,
        });

        features.push(Ary);
        // features.push(
        //   new ol.Feature({
        //     geometry: new ol.geom.Point(this.data[i].geo),
        //   })
        // );
      }

      // 矢量要素数据源
      var source = new ol.source.Vector({
        features: features,
      });

      // 聚合标注数据源
      var clusterSource = new ol.source.Cluster({
        distance: 0, //这个是通过 distance 来控制两个点聚合的间距
        source: source,
      }); 
      

      var clusters = new ol.layer.Vector({
        source: source,
       style: (feature) => {
          var text = feature.get("name"); //这个是每个点位对应的id
          var color = "";
          var pintName = feature.get("pintName");
          var AoffsetX=30;
          var AoffsetY=-10;
          if (pintName=='B1'){
              AoffsetX=-20,
               AoffsetY=20
              }

          return new Style({
            image: new Circle({
              radius: 1,
              stroke: new Stroke({
                color: "black",
              }),
              fill: new Fill({
                color: "black",
              }),
              opacity: 0.75,
            }),
            text: new Text({
              //位置
              textAlign: "center",
              //基准线
              textBaseline: "middle",
              //文字样式
              font: "normal 26px 微软雅黑",
              //文本内容
              text: text,
              //文本填充样式（即文字颜色）
              
               offsetX:AoffsetX,
               offsetY:AoffsetY,
              fill: new ol.style.Fill({ color: "black" }),
              stroke: new ol.style.Stroke({ color: "black", width: 1}),
            }),
          });
        },

        // {
        //   var text = feature.get("point_location"); //这个是每个点位对应的id
        //   var color = "";
        //   // mark点的填充颜色判断

        //   color = "#00ff00";

        //   return new Style({
        //     image: new Icon({
        //     anchor: [0.5, 0.5], // 图标中心
        //     src: require("./img/blueIcon.png"),
        //     scale: 0.5,

        //     rotateWithView: true,
        //   }),
        //     text: new Text({
        //       //位置
        //       textAlign: "bottom",
        //       //基准线
        //       textBaseline: "middle",
        //       //文字样式
        //       font: "normal 20px 微软雅黑",
        //       //文本内容
        //        text: feature.get('pintName'),
        //       //文本填充样式（即文字颜色）
        //       fill: new ol.style.Fill({ color: "#000000" }),
        //       stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
        //     }),
        //   });
        // },

        // style: function (feature, resolution) {
        //   var size = feature.get("features").length; //获取该要素所在聚合群的要素数量
        //   var style = styleCache[size];
        //   if (!style) {
        //     style = [
        //       new Style({
        //         image: new Circle({
        //           radius: 10,
        //           stroke: new Stroke({
        //             color: "#fff",
        //           }),
        //           fill: new Fill({
        //             color: "#3399CC",
        //           }),
        //         }),
        //       }),
        //     ];
        //   }
        //   return style;
        // },
        zIndex: 999,
      });

      this.map.addLayer(clusters);
      // 弹窗

      this.map.on("singleclick", (e) => {
        let elPopup = this.$refs.popup;
        var popup = new ol.Overlay({
          element: elPopup,
          positioning: "bottom-center",
          stopEvent: false,
          // 信息框的上下位置
          offset: [0, 30],
        });
        this.map.addOverlay(popup);
        console.log(e.pixel);
        let feature = this.map.forEachFeatureAtPixel(
          e.pixel,
          (feature) => feature
        );
        console.log(feature.values_);
        if (feature) {
          let coordinates = feature.getGeometry().getCoordinates();
          // console.log(coordinates)
          setTimeout(() => {
            var content = document.getElementById("popup-content");
            content.innerHTML = "";
            this.show = true;
            //在popup中加载当前要素的具体信息
            this.addFeatrueInfo(feature.values_);

            popup.setPosition(coordinates);
          }, 0);
        } else {
          this.show = false;
        }
      });
      //   this.map.on("singleclick", (e) => {
      //     let elPopup = this.$refs.popup;
      //     var popup = new ol.Overlay({
      //       element: elPopup,
      //       positioning: "bottom-center",
      //       stopEvent: false,
      //       // 信息框的上下位置
      //       offset: [0, 30],
      //     });
      //     this.map.addOverlay(popup);
      //     console.log(e.pixel)
      //     let feature = this.map.forEachFeatureAtPixel(
      //       e.pixel,
      //       (feature) => feature
      //     );
      //     console.log(feature.values_);
      //     if (feature) {
      //       let coordinates = feature.getGeometry().getCoordinates();
      //       // console.log(coordinates)
      //       setTimeout(() => {
      //         var content = document.getElementById("popup-content");
      //         content.innerHTML = "";
      //         this.show = true;
      //         //在popup中加载当前要素的具体信息
      //         this.addFeatrueInfo(feature.values_);

      //         popup.setPosition(coordinates);
      //       }, 0);
      //     } else {
      //       this.show = false;
      //     }
      //   });
    },
    // 初始化地图
    // initMap() {
    //   this.map = new Map({
    //     layers: [
    //       new TileLayer({
    //     extent: [37467916, 3964896.75, 37478080, 3972216.5],
    //      source: new TileWMS({
    //       url: "http://120.53.249.144:8080/geoserver/wms",
    //       params: { LAYERS: "webgis:cad_polyline" },
    //       serverType: "geoserver",
    //     }),

    //   })
    //     ],
    //     target: "map",
    //     view: new View({
    //        center: [37477916, 3968896.2],
    //        projection: 'EPSG:3857',
    //       zoom: 14,
    //     }),
    //   });
    // },

    addLayer() {
      // 加载 GeoServer 发布的 wms 服务
      let wmsLayer = new TileLayer({
        extent: [
          // 边界
          97.350096, 26.045865, 108.546488, 34.312446,
        ],
        source: new TileWMS({
          //上线后，记得要把url: 'http://localhost:8090/geoserver/ws-world/wms'中的localhost换成云服务器的ip地址！！
          url: "http://120.76.197.111:8090/geoserver/keshan/wms",
          params: { LAYERS: "keshan:sichuan", TILED: true },
          serverType: "geoserver",
        }),
        visible: true,
        zIndex: 2,
      });
      this.map.addLayer(wmsLayer);
    },
  },
};
</script>
<style lang="less" scoped>
#mapCon {
  width: 100%;
  height: 100%;
  position: relative;
  float: left;
}

.quarter-div {
  position: relative;
  width: 50%;
  height: 10%;

  float: left;
  top: 15px;
}

#title {
  top: 30%;
  position: relative;
  float: right;

  width: 25%;
  height: 700px;
  text-align: center;
}
.ol-popup {
  position: absolute;
  background-color: white;
  -webkit-filter: drop-shadow(0 1px 4px rgba(0, 0, 0, 0.2));
  filter: drop-shadow(0 1px 4px rgba(0, 0, 0, 0.2));
  padding: 15px;
  border-radius: 10px;
  border: 1px solid #cccccc;
  bottom: 45px;
  left: -50px;
}

.ol-popup:after,
.ol-popup:before {
  top: 100%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}

.ol-popup:after {
  border-top-color: white;
  border-width: 10px;
  left: 48px;
  margin-left: -10px;
}

.ol-popup:before {
  border-top-color: #cccccc;
  border-width: 11px;
  left: 48px;
  margin-left: -11px;
}

.ol-popup-closer {
  text-decoration: none;
  position: absolute;
  top: 2px;
  right: 8px;
}

.ol-popup-closer:after {
  content: "✖";
}

#popup-content {
  font-size: 14px;
  font-family: "微软雅黑";
  width: 160px;
}

#popup-content .markerInfo {
  font-weight: bold;
}
#popup-content1 {
  font-size: 14px;
  font-family: "微软雅黑";
  width: 300px;
}

#popup-content1 .markerInfo {
  font-weight: bold;
}
</style>