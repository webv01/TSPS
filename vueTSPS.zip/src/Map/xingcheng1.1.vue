<template>
  <div>
    <div id="mapCon">
      <!-- Popup -->
      <div id="popup" class="ol-popup" ref="popup" v-show="show">
        <a href="#" id="popup-closer" class="ol-popup-closer"></a>
        <div id="popup-content"></div>
      </div>
    </div>
       <div id="title">
      <div class="quarter-div">
        <!-- <div class="quarter-div" >
          <img :src="url1" alt="" />
        </div>
        <div class="quarter-div" style="top: 30px;text-align: center;right:25px;  font-size: 25px;">GPS轨迹A </div> -->
      </div>


        <div class="quarter-div">
        <!-- <div class="quarter-div" style="">
          <img :src="url2" alt="" />
        </div>
      <div class="quarter-div" style="top: 30px;text-align: center;right:25px;  font-size: 25px;">真实轨迹A </div> -->
      </div>
      <!-- <div class="quarter-div">

      </div> -->
        <div class="quarter-div">
        <!-- <div class="quarter-div" style="">
          <img :src="url3" alt="" />
        </div>
      <div class="quarter-div" style="top: 30px;text-align: center;right:25px;  font-size: 25px;">GPS轨迹B </div> -->
      </div>
      <!-- <div class="quarter-div">
 
      </div> -->
       <div class="quarter-div">
        <!-- <div class="quarter-div" style="">
          <img :src="url4" alt="" />
        </div>
      <div class="quarter-div" style="top: 30px;text-align: center;right:25px;  font-size: 25px;">真实轨迹B</div> -->
      </div>
    </div> 
    <!-- <div id="title">
      <div class="quarter-div">
        <div class="quarter-div" >
          <img :src="url1" alt="" />
        </div>
        <div class="quarter-div" style="top: 30px;text-align: center;right:25px;  font-size: 25px;">GPS轨迹A </div>
      </div>

      <div class="quarter-div">
     
      </div>
        <div class="quarter-div">
        <div class="quarter-div" style="">
          <img :src="url2" alt="" />
        </div>
      <div class="quarter-div" style="top: 30px;text-align: center;right:25px;  font-size: 25px;">真实轨迹A </div>
      </div>
      <div class="quarter-div">

      </div>
        <div class="quarter-div">
        <div class="quarter-div" style="">
          <img :src="url3" alt="" />
        </div>
      <div class="quarter-div" style="top: 30px;text-align: center;right:25px;  font-size: 25px;">GPS轨迹B </div>
      </div>
      <div class="quarter-div">
 
      </div>
       <div class="quarter-div">
        <div class="quarter-div" style="">
          <img :src="url4" alt="" />
        </div>
      <div class="quarter-div" style="top: 30px;text-align: center;right:25px;  font-size: 25px;">真实轨迹B</div>
      </div>
    </div> -->
  </div>
</template>
<script>
import "ol/ol.css";
import Map from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import TileWMS from "ol/source/TileWMS";
import XYZ from "ol/source/XYZ";
import OSM from "ol/source/OSM";
import ol from "../utils/ol5/ol";
import { Icon, Stroke, Style, Circle, Fill, Text } from "ol/style";

import proj4 from "proj4";
import LineString from "ol/geom/LineString";

export default {
  name: "",

  data() {
    return {
      show: false,
      map: {},
      data: [],
      url1: require("./img/84-虚线 (1).png"),
      url2: require("./img/直线.png"),
      url3: require("./img/84-虚线.png"),
      url4: require("./img/直线 (1).png"),
    };
  },
  mounted() {
    this.initMap();
  },
  methods: {
    initMap() {
      var gaodeMapLayer = new ol.layer.Tile({
        title: "高德地图",
        source: new ol.source.XYZ({
          url: " https://tile.openstreetmap.org/{z}/{x}/{y}.png",
          wrapX: false,
        }),
      });

      this.map = new ol.Map({
        layers: [gaodeMapLayer],
        view: new ol.View({
          center: [-73.95588028, 40.65137012],

          zoom: 15, // 设置初始化时的地图缩放层级
          projection: "EPSG:4326", // 坐标系
        }),
        target: "mapCon", // 地图dom
      });
      // this.setdata();
      this.showPoint();
    },
    showPoint() {
      var features = new Array();
      var routerline1 =
       [
        [-73.9558629,40.6513086],
         [-73.95582413,40.65050987],
        [-73.9466676,40.6509372],
        [-73.94677695,40.65184834],
        [-73.94966558,40.65169904],
        [-73.95006127,40.65543080],
        [-73.94715870,40.65559529],
    
      ];
      //       [
      //   [-73.937444,40.631550],
      //   [-73.936474,40.631105],
      //   [-73.935714,40.631498],

      //   [-73.934255,40.633208],
      //   [-73.932705,40.634669],
      //   [-73.931472,40.634936],
      //   [-73.9304877,40.6350057],[-73.929522,40.634078],[-73.9270,40.635902],
      //   [-73.925830,40.638917],[-73.9246,40.6453],
        
      //   [-73.924336,40.647700],[-73.9245,40.64898]
      // ];
        //      [ 
        // [-73.938729,40.631891],
    
        //         [-73.9379759,40.6322273],
        //  [-73.937431,40.632180],
        // [-73.935950,40.632219],
        // [-73.935229,40.632389],
      
        // [-73.929848, 40.632512],[-73.929763,40.632599],        [-73.928742, 40.63388],
        // [-73.926791, 40.635791],

        // [-73.925765, 40.640276],
        // [-73.925041, 40.643696],
        // [-73.924095, 40.648744],]
    var routerline2 = [
        [-73.95588028, 40.65137012],
        [-73.95580198, 40.65054242],
        [-73.95247241, 40.65069902],
        [-73.95282584,40.65398052],
        [-73.94703251,40.65434198],
        [-73.94715870,40.65559529],
      ];

      var routerline3 = [
        [-73.95591997, 40.65136838],
        [-73.94984013,40.65329009],
        [-73.94715870,40.65559529],
      ];
      var routerline4 = [
        [-73.95588028, 40.65137012],
        [-73.95036259,40.65411958],
        [-73.94715870,40.65559529],
      ];

    var routerlist =
       [
        [-73.9558629,40.6513086],
         
        [-73.94735253,40.65728042],
    
      ];
      var i = 0;
      

      this.data =[
        {
          geo: [-73.94715870,40.65559529],
          point_location: "A1" ,
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "Sensor " + String.fromCharCode(65 + i),
        },{
          geo: [-73.94984013,40.65329009],
          point_location: "A2" ,
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "Sensor " + String.fromCharCode(65 + i),
        },{
          geo: [-73.95588028, 40.65137012],
          point_location: "A3" ,
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "Sensor " + String.fromCharCode(65 + i),
        },{
          geo: [-73.9558629,40.6513086],
          point_location: "B3" ,
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "Sensor " + String.fromCharCode(65 + i),
        },{
          geo: [-73.95036259,40.65411958],
          point_location: "B2" ,
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "Sensor " + String.fromCharCode(65 + i),
        },{
          geo: [-73.94715870,40.65559529],
          point_location: "B1" ,
          point_status_name: "Point " + String.fromCharCode(65 + i),
          point_value: "Value " + String.fromCharCode(65 + i),
          sensor_type_name: "Sensor " + String.fromCharCode(65 + i),
        },]

        
   
      this.createMark();
      var routeFeature = new ol.Feature({
        type: "route1",
        geometry: new ol.geom.LineString(routerline2),
      });
      var routeFeature1 = new ol.Feature({
        type: "route2",
        geometry: new ol.geom.LineString(routerline1),
      });
      var routeFeature2 = new ol.Feature({
        type: "route3",
        geometry: new ol.geom.LineString(routerline3),
      });
      var routeFeature3 = new ol.Feature({
        type: "route4",
        geometry: new ol.geom.LineString(routerline4),
      });

      var startMarker = new ol.Feature({
        type: "iconStart",
        geometry: new ol.geom.Point(routerline2[0]),
      });

      var source = new ol.source.Vector({
        features: [
          routeFeature,
          startMarker,
          routeFeature1,
          routeFeature2,
          routeFeature3,
        ],
      });
      var styles = {
        route1: new Style({
          stroke: new Stroke({
            width: 5,
            color: "red",
          }),
        }),
        route2: new Style({
          stroke: new Stroke({
            width: 5,
            color: "blue",
          }),
        }),
        route3: new Style({
          stroke: new Stroke({
            width: 5,
            color: "blue",
            lineDash: [15, 15, 15, 15],
          }),
        }),
        route4: new Style({
          stroke: new Stroke({
            width: 5,
            color: "red",
            lineDash: [15, 15, 15, 15],
        
          }),
        }),
        iconStart: new Style({
          image: new Icon({
            anchor: [0.5, 0.5], // 图标中心
            src: require("./img/blueIcon.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
        }),
      };
      this.clusters = new ol.layer.Vector({
        source: new ol.source.Vector({
          features: [routeFeature, routeFeature1, routeFeature2, routeFeature3],
        }),
        style: function (feature) {
          return styles[feature.get("type")];
        },
      });




 
          this.map.addLayer(this.clusters);

      
    },
    setdata() {
      this.data = [
        {
          geo: [-73.9559225, 40.6513735],
          point_location: "A3",
          point_status_name: "葫芦岛校区",
          point_value: "学校",
          sensor_type_name: "71262",
        },
        {
          geo: [-73.9558701, 40.6513696],
          point_location: "B3",
          point_status_name: "超市、商场。美食、电影院",
          point_value: "景区",
          sensor_type_name: "71265",
        },
        {
          geo: [-73.9504903, 40.6553856],

          point_location: "B2",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
        {
          geo: [-73.95004012, 40.65515705],

          point_location: "A2",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },

        {
          geo: [-73.94733891, 40.65726851],

          point_location: "B1",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
        {
          geo: [-73.94736967, 40.65729141],

          point_location: "A1",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
      ];

      this.createMark();
    },
    setInnerText(element, text) {
      if (typeof element.textContent == "string") {
        element.textContent = text;
      } else {
        element.innerText = text;
      }
    },
    addFeatrueInfo(info) {
      var content = document.getElementById("popup-content");

      //新增a元素
      var elementA = document.createElement("a");
      elementA.className = "markerInfo";

      //elementA.innerText = info.att.title;
      this.setInnerText(elementA, "ID：" + info.name);
      // 新建的div元素添加a子节点
      content.appendChild(elementA);
      //新增div元素
      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      //elementDiv.innerText = info.att.text;
      this.setInnerText(elementDiv, "名称：" + info.pintName);
      // 为content添加div子节点
      content.appendChild(elementDiv);
      //新增div元素
      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      //elementDiv.innerText = info.att.text;
      this.setInnerText(elementDiv, "类别：" + info.value);
      // 为content添加div子节点
      content.appendChild(elementDiv);
      //新增div元素
      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      //elementDiv.innerText = info.att.text;
      this.setInnerText(elementDiv, "描述：" + info.status);
      // 为content添加div子节点
      content.appendChild(elementDiv);
    },
    createMark() {
      var features = new Array();
      for (var i = 0; i < this.data.length; i++) {
        let Ary = new ol.Feature({
          geometry: new ol.geom.Point(this.data[i].geo),

          status: this.data[i].point_status_name,
          name: this.data[i].sensor_type_name,
          value: this.data[i].point_value,
          pintName: this.data[i].point_location,
          type: this.data[i].point_location,
        });

        features.push(Ary);
        // features.push(
        //   new ol.Feature({
        //     geometry: new ol.geom.Point(this.data[i].geo),
        //   })
        // );
      }

      // 矢量要素数据源
      var source = new ol.source.Vector({
        features: features,
      });

      // 聚合标注数据源
      var clusterSource = new ol.source.Cluster({
        distance: 0, //这个是通过 distance 来控制两个点聚合的间距
        source: source,
      });
      var styles1 = {
        A1: new Style({
          image: new Icon({
            anchor: [0.5, 0.7], // 图标中心
            src: require("./img/blueIcon.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
          text: new Text({
            //位置
            textAlign: "right",
            //基准线
            textBaseline: "middle",
            //文字样式
            font: "normal 32px 微软雅黑",
            //文本内容
            text: "  A1",
            offsetX: -20,
             offsetY: -10,
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        B1: new Style({
          image: new Icon({
            anchor: [0.5, 0.5], // 图标中心
            src: require("./img/blueIcon.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
          text: new Text({
            //位置
            textAlign: "left",
            //基准线
            textBaseline: "bottom",
            font: "normal 32px 微软雅黑",
            //文本内容
            offsetX: 20,
            text: "B1",
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        A2: new Style({
          image: new Icon({
            anchor: [0.5, 0.7], // 图标中心
            src: require("./img/blueIcon.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
          text: new Text({
            //位置
            textAlign: "right",
            //基准线
            textBaseline: "middle",
            //文字样式
            font: "normal 32px 微软雅黑",
            //文本内容
            text: "  A2",
            offsetX: -20,
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        B2: new Style({
          image: new Icon({
            anchor: [0.5, 0.7], // 图标中心
            src: require("./img/blueIcon.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
          text: new Text({
            //位置
            textAlign: "right",
            //基准线
            textBaseline: "middle",
            //文字样式
            font: "normal 32px 微软雅黑",
            //文本内容
            text: "  B2",
            offsetX: -20,
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        A3: new Style({
          image: new Icon({
            anchor: [0.5, 0.7], // 图标中心
            src: require("./img/blueIcon.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
          text: new Text({
            //位置
            textAlign: "right",
            //基准线
            textBaseline: "middle",
            //文字样式
            font: "normal 32px 微软雅黑",
            //文本内容
            text: "  A2",
            offsetX: -20,
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        B3: new Style({
          image: new Icon({
            anchor: [0.4, 0.5], // 图标中心
            src: require("./img/blueIcon.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
          text: new Text({
            //位置
            textAlign: "left",
            //基准线
            textBaseline: "bottom",
            //文字样式
            font: "normal 32px 微软雅黑",
            //文本内容
            offsetX: 20,
            text: "B3",
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
      };

      var clusters = new ol.layer.Vector({
        source: source,
        style: (feature) => {
          return styles1[feature.get("type")];
        },

        // {
        //   var text = feature.get("point_location"); //这个是每个点位对应的id
        //   var color = "";
        //   // mark点的填充颜色判断

        //   color = "#00ff00";

        //   return new Style({
        //     image: new Icon({
        //     anchor: [0.5, 0.5], // 图标中心
        //     src: require("./img/blueIcon.png"),
        //     scale: 0.5,

        //     rotateWithView: true,
        //   }),
        //     text: new Text({
        //       //位置
        //       textAlign: "bottom",
        //       //基准线
        //       textBaseline: "middle",
        //       //文字样式
        //       font: "normal 20px 微软雅黑",
        //       //文本内容
        //        text: feature.get('pintName'),
        //       //文本填充样式（即文字颜色）
        //       fill: new ol.style.Fill({ color: "#000000" }),
        //       stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
        //     }),
        //   });
        // },

        // style: function (feature, resolution) {
        //   var size = feature.get("features").length; //获取该要素所在聚合群的要素数量
        //   var style = styleCache[size];
        //   if (!style) {
        //     style = [
        //       new Style({
        //         image: new Circle({
        //           radius: 10,
        //           stroke: new Stroke({
        //             color: "#fff",
        //           }),
        //           fill: new Fill({
        //             color: "#3399CC",
        //           }),
        //         }),
        //       }),
        //     ];
        //   }
        //   return style;
        // },
        zIndex: 999,
      });

      this.map.addLayer(clusters);
      // 弹窗

      this.map.on("singleclick", (e) => {
        let elPopup = this.$refs.popup;
        var popup = new ol.Overlay({
          element: elPopup,
          positioning: "bottom-center",
          stopEvent: false,
          // 信息框的上下位置
          offset: [0, 30],
        });
        this.map.addOverlay(popup);
        console.log(e.pixel);
        let feature = this.map.forEachFeatureAtPixel(
          e.pixel,
          (feature) => feature
        );
        console.log(feature.values_);
        if (feature) {
          let coordinates = feature.getGeometry().getCoordinates();
          // console.log(coordinates)
          setTimeout(() => {
            var content = document.getElementById("popup-content");
            content.innerHTML = "";
            this.show = true;
            //在popup中加载当前要素的具体信息
            this.addFeatrueInfo(feature.values_);

            popup.setPosition(coordinates);
          }, 0);
        } else {
          this.show = false;
        }
      });
      //   this.map.on("singleclick", (e) => {
      //     let elPopup = this.$refs.popup;
      //     var popup = new ol.Overlay({
      //       element: elPopup,
      //       positioning: "bottom-center",
      //       stopEvent: false,
      //       // 信息框的上下位置
      //       offset: [0, 30],
      //     });
      //     this.map.addOverlay(popup);
      //     console.log(e.pixel)
      //     let feature = this.map.forEachFeatureAtPixel(
      //       e.pixel,
      //       (feature) => feature
      //     );
      //     console.log(feature.values_);
      //     if (feature) {
      //       let coordinates = feature.getGeometry().getCoordinates();
      //       // console.log(coordinates)
      //       setTimeout(() => {
      //         var content = document.getElementById("popup-content");
      //         content.innerHTML = "";
      //         this.show = true;
      //         //在popup中加载当前要素的具体信息
      //         this.addFeatrueInfo(feature.values_);

      //         popup.setPosition(coordinates);
      //       }, 0);
      //     } else {
      //       this.show = false;
      //     }
      //   });
    },

    // 初始化地图
    // initMap() {
    //   this.map = new Map({
    //     layers: [
    //       new TileLayer({
    //     extent: [37467916, 3964896.75, 37478080, 3972216.5],
    //      source: new TileWMS({
    //       url: "http://120.53.249.144:8080/geoserver/wms",
    //       params: { LAYERS: "webgis:cad_polyline" },
    //       serverType: "geoserver",
    //     }),

    //   })
    //     ],
    //     target: "map",
    //     view: new View({
    //        center: [37477916, 3968896.2],
    //        projection: 'EPSG:3857',
    //       zoom: 14,
    //     }),
    //   });
    // },

    addLayer() {
      // 加载 GeoServer 发布的 wms 服务
      let wmsLayer = new TileLayer({
        extent: [
          // 边界
          97.350096, 26.045865, 108.546488, 34.312446,
        ],
        source: new TileWMS({
          //上线后，记得要把url: 'http://localhost:8090/geoserver/ws-world/wms'中的localhost换成云服务器的ip地址！！
          url: "http://120.76.197.111:8090/geoserver/keshan/wms",
          params: { LAYERS: "keshan:sichuan", TILED: true },
          serverType: "geoserver",
        }),
        visible: true,
        zIndex: 2,
      });
      this.map.addLayer(wmsLayer);
    },
  },
};
</script>
<style lang="less" scoped>
#mapCon {
  width: 120%;
  height: 70%;
  position: relative;
  float: left;
}

.quarter-div {
  position: relative;
  background-color: aqua;
  width: 20%;
  height: 10%;

  float: left;
  right: 35px;
  top: 20px;
}

#title {

  top: 70%;
  position: relative;
  // float: right;
  height: 30%;

  width: 100%;
  // height: 700px;
  text-align: center;
}
.ol-popup {
  position: absolute;
  background-color: white;
  -webkit-filter: drop-shadow(0 1px 4px rgba(0, 0, 0, 0.2));
  filter: drop-shadow(0 1px 4px rgba(0, 0, 0, 0.2));
  padding: 15px;
  border-radius: 10px;
  border: 1px solid #cccccc;
  bottom: 45px;
  left: -50px;
}

.ol-popup:after,
.ol-popup:before {
  top: 100%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}

.ol-popup:after {
  border-top-color: white;
  border-width: 10px;
  left: 48px;
  margin-left: -10px;
}

.ol-popup:before {
  border-top-color: #cccccc;
  border-width: 11px;
  left: 48px;
  margin-left: -11px;
}

.ol-popup-closer {
  text-decoration: none;
  position: absolute;
  top: 2px;
  right: 8px;
}

.ol-popup-closer:after {
  content: "✖";
}

#popup-content {
  font-size: 14px;
  font-family: "微软雅黑";
  width: 160px;
}

#popup-content .markerInfo {
  font-weight: bold;
}
#popup-content1 {
  font-size: 14px;
  font-family: "微软雅黑";
  width: 300px;
}

#popup-content1 .markerInfo {
  font-weight: bold;
}
</style>