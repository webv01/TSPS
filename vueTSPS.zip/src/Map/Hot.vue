<template>
  <div style="height: 100%">
    <div id="map"></div>
    <!-- <div id="title">
      <div style="left: 0%; hight: 20%; position: relative">
        <el-input
          placeholder="搜索关键字，例如：covid-19"
          v-model="input2"
          style="width: 82%; left: 10px; top: 15px; position: absolute"
        >
        </el-input>
        <i
          class="el-icon-search"
          style="float: right; right: 30px; top: 20px; position: relative"
        ></i>
      </div>
    </div> -->
  </div>
</template>

<script>
import Map from "ol/Map";
import View from "ol/View";
import { Heatmap as HeatmapLayer } from "ol/layer";
import { Icon, Stroke, Style, Circle, Fill, Text } from "ol/style";
import VectorSource from "ol/source/Vector";
import { transform } from "ol/proj";
import GeoJSON from "ol/format/GeoJSON";
import ol from "../utils/ol5/ol";
import proj4 from "proj4";
export default {
  name: "heatmap",
  data() {
    return {
      map: null,
      center: [37473426.9, 3968134.2],
      data: new Array(),
      // 热力图假数据
      heatData: {
        type: "FeatureCollection",
        name: "test",
        features: [
          {
            type: "Feature",
            properties: { geo_id: 773869 },
            geometry: { type: "Point", coordinates: [-118.31829, 34.15497] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767541 },
            geometry: { type: "Point", coordinates: [-118.23799, 34.11621] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767542 },
            geometry: { type: "Point", coordinates: [-118.23819, 34.11641] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717447 },
            geometry: { type: "Point", coordinates: [-118.26772, 34.07248] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717446 },
            geometry: { type: "Point", coordinates: [-118.26572, 34.07142] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717445 },
            geometry: { type: "Point", coordinates: [-118.25932, 34.06913] },
          },
          {
            type: "Feature",
            properties: { geo_id: 773062 },
            geometry: { type: "Point", coordinates: [-118.23369, 34.05368] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767620 },
            geometry: { type: "Point", coordinates: [-118.22932, 34.13486] },
          },
          {
            type: "Feature",
            properties: { geo_id: 737529 },
            geometry: { type: "Point", coordinates: [-118.47352, 34.20264] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717816 },
            geometry: { type: "Point", coordinates: [-118.4686, 34.15562] },
          },
          {
            type: "Feature",
            properties: { geo_id: 765604 },
            geometry: { type: "Point", coordinates: [-118.38223, 34.16415] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767471 },
            geometry: { type: "Point", coordinates: [-118.22469, 34.15691] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716339 },
            geometry: { type: "Point", coordinates: [-118.28795, 34.07821] },
          },
          {
            type: "Feature",
            properties: { geo_id: 773906 },
            geometry: { type: "Point", coordinates: [-118.30266, 34.1566] },
          },
          {
            type: "Feature",
            properties: { geo_id: 765273 },
            geometry: { type: "Point", coordinates: [-118.47437, 34.18949] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716331 },
            geometry: { type: "Point", coordinates: [-118.26246, 34.07006] },
          },
          {
            type: "Feature",
            properties: { geo_id: 771667 },
            geometry: { type: "Point", coordinates: [-118.23388, 34.07314] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716337 },
            geometry: { type: "Point", coordinates: [-118.28186, 34.07732] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769953 },
            geometry: { type: "Point", coordinates: [-118.19992, 34.20672] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769402 },
            geometry: { type: "Point", coordinates: [-118.33911, 34.12095] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769403 },
            geometry: { type: "Point", coordinates: [-118.33928, 34.12073] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769819 },
            geometry: { type: "Point", coordinates: [-118.19803, 34.20584] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769405 },
            geometry: { type: "Point", coordinates: [-118.34482, 34.12634] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716941 },
            geometry: { type: "Point", coordinates: [-118.21435, 34.05767] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717578 },
            geometry: { type: "Point", coordinates: [-118.27076, 34.15478] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716960 },
            geometry: { type: "Point", coordinates: [-118.27164, 34.12121] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717804 },
            geometry: { type: "Point", coordinates: [-118.47605, 34.09478] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767572 },
            geometry: { type: "Point", coordinates: [-118.22871, 34.12967] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767573 },
            geometry: { type: "Point", coordinates: [-118.22901, 34.12964] },
          },
          {
            type: "Feature",
            properties: { geo_id: 773012 },
            geometry: { type: "Point", coordinates: [-118.22086, 34.0839] },
          },
          {
            type: "Feature",
            properties: { geo_id: 773013 },
            geometry: { type: "Point", coordinates: [-118.22076, 34.08374] },
          },
          {
            type: "Feature",
            properties: { geo_id: 764424 },
            geometry: { type: "Point", coordinates: [-118.39469, 34.17878] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769388 },
            geometry: { type: "Point", coordinates: [-118.33441, 34.11027] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716328 },
            geometry: { type: "Point", coordinates: [-118.25397, 34.06664] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717819 },
            geometry: { type: "Point", coordinates: [-118.47407, 34.18784] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769941 },
            geometry: { type: "Point", coordinates: [-118.20237, 34.20699] },
          },
          {
            type: "Feature",
            properties: { geo_id: 760987 },
            geometry: { type: "Point", coordinates: [-118.34043, 34.15359] },
          },
          {
            type: "Feature",
            properties: { geo_id: 718204 },
            geometry: { type: "Point", coordinates: [-118.29575, 34.15541] },
          },
          {
            type: "Feature",
            properties: { geo_id: 718045 },
            geometry: { type: "Point", coordinates: [-118.23973, 34.06712] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769418 },
            geometry: { type: "Point", coordinates: [-118.34465, 34.12659] },
          },
          {
            type: "Feature",
            properties: { geo_id: 768066 },
            geometry: { type: "Point", coordinates: [-118.3748, 34.15118] },
          },
          {
            type: "Feature",
            properties: { geo_id: 772140 },
            geometry: { type: "Point", coordinates: [-118.47493, 34.16498] },
          },
          {
            type: "Feature",
            properties: { geo_id: 773927 },
            geometry: { type: "Point", coordinates: [-118.28034, 34.15262] },
          },
          {
            type: "Feature",
            properties: { geo_id: 760024 },
            geometry: { type: "Point", coordinates: [-118.46483, 34.1593] },
          },
          {
            type: "Feature",
            properties: { geo_id: 774012 },
            geometry: { type: "Point", coordinates: [-118.20137, 34.14769] },
          },
          {
            type: "Feature",
            properties: { geo_id: 774011 },
            geometry: { type: "Point", coordinates: [-118.20123, 34.14747] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767609 },
            geometry: { type: "Point", coordinates: [-118.21733, 34.18555] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769359 },
            geometry: { type: "Point", coordinates: [-118.42216, 34.1566] },
          },
          {
            type: "Feature",
            properties: { geo_id: 760650 },
            geometry: { type: "Point", coordinates: [-118.23256, 34.07505] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716956 },
            geometry: { type: "Point", coordinates: [-118.25544, 34.10658] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769831 },
            geometry: { type: "Point", coordinates: [-118.20101, 34.20663] },
          },
          {
            type: "Feature",
            properties: { geo_id: 761604 },
            geometry: { type: "Point", coordinates: [-118.28711, 34.15407] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717495 },
            geometry: { type: "Point", coordinates: [-118.41326, 34.15664] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716554 },
            geometry: { type: "Point", coordinates: [-118.2666, 34.15597] },
          },
          {
            type: "Feature",
            properties: { geo_id: 773953 },
            geometry: { type: "Point", coordinates: [-118.29344, 34.15522] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767470 },
            geometry: { type: "Point", coordinates: [-118.22436, 34.15699] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716955 },
            geometry: { type: "Point", coordinates: [-118.24427, 34.09579] },
          },
          {
            type: "Feature",
            properties: { geo_id: 764949 },
            geometry: { type: "Point", coordinates: [-118.34684, 34.12881] },
          },
          {
            type: "Feature",
            properties: { geo_id: 773954 },
            geometry: { type: "Point", coordinates: [-118.29344, 34.15544] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767366 },
            geometry: { type: "Point", coordinates: [-118.47341, 34.21216] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769444 },
            geometry: { type: "Point", coordinates: [-118.43908, 34.15555] },
          },
          {
            type: "Feature",
            properties: { geo_id: 773939 },
            geometry: { type: "Point", coordinates: [-118.37226, 34.15297] },
          },
          {
            type: "Feature",
            properties: { geo_id: 774067 },
            geometry: { type: "Point", coordinates: [-118.28441, 34.15362] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769443 },
            geometry: { type: "Point", coordinates: [-118.43931, 34.15574] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767750 },
            geometry: { type: "Point", coordinates: [-118.20635, 34.09335] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767751 },
            geometry: { type: "Point", coordinates: [-118.20616, 34.09335] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767610 },
            geometry: { type: "Point", coordinates: [-118.21766, 34.18555] },
          },
          {
            type: "Feature",
            properties: { geo_id: 773880 },
            geometry: { type: "Point", coordinates: [-118.3484, 34.15367] },
          },
          {
            type: "Feature",
            properties: { geo_id: 764766 },
            geometry: { type: "Point", coordinates: [-118.3535, 34.13338] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717497 },
            geometry: { type: "Point", coordinates: [-118.41456, 34.15685] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717490 },
            geometry: { type: "Point", coordinates: [-118.37124, 34.14745] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717491 },
            geometry: { type: "Point", coordinates: [-118.3711, 34.14761] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717492 },
            geometry: { type: "Point", coordinates: [-118.37935, 34.15459] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717493 },
            geometry: { type: "Point", coordinates: [-118.39618, 34.15434] },
          },
          {
            type: "Feature",
            properties: { geo_id: 765176 },
            geometry: { type: "Point", coordinates: [-118.35135, 34.13286] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717498 },
            geometry: { type: "Point", coordinates: [-118.43273, 34.15571] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717499 },
            geometry: { type: "Point", coordinates: [-118.44808, 34.15666] },
          },
          {
            type: "Feature",
            properties: { geo_id: 765171 },
            geometry: { type: "Point", coordinates: [-118.46896, 34.16789] },
          },
          {
            type: "Feature",
            properties: { geo_id: 718064 },
            geometry: { type: "Point", coordinates: [-118.24489, 34.11296] },
          },
          {
            type: "Feature",
            properties: { geo_id: 718066 },
            geometry: { type: "Point", coordinates: [-118.22889, 34.12302] },
          },
          {
            type: "Feature",
            properties: { geo_id: 765164 },
            geometry: { type: "Point", coordinates: [-118.28911, 34.07898] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769431 },
            geometry: { type: "Point", coordinates: [-118.45664, 34.15843] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769430 },
            geometry: { type: "Point", coordinates: [-118.45658, 34.15818] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717610 },
            geometry: { type: "Point", coordinates: [-118.39497, 34.17886] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767053 },
            geometry: { type: "Point", coordinates: [-118.46775, 34.17091] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767621 },
            geometry: { type: "Point", coordinates: [-118.22969, 34.13486] },
          },
          {
            type: "Feature",
            properties: { geo_id: 772596 },
            geometry: { type: "Point", coordinates: [-118.50495, 34.17126] },
          },
          {
            type: "Feature",
            properties: { geo_id: 772597 },
            geometry: { type: "Point", coordinates: [-118.50495, 34.17109] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767350 },
            geometry: { type: "Point", coordinates: [-118.47045, 34.18011] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767351 },
            geometry: { type: "Point", coordinates: [-118.47022, 34.18022] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716571 },
            geometry: { type: "Point", coordinates: [-118.40337, 34.2] },
          },
          {
            type: "Feature",
            properties: { geo_id: 773023 },
            geometry: { type: "Point", coordinates: [-118.24348, 34.05773] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767585 },
            geometry: { type: "Point", coordinates: [-118.22432, 34.16556] },
          },
          {
            type: "Feature",
            properties: { geo_id: 773024 },
            geometry: { type: "Point", coordinates: [-118.24357, 34.05759] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717483 },
            geometry: { type: "Point", coordinates: [-118.33698, 34.11684] },
          },
          {
            type: "Feature",
            properties: { geo_id: 718379 },
            geometry: { type: "Point", coordinates: [-118.27812, 34.14224] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717481 },
            geometry: { type: "Point", coordinates: [-118.32826, 34.10634] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717480 },
            geometry: { type: "Point", coordinates: [-118.32497, 34.10478] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717486 },
            geometry: { type: "Point", coordinates: [-118.34809, 34.12974] },
          },
          {
            type: "Feature",
            properties: { geo_id: 764120 },
            geometry: { type: "Point", coordinates: [-118.40366, 34.20164] },
          },
          {
            type: "Feature",
            properties: { geo_id: 772151 },
            geometry: { type: "Point", coordinates: [-118.49872, 34.16928] },
          },
          {
            type: "Feature",
            properties: { geo_id: 718371 },
            geometry: { type: "Point", coordinates: [-118.23849, 34.09017] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717489 },
            geometry: { type: "Point", coordinates: [-118.36438, 34.13876] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717488 },
            geometry: { type: "Point", coordinates: [-118.36006, 34.13561] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717818 },
            geometry: { type: "Point", coordinates: [-118.46753, 34.1722] },
          },
          {
            type: "Feature",
            properties: { geo_id: 718076 },
            geometry: { type: "Point", coordinates: [-118.2253, 34.16339] },
          },
          {
            type: "Feature",
            properties: { geo_id: 718072 },
            geometry: { type: "Point", coordinates: [-118.2257, 34.1491] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767455 },
            geometry: { type: "Point", coordinates: [-118.22704, 34.14347] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767454 },
            geometry: { type: "Point", coordinates: [-118.22733, 34.14352] },
          },
          {
            type: "Feature",
            properties: { geo_id: 761599 },
            geometry: { type: "Point", coordinates: [-118.27786, 34.14226] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717099 },
            geometry: { type: "Point", coordinates: [-118.24674, 34.15648] },
          },
          {
            type: "Feature",
            properties: { geo_id: 773916 },
            geometry: { type: "Point", coordinates: [-118.2852, 34.15247] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716968 },
            geometry: { type: "Point", coordinates: [-118.29809, 34.16588] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769467 },
            geometry: { type: "Point", coordinates: [-118.39699, 34.15451] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717576 },
            geometry: { type: "Point", coordinates: [-118.2957, 34.15559] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717573 },
            geometry: { type: "Point", coordinates: [-118.325, 34.15384] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717572 },
            geometry: { type: "Point", coordinates: [-118.32751, 34.15351] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717571 },
            geometry: { type: "Point", coordinates: [-118.35921, 34.15326] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717570 },
            geometry: { type: "Point", coordinates: [-118.35921, 34.15302] },
          },
          {
            type: "Feature",
            properties: { geo_id: 764760 },
            geometry: { type: "Point", coordinates: [-118.35506, 34.13401] },
          },
          {
            type: "Feature",
            properties: { geo_id: 718089 },
            geometry: { type: "Point", coordinates: [-118.27372, 34.12769] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769847 },
            geometry: { type: "Point", coordinates: [-118.22351, 34.20983] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717608 },
            geometry: { type: "Point", coordinates: [-118.38812, 34.17154] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767523 },
            geometry: { type: "Point", coordinates: [-118.24209, 34.11439] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716942 },
            geometry: { type: "Point", coordinates: [-118.21451, 34.0593] },
          },
          {
            type: "Feature",
            properties: { geo_id: 718090 },
            geometry: { type: "Point", coordinates: [-118.27969, 34.14847] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769867 },
            geometry: { type: "Point", coordinates: [-118.23931, 34.21846] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717472 },
            geometry: { type: "Point", coordinates: [-118.31601, 34.10045] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717473 },
            geometry: { type: "Point", coordinates: [-118.31581, 34.10054] },
          },
          {
            type: "Feature",
            properties: { geo_id: 759591 },
            geometry: { type: "Point", coordinates: [-118.26825, 34.11521] },
          },
          {
            type: "Feature",
            properties: { geo_id: 764781 },
            geometry: { type: "Point", coordinates: [-118.47012, 34.16037] },
          },
          {
            type: "Feature",
            properties: { geo_id: 765099 },
            geometry: { type: "Point", coordinates: [-118.47224, 34.16378] },
          },
          {
            type: "Feature",
            properties: { geo_id: 762329 },
            geometry: { type: "Point", coordinates: [-118.22862, 34.13904] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716953 },
            geometry: { type: "Point", coordinates: [-118.24279, 34.09458] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716951 },
            geometry: { type: "Point", coordinates: [-118.23182, 34.08581] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767509 },
            geometry: { type: "Point", coordinates: [-118.24819, 34.11059] },
          },
          {
            type: "Feature",
            properties: { geo_id: 765182 },
            geometry: { type: "Point", coordinates: [-118.25126, 34.06491] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769358 },
            geometry: { type: "Point", coordinates: [-118.42222, 34.15679] },
          },
          {
            type: "Feature",
            properties: { geo_id: 772513 },
            geometry: { type: "Point", coordinates: [-118.23661, 34.06871] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716958 },
            geometry: { type: "Point", coordinates: [-118.26501, 34.11167] },
          },
          {
            type: "Feature",
            properties: { geo_id: 718496 },
            geometry: { type: "Point", coordinates: [-118.34232, 34.15403] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769346 },
            geometry: { type: "Point", coordinates: [-118.40424, 34.15677] },
          },
          {
            type: "Feature",
            properties: { geo_id: 773904 },
            geometry: { type: "Point", coordinates: [-118.30266, 34.15641] },
          },
          {
            type: "Feature",
            properties: { geo_id: 718499 },
            geometry: { type: "Point", coordinates: [-118.31253, 34.15469] },
          },
          {
            type: "Feature",
            properties: { geo_id: 764853 },
            geometry: { type: "Point", coordinates: [-118.25102, 34.06461] },
          },
          {
            type: "Feature",
            properties: { geo_id: 761003 },
            geometry: { type: "Point", coordinates: [-118.30841, 34.15546] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717502 },
            geometry: { type: "Point", coordinates: [-118.47484, 34.16521] },
          },
          {
            type: "Feature",
            properties: { geo_id: 759602 },
            geometry: { type: "Point", coordinates: [-118.27178, 34.12199] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717504 },
            geometry: { type: "Point", coordinates: [-118.49166, 34.16519] },
          },
          {
            type: "Feature",
            properties: { geo_id: 763995 },
            geometry: { type: "Point", coordinates: [-118.40931, 34.21979] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717508 },
            geometry: { type: "Point", coordinates: [-118.51814, 34.17112] },
          },
          {
            type: "Feature",
            properties: { geo_id: 765265 },
            geometry: { type: "Point", coordinates: [-118.47395, 34.18529] },
          },
          {
            type: "Feature",
            properties: { geo_id: 773996 },
            geometry: { type: "Point", coordinates: [-118.21587, 34.14511] },
          },
          {
            type: "Feature",
            properties: { geo_id: 773995 },
            geometry: { type: "Point", coordinates: [-118.21587, 34.14483] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717469 },
            geometry: { type: "Point", coordinates: [-118.31366, 34.0971] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717468 },
            geometry: { type: "Point", coordinates: [-118.31381, 34.09699] },
          },
          {
            type: "Feature",
            properties: { geo_id: 764106 },
            geometry: { type: "Point", coordinates: [-118.38801, 34.17169] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717465 },
            geometry: { type: "Point", coordinates: [-118.30907, 34.09373] },
          },
          {
            type: "Feature",
            properties: { geo_id: 764794 },
            geometry: { type: "Point", coordinates: [-118.46808, 34.16028] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717466 },
            geometry: { type: "Point", coordinates: [-118.30918, 34.09359] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717461 },
            geometry: { type: "Point", coordinates: [-118.30174, 34.08558] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717460 },
            geometry: { type: "Point", coordinates: [-118.30161, 34.08571] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717463 },
            geometry: { type: "Point", coordinates: [-118.3059, 34.09004] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717462 },
            geometry: { type: "Point", coordinates: [-118.30607, 34.08993] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769345 },
            geometry: { type: "Point", coordinates: [-118.40441, 34.15655] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716943 },
            geometry: { type: "Point", coordinates: [-118.21492, 34.05987] },
          },
          {
            type: "Feature",
            properties: { geo_id: 772669 },
            geometry: { type: "Point", coordinates: [-118.22834, 34.07828] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717582 },
            geometry: { type: "Point", coordinates: [-118.26092, 34.15646] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717583 },
            geometry: { type: "Point", coordinates: [-118.25506, 34.15627] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717580 },
            geometry: { type: "Point", coordinates: [-118.26359, 34.1562] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716949 },
            geometry: { type: "Point", coordinates: [-118.22974, 34.08406] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717587 },
            geometry: { type: "Point", coordinates: [-118.23893, 34.15402] },
          },
          {
            type: "Feature",
            properties: { geo_id: 772178 },
            geometry: { type: "Point", coordinates: [-118.49885, 34.16903] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717585 },
            geometry: { type: "Point", coordinates: [-118.24188, 34.15564] },
          },
          {
            type: "Feature",
            properties: { geo_id: 716939 },
            geometry: { type: "Point", coordinates: [-118.21724, 34.04301] },
          },
          {
            type: "Feature",
            properties: { geo_id: 768469 },
            geometry: { type: "Point", coordinates: [-118.35993, 34.13583] },
          },
          {
            type: "Feature",
            properties: { geo_id: 764101 },
            geometry: { type: "Point", coordinates: [-118.38246, 34.16421] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767554 },
            geometry: { type: "Point", coordinates: [-118.23143, 34.11966] },
          },
          {
            type: "Feature",
            properties: { geo_id: 773975 },
            geometry: { type: "Point", coordinates: [-118.22251, 34.14584] },
          },
          {
            type: "Feature",
            properties: { geo_id: 773974 },
            geometry: { type: "Point", coordinates: [-118.22251, 34.14559] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717510 },
            geometry: { type: "Point", coordinates: [-118.51976, 34.17128] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717513 },
            geometry: { type: "Point", coordinates: [-118.5368, 34.17339] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717825 },
            geometry: { type: "Point", coordinates: [-118.47307, 34.22164] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767495 },
            geometry: { type: "Point", coordinates: [-118.24992, 34.10377] },
          },
          {
            type: "Feature",
            properties: { geo_id: 767494 },
            geometry: { type: "Point", coordinates: [-118.24962, 34.10377] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717821 },
            geometry: { type: "Point", coordinates: [-118.47361, 34.20112] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717823 },
            geometry: { type: "Point", coordinates: [-118.47326, 34.20264] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717458 },
            geometry: { type: "Point", coordinates: [-118.29755, 34.08265] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717459 },
            geometry: { type: "Point", coordinates: [-118.29729, 34.08294] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769926 },
            geometry: { type: "Point", coordinates: [-118.23113, 34.21356] },
          },
          {
            type: "Feature",
            properties: { geo_id: 764858 },
            geometry: { type: "Point", coordinates: [-118.3754, 34.1527] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717450 },
            geometry: { type: "Point", coordinates: [-118.27362, 34.07488] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717452 },
            geometry: { type: "Point", coordinates: [-118.27356, 34.07502] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717453 },
            geometry: { type: "Point", coordinates: [-118.28093, 34.07696] },
          },
          {
            type: "Feature",
            properties: { geo_id: 759772 },
            geometry: { type: "Point", coordinates: [-118.30539, 34.17115] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717456 },
            geometry: { type: "Point", coordinates: [-118.29325, 34.08102] },
          },
          {
            type: "Feature",
            properties: { geo_id: 771673 },
            geometry: { type: "Point", coordinates: [-118.22871, 34.07787] },
          },
          {
            type: "Feature",
            properties: { geo_id: 772167 },
            geometry: { type: "Point", coordinates: [-118.47985, 34.16526] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769372 },
            geometry: { type: "Point", coordinates: [-118.3173, 34.1027] },
          },
          {
            type: "Feature",
            properties: { geo_id: 774204 },
            geometry: { type: "Point", coordinates: [-118.34172, 34.15397] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769806 },
            geometry: { type: "Point", coordinates: [-118.18442, 34.19638] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717590 },
            geometry: { type: "Point", coordinates: [-118.23182, 34.14929] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717592 },
            geometry: { type: "Point", coordinates: [-118.2243, 34.14604] },
          },
          {
            type: "Feature",
            properties: { geo_id: 717595 },
            geometry: { type: "Point", coordinates: [-118.1829, 34.14163] },
          },
          {
            type: "Feature",
            properties: { geo_id: 772168 },
            geometry: { type: "Point", coordinates: [-118.47985, 34.16542] },
          },
          {
            type: "Feature",
            properties: { geo_id: 718141 },
            geometry: { type: "Point", coordinates: [-118.37456, 34.15133] },
          },
          {
            type: "Feature",
            properties: { geo_id: 769373 },
            geometry: { type: "Point", coordinates: [-118.31747, 34.10262] },
          },
        ],
      },
    };
  },
  mounted() {
    this.initmap();
  },
  methods: {
    initmap() {
      var shamp = new ol.layer.Image({
        //数据范围
        name: "注记图层",
        // extent: [37467916, 3964896.75, 37478080, 3972216.5],
        source: new ol.source.ImageWMS({
          //WMS服务基地址
          url: "http://127.0.0.1:8080/geoserver/wms",
          //图层参数123
          params: {
            LAYERS: "		beijing:beijinghot",
          },
          //服务类型
          serverType: "geoserver",
        }),
      });
      var gaodeMapLayer = new ol.layer.Tile({
        title: "高德地图",
        source: new ol.source.XYZ({
          // url:"http://t4.tianditu.com/DataServer?T=vec_w&tk=4a76fd399e76e3e984e82953755c3410&x={x}&y={y}&l={z}",
          url: " https://tile.openstreetmap.org/{z}/{x}/{y}.png",
          wrapX: false,
        }),
      });
      this.map = new ol.Map({
        layers: [gaodeMapLayer],
        view: new ol.View({
          center: [-118.311178, 34.151224],

          zoom: 8, // 设置初始化时的地图缩放层级
          projection: "EPSG:4326", // 坐标系
        }),
        target: "map", // 地图dom
      });
      this.setdata12();
      this.setdata();
    },

    setdata() {
      // 创建一个热力图层
      let vector = new ol.layer.Vector({
        // 矢量数据源
        source: new VectorSource({
          features: new GeoJSON().readFeatures(this.heatData),
        }),
      });
      console.log(new GeoJSON().readFeatures(this.heatData));
      this.map.addLayer(vector);
    },

    setdata12() {
      this.data = [
        {
          geo: [-118.30266, 34.15641],
          point_location: "B3",

          name: "142",
          point_value: "住宅",
          value: "0",
        },
        {
          geo: [-118.2957, 34.15541],
          point_location: "B3",

          name: "", // #37
          point_value: "3",
          value: "0",
        },
        {
          geo: [-118.28034, 34.15262],
          point_location: "B3",

          name: "42",
          point_value: "住宅",
          value: "0",
        },
        {
          geo: [-118.29344, 34.15544],
          point_location: "A3",

          name: "58",
          point_value: "3",
          value: "3",
        },

        {
          geo: [-118.29595, 34.15559],
          point_location: "A3",

          name: "114",
          point_value: "3",
          value: "3",
        },
        {
          geo: [-118.29575, 34.15541],
          point_location: "A3",

          name: "\u2005" + "37",
          point_value: "3",
          value: "3",
        },
        {
          geo: [-118.29344, 34.15522],
          point_location: "B1",

          name: "54",
          point_value: "住宅",
          value: "0",
        },
        //         {
        //   geo: [-118.31253, 34.15469],
        //   point_location: "A3",

        //   name: "143",
        //   point_value: "3",
        //   value: "3",
        // },
        //         {
        //   geo: [-118.30841, 34.15546],
        //   point_location: "A3",

        //   name: "",
        //   point_value: "3",
        //   value: "3",
        // },
      ];

      this.createMark();
    },
    setInnerText(element, text) {
      if (typeof element.textContent == "string") {
        element.textContent = text;
      } else {
        element.innerText = text;
      }
    },
    addFeatrueInfo(info) {
      var content = document.getElementById("popup-content");

      //新增a元素
      var elementA = document.createElement("a");
      elementA.className = "markerInfo";

      //elementA.innerText = info.att.title;
      // this.setInnerText(elementA, "ID：" + info.name);

      this.setInnerText(elementA, "交通流量预测");

      // 新建的div元素添加a子节点
      content.appendChild(elementA);
      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      elementDiv.style.display = "flex";
      elementDiv.style.alignItems = "center";

      // // 新增10的元素
      // var elementSpan2 = document.createElement("span");
      // elementDiv.style.whiteSpace = "pre";
      // elementSpan2.innerText =  "\u2005CH₄\t  ";
      // elementSpan2.style.marginLeft = "92px"; // 调整与红色风险数的间距
      // elementDiv.appendChild(elementSpan2);

      // // 添加红色风险数和10的父元素div到content
      // content.appendChild(elementDiv);

      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      elementDiv.style.display = "flex";
      elementDiv.style.alignItems = "center";

      // 新增红色风险数的元素
      var elementSpan = document.createElement("span");
      elementSpan.innerText = "地点: ";
      elementDiv.appendChild(elementSpan);

      // 新增10的元素
      var elementSpan2 = document.createElement("span");
      elementDiv.style.whiteSpace = "pre";

      elementSpan2.innerText = "\u2005 " + info.name;
      // elementSpan2.innerText = "\t1 \t\t0";
      elementSpan2.style.marginLeft = "20px"; // 调整与红色风险数的间距
      elementDiv.appendChild(elementSpan2);

      // 添加红色风险数和10的父元素div到content
      content.appendChild(elementDiv);

      // //

      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      elementDiv.style.display = "flex";
      elementDiv.style.alignItems = "center";

      // 新增红色风险数的元素
      var elementSpan = document.createElement("span");
      elementSpan.innerText = "流量: ";
      elementDiv.appendChild(elementSpan);

      // 新增10的元素
      var elementSpan2 = document.createElement("span");
      elementDiv.style.whiteSpace = "pre";
      elementSpan2.innerText = "\u2005" + info.value;
      // elementSpan2.innerText = "\t1 \t\t0";
      elementSpan2.style.marginLeft = "20px"; // 调整与红色风险数的间距
      elementDiv.appendChild(elementSpan2);

      // 添加红色风险数和10的父元素div到content
      content.appendChild(elementDiv);

      //     var elementDiv = document.createElement("div");
      // elementDiv.className = "markerText";
      // elementDiv.style.display = "flex";
      // elementDiv.style.alignItems = "center";

      // // 新增红色风险数的元素
      // var elementSpan = document.createElement("span");
      // elementSpan.innerText = "黄色风险数: ";
      // elementDiv.appendChild(elementSpan);

      // // 新增10的元素
      // var elementSpan2 = document.createElement("span");
      // elementDiv.style.whiteSpace = "pre";
      //  elementSpan2.innerText =  "\u2005 0 ";
      // // elementSpan2.innerText = "\t1 \t\t0";
      // elementSpan2.style.marginLeft = "20px"; // 调整与红色风险数的间距
      // elementDiv.appendChild(elementSpan2);

      // // 添加红色风险数和10的父元素div到content
      // content.appendChild(elementDiv);
      //     var elementDiv = document.createElement("div");
      // elementDiv.className = "markerText";
      // elementDiv.style.display = "flex";
      // elementDiv.style.alignItems = "center";

      // // 新增红色风险数的元素
      // var elementSpan = document.createElement("span");
      // elementSpan.innerText = "蓝色风险数: ";
      // elementDiv.appendChild(elementSpan);

      // // 新增10的元素
      // var elementSpan2 = document.createElement("span");
      // elementDiv.style.whiteSpace = "pre";
      //  elementSpan2.innerText =  "\u2005 0 ";
      // // elementSpan2.innerText = "\t1 \t\t0";
      // elementSpan2.style.marginLeft = "20px"; // 调整与红色风险数的间距
      // elementDiv.appendChild(elementSpan2);

      // // 添加红色风险数和10的父元素div到content
      // content.appendChild(elementDiv);

      // //新增div元素
      // var elementDiv = document.createElement("div");
      // elementDiv.className = "markerText";
      // //elementDiv.innerText = info.att.text;
      // // this.setInnerText(elementDiv, "时间：" + info.time);
      // this.setInnerText(elementDiv, "红色风险数:" );

      // // 为content添加div子节点
      // content.appendChild(elementDiv);

      // //新增div元素
      // var elementDiv = document.createElement("div");
      // elementDiv.className = "markerText";
      // //elementDiv.innerText = info.att.text;
      // // this.setInnerText(elementDiv, "类别：" + info.value);
      // this.setInnerText(elementDiv, "红色风险数：" );
      // // 为content添加div子节点
      // content.appendChild(elementDiv);
      // //新增div元素
      // var elementDiv = document.createElement("div");
      // elementDiv.className = "markerText";

      // //elementDiv.innerText = info.att.text;
      // // this.setInnerText(elementDiv, "地点：" + info.status);
      // this.setInnerText(elementDiv, "红色风险数：" );
      // // 为content添加div子节点
      // content.appendChild(elementDiv);
    },
    styles1(index, name) {
      var styles1 = {
        A3: new Style({
          image: new Icon({
            anchor: [0.5, 0.7], // 图标中心
            src: require("./blueIcon.png"),
            scale: 0.5,

            rotateWithView: true,
          }),
          text: new Text({
            //位置
            textAlign: "bottom",
            //基准线
            textBaseline: "middle",
            //文字样式
            font: "normal 35px 微软雅黑",
            //文本内容
            offsetX: 20,
            offsetY: 20,
            text: name,
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        B3: new Style({
          image: new Icon({
            anchor: [0.5, 0.5], // 图标中心
            src: require("./blueIcon.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
        }),
      };
      return styles1(index);
    },
    createMark() {
      var features = new Array();

      for (var i = 0; i < this.data.length; i++) {
        let Ary = new ol.Feature({
          geometry: new ol.geom.Point(this.data[i].geo),
          value: this.data[i].value,

          status: "欣葆家园",
          name: this.data[i].name,

          pintName: "A3",
          time: "2022.12.15 17:53:08",
          type: this.data[i].point_location,
        });

        features.push(Ary);

        // features.push(
        //   new ol.Feature({
        //     geometry: new ol.geom.Point(this.data[i].geo),
        //   })
        // );
      }

      // 矢量要素数据源
      var source = new ol.source.Vector({
        features: features,
      });

      // 聚合标注数据源
      var clusterSource = new ol.source.Cluster({
        distance: 40, //这个是通过 distance 来控制两个点聚合的间距
        source: source,
      });

      var styles1 = {
        A3: new Style({
          image: new Icon({
            anchor: [0.5, 0.7], // 图标中心
            src: require("./blueIcon.png"),
            scale: 0.5,

            rotateWithView: true,
          }),
          text: new Text({
            //位置
            textAlign: "bottom",
            //基准线
            textBaseline: "middle",
            //文字样式
            font: "normal 35px 微软雅黑",
            //文本内容
            offsetX: 20,
            offsetY: 20,
            text: " 123",
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        B3: new Style({
          image: new Icon({
            anchor: [0.5, 0.5], // 图标中心
            src: require("./blueIcon.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
        }),
      };
      var that = this;
      var clusters = new ol.layer.Vector({
        // distance: 40, //这个是通过 distance 来控制两个点聚合的间距
        source: source,

        style: (feature) => {
          if (feature.get("type") == "B1") {
            return new Style({
              image: new Icon({
                anchor: [0.5, 0.8], // 图标中心
                src: require("./icon/位置 (3).png"),
                scale: 0.3,

                rotateWithView: true,
              }),
              text: new Text({
                //位置
                textAlign: "bottom",
                //基准线
                textBaseline: "middle",
                //文字样式
                font: "normal 35px 微软雅黑",
                //文本内容
                offsetX: 8,
                offsetY: 30,
                text: feature.get("name"),
                //文本填充样式（即文字颜色）
                fill: new ol.style.Fill({ color: "#000000" }),
                stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
              }),
            });
          }
          if (feature.get("type") == "A3") {
            let offseY = 0;
            if (feature.get("name") == "114" || feature.get("name") == "58") {
              offseY = -55;
            } else {
              offseY = 30;
            }
            return new Style({
              image: new Icon({
                anchor: [0.5, 0.8], // 图标中心
                src: require("./icon/位置 (1).png"),
                scale: 0.3,

                rotateWithView: true,
              }),
              text: new Text({
                //位置
                textAlign: "bottom",
                //基准线
                textBaseline: "middle",
                //文字样式
                font: "normal 35px 微软雅黑",
                //文本内容
                offsetX: 25,

                offsetY: offseY,
                text: feature.get("name"),
                //文本填充样式（即文字颜色）
                fill: new ol.style.Fill({ color: "#000000" }),
                stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
              }),
            });
          }
          if (feature.get("type") == "B3") {
            return new Style({
              image: new Icon({
                anchor: [0.4, 0.8], // 图标中心
                src: require("./icon/位置 (2).png"),
                scale: 0.3,

                rotateWithView: true,
              }),
              text: new Text({
                //位置
                textAlign: "bottom",
                //基准线
                textBaseline: "middle",
                //文字样式
                font: "normal 35px 微软雅黑",
                //文本内容
                offsetX: 20,
                offsetY: 30,
                text: feature.get("name"),
                //文本填充样式（即文字颜色）
                fill: new ol.style.Fill({ color: "#000000" }),
                stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
              }),
            });
          }
        },

        zIndex: 999,
      });

      this.map.addLayer(clusters);
      // 弹窗

      //   this.map.on("singleclick", (e) => {
      //     let elPopup = this.$refs.popup;
      //     var popup = new ol.Overlay({
      //       element: elPopup,
      //       positioning: "bottom-center",
      //       stopEvent: false,
      //       // 信息框的上下位置
      //       offset: [0, 30],
      //     });
      //     this.map.addOverlay(popup);
      //     console.log(e.pixel)
      //     let feature = this.map.forEachFeatureAtPixel(
      //       e.pixel,
      //       (feature) => feature
      //     );
      //     console.log(feature.values_);
      //     if (feature) {
      //       let coordinates = feature.getGeometry().getCoordinates();
      //       // console.log(coordinates)
      //       setTimeout(() => {
      //         var content = document.getElementById("popup-content");
      //         content.innerHTML = "";
      //         this.show = true;
      //         //在popup中加载当前要素的具体信息
      //         this.addFeatrueInfo(feature.values_);

      //         popup.setPosition(coordinates);
      //       }, 0);
      //     } else {
      //       this.show = false;
      //     }
      //   });
    },

    // 初始化地图
    // initMap() {
    //   this.map = new Map({
    //     layers: [
    //       new TileLayer({
    //     extent: [37467916, 3964896.75, 37478080, 3972216.5],
    //      source: new TileWMS({
    //       url: "http://120.53.249.144:8080/geoserver/wms",
    //       params: { LAYERS: "webgis:cad_polyline" },
    //       serverType: "geoserver",
    //     }),

    //   })
    //     ],
    //     target: "map",
    //     view: new View({
    //        center: [37477916, 3968896.2],
    //        projection: 'EPSG:3857',
    //       zoom: 14,
    //     }),
    //   });
    // },

    addLayer() {
      // 加载 GeoServer 发布的 wms 服务
      let wmsLayer = new TileLayer({
        extent: [
          // 边界
          97.350096, 26.045865, 108.546488, 34.312446,
        ],
        source: new TileWMS({
          //上线后，记得要把url: 'http://localhost:8090/geoserver/ws-world/wms'中的localhost换成云服务器的ip地址！！
          url: "http://120.76.197.111:8090/geoserver/keshan/wms",
          params: { LAYERS: "keshan:sichuan", TILED: true },
          serverType: "geoserver",
        }),
        visible: true,
        zIndex: 2,
      });
      this.map.addLayer(wmsLayer);
    },
  },
};
</script>

<style scoped>
.label {
  font-size: 20px;
}
.title_i {
  position: absolute;
  left: 10%;
  top: 50%;
  font-size: 30px;
  transform: translate(-50%, -50%);
  color: rgb(156, 149, 149);
  background-color: rgb(156, 149, 149);
}

#title {
  border-radius: 10px;
  top: 10%;
  left: 35%;
  bottom: 3%;
  position: absolute;
  float: left;
  font-size: 30px;
  width: 35%;
  background-color: rgb(255, 255, 255);
  height: 9%;
  text-align: center;
}
</style>

