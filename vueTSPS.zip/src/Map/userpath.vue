<template>
  <div class="path">
    <span>用户</span>
    <el-select
      v-model="value"
      filterable
      placeholder="用户"
      style="width: 20%"
      @change="get"
    >
      <el-option
        v-for="item in options"
        :key="item.value"
        :label="item.label"
        :value="item.label"
      >
      </el-option>
    </el-select>

    <label for="speed">
      speed:&nbsp;
      <input id="speed" type="range" min="10" max="999" step="10" value="60" />
    </label>
    <el-button id="start-animation">开始</el-button>
    <el-button id="pause-animation">暂停</el-button>
    <el-button id="continue-animation">继续</el-button>
    <el-button id="stop-animation">结束</el-button>
    <div id="map" />
  </div>
</template>

<script>
import Feature from "ol/Feature";
import map from "ol/Map";
import Point from "ol/geom/Point";
import Polyline from "ol/format/Polyline";
import VectorSource from "ol/source/Vector";
import View from "ol/View";
import OSM from "ol/source/OSM";
import LineString from "ol/geom/LineString";
import Style from "ol/style/Style";
import Icon from "ol/style/Icon";
import Stroke from "ol/style/Stroke";
import TileLayer from "ol/layer/Tile";
import VectorLayer from "ol/layer/Vector";
import axios from "axios";
import ol from "../utils/ol5/ol";
import qs from "qs";
export default {
  data() {
    return {
      options: [
        {
          value: "选项1",
          label: "zhangsan",
        },
        {
          value: "选项2",
          label: "admin",
        },
      ],
      value: "",
      center: [116.4, 40.11344786567153],
      map: null,

      route: null,
      routes: null,
      routeLength: 0,
      routeCoords: [],
      routeCoordsX: [],
      routeCoordsY: [],
      routeFeature: null,
      geoMarker: null,
      startMarker: null,
      endMarker: null,
      styles: {},
      animating: false,
      vectorLayer: null,
      speed: undefined,
      startTime: undefined,
      speedInput: undefined,
      startButton: undefined,
      stoptime: null,
      timer: null,
      elapsedTime: 0,
      timerFlag: false,
      index: 0,
      getdata: null,
    };
  },
  mounted() {
    // this.get()
    this.initMap();
  },
  methods: {
    async get() {
      var param = qs.stringify({
        data: this.value,
      });
      const { data: ret } = await axios.post(
        "http://127.0.0.1:8000/api/test1",
        param
      );

      this.getdata = ret.data["data"];
      //
      
      if (this.vectorLayer) this.map.removeLayer(this.vectorLayer);
      this.movepath();

      this.startButton.addEventListener("click", this.startAnimation, false);
      this.pauseButton.addEventListener("click", this.pauseAnimation, false);
      this.continueButton.addEventListener(
        "click",
        this.continueAnimation,
        false
      );
      this.stopButton.addEventListener("click", this.stopAnimation, false);
    },
    initMap() {
      // console.log(  this.getdata)
      const that = this;
      var seamap = new TileLayer({
        source: new OSM(),
      });
      this.map = new map({
        target: "map",
        view: new View({
          center: this.center,
          projection: "EPSG:4326",
          zoom: 14,
          minZoom: 2,
          maxZoom: 18,
        }),
        layers: [seamap],
      });
      // this.movepath()
    },
    movepath() {
      this.routeCoords = [];
      const that = this;

      var x = this.getdata.map((item) => {
        return parseFloat(item[0]);
      });

      var y = this.getdata.map((item) => {
        return parseFloat(item[1]);
      });

      for (var i = 0; i < this.getdata.length; i++) {
        this.routeCoords.push([x[i], y[i]]);
      }

      this.center = this.routeCoords[0];
      // 矢量元素要呈现的几何图形的特征属性LineString代表线段
      this.routes = new LineString(this.routeCoords);
      console.log(this.getdata);
      this.routeLength = this.routeCoords.length;
      this.routeFeature = new Feature({
        type: "route",
        geometry: this.routes,
      });
      console.log(this.routeFeature);
      this.geoMarker = new Feature({
        type: "geoMarker",
        geometry: new Point(this.routeCoords[0]),
      });
      this.startMarker = new Feature({
        type: "iconStart",
        geometry: new Point(this.routeCoords[0]),
      });
      this.endMarker = new Feature({
        type: "iconEnd",
        geometry: new Point(this.routeCoords[this.routeLength - 1]),
      });
      this.styles = {
        route: new Style({
          stroke: new Stroke({
            width: 6,
            color: [237, 212, 0, 0.8],
          }),
        }),
        iconStart: new Style({
          image: new Icon({
            anchor: [0.5, 0.5],
            scale: 0.2,
            src: require("./img/start.png"),
          }),
        }),
        iconEnd: new Style({
          image: new Icon({
            anchor: [0.5, 0.5],
            scale: 0.2,
            src: require("./img/target.png"),
          }),
        }),
        geoMarker: new Style({
          image: new Icon({
            anchor: [0.5, 0.5], // 图标中心
            src: require("./img/foot.png"),
            scale: 0.1,
            rotation: -Math.atan2(
              this.routeCoords[0][1] - this.routeCoords[1][1],
              this.routeCoords[0][0] - this.routeCoords[1][0]
            ),
            rotateWithView: true,
          }),
        }),
      };
      this.vectorLayer = new VectorLayer({
        source: new VectorSource({
          features: [
            this.routeFeature,
            this.geoMarker,
            this.startMarker,
            this.endMarker,
          ],
        }),
        style: function (feature) {
          if (that.animating && feature.get("type") === "geoMarker") {
            return null;
          }
          return that.styles[feature.get("type")];
        },
      });
      this.map.addLayer(this.vectorLayer);
      this.speedInput = document.getElementById("speed");
      this.startButton = document.getElementById("start-animation");
      this.pauseButton = document.getElementById("pause-animation");
      this.continueButton = document.getElementById("continue-animation");
      this.stopButton = document.getElementById("stop-animation");
    },
    moveFeature(event) {
      if (!this.vectorLayer.getVisible()) {
        this.vectorLayer.setVisible(true);
      }
      var carStyle, rotation;
      // 开始动画
      this.elapsedTime++; // elapsedTime 已过时间
      console.log(this.speed);
      this.index = Math.round((Number(this.speed) * this.elapsedTime) / 60); // 已经走了多少个点
      var x, y;
      if (this.index >= this.routeCoords.length) {
        clearInterval(this.timer);
        return;
      }
      if (this.routeCoords[this.index] && this.routeCoords[this.index + 1]) {
        x =
          this.routeCoords[this.index][0] - this.routeCoords[this.index + 1][0];
        y =
          this.routeCoords[this.index][1] - this.routeCoords[this.index + 1][1];
        // 返回从原点(0,0)到(x,y)点的线段与x轴正方向之间的弧度值
        rotation = Math.atan2(y, x);
      } else {
        rotation = 0;
      }
      carStyle = new Style({
        image: new Icon({
          src: require("./img/foot.png"),
          rotateWithView: false,
          rotation:
            -rotation +
            Math.atan2(
              this.routeCoords[0][1] - this.routeCoords[1][1],
              this.routeCoords[0][0] - this.routeCoords[1][0]
            ) /
              2,
          scale: 0.2,
          anchor: [0.5, 0.5], // 图标中心
        }),
      });
      console.log(this.routeCoords);
      var line = new Feature({
        geometry: new LineString(this.routeCoords),
      });
      var lineStyle = new Style({
        stroke: new Stroke({
          width: 10,
          color: [237, 212, 0, 0.8],
        }),
      });
      line.setStyle(lineStyle);
      var currentPoint = new Point(this.routeCoords[this.index]);
      // 添加矢量元素
      var feature = new Feature(currentPoint);
      this.vectorLayer.getSource().clear();
      feature.setStyle(carStyle);

      this.vectorLayer.getSource().addFeature(this.routeFeature);
      this.vectorLayer.getSource().addFeature(this.startMarker);
      this.vectorLayer.getSource().addFeature(this.endMarker);
      this.vectorLayer.getSource().addFeature(feature);
      this.map.render();
    },
    startAnimation() {
      this.animating = true;
      this.startTime = new Date().getTime();
      this.speed = this.speedInput.value;
      // 隐藏geoMarker
      this.geoMarker.changed();
      this.map.getView().setCenter(this.center);
      // 添加事件，地图渲染时触发
      if (this.timer) {
        clearInterval(this.timer);
      }
      this.timer = setInterval(() => {
        this.moveFeature();
      }, 60);
      this.elapsedTime = 0;
    },
    pauseAnimation() {
      clearInterval(this.timer);
      this.timerFlag = true;
    },
    continueAnimation() {
      if (this.timerFlag) {
        this.map.getView().setCenter(this.center);
        // 添加事件，地图渲染时触发
        this.timer = setInterval(() => {
          this.moveFeature();
        }, 60);
      }
      this.timerFlag = false;
    },
    stopAnimation(ended) {
      clearInterval(this.timer);
      this.vectorLayer.getSource().clear();
      this.vectorLayer.getSource().addFeature(this.routeFeature);
      this.vectorLayer.getSource().addFeature(this.startMarker);
      this.vectorLayer.getSource().addFeature(this.endMarker);
    },
  },
};
</script>

<style>
.path {
  width: 100%;
  height: 100%;
}
#map {
  width: 100%;
  height: 100%;
}
</style>

