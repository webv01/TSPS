<template>
  <div id="mapCon">
    <!-- Popup 设置弹窗样式-->
    <div id="popup" class="ol-popup" ref="popup" v-show="show">
      <a href="#" id="popup-closer" class="ol-popup-closer"></a>
      <div id="popup-content"></div>
    </div>
  </div>
</template>
<script>
// import img1 from "../../src/assets/blueIcon.png";
import axios from 'axios'
import "ol/ol.css";
import ol from "../utils/ol5/ol";
import { Stroke, Style, Circle, Fill, Text } from "ol/style";
import proj4 from "proj4";
export default {
  name: "",

  data() {
    return {
      show: false,
      map: {},
      data: {},
    };
  },
  mounted() {
    this.getData();
    this.initMap();
  },

  methods: {
    initMap() {
      /**
       *   // 自定义坐标系
       */
      var projection_2362 = new ol.proj.Projection({
        code: "EPSG:2362",
        extent: [38344577.81, 2381399.02, 38617340.68, 5036052.73],
        units: "m",
        axisOrientation: "neu",
      });
      proj4.defs(
        "EPSG:2362",
        "+proj=tmerc +lat_0=0 +lon_0=114 +k=1 +x_0=38500000 +y_0=0 +a=6378140 +b=6356755.288157528 +units=m +no_defs"
      );
      //结合proj4在ol3中自定义坐标系,以4326为例(3857同理)
      ol.proj.addProjection(projection_2362);
      ol.proj.addCoordinateTransforms(
        "EPSG:4326",
        "EPSG:2362",
        function (coordinate) {
          return proj4("EPSG:4326", "EPSG:2362", coordinate);
        },
        function (coordinate) {
          return proj4("EPSG:2362", "EPSG:4326", coordinate);
        }
      );
      console.log(
        ol.proj.transform([37473426.9, 3968134.2], "EPSG:2362", "EPSG:4326")
      );
      console.log(ol.proj.transform([118, 32], "EPSG:4326", "EPSG:2362"));

      var shamp = new ol.layer.Image({
        //数据范围
        name: "注记图层",
        // extent: [37467916, 3964896.75, 37478080, 3972216.5],
        source: new ol.source.ImageWMS({
          //WMS服务基地址
     				url: 'http://127.0.0.1:8080/geoserver/wms',
               					//图层参数123
               					params: {
               						'LAYERS': '	biyesheji:polyline'
          },
          //服务类型
          serverType: "geoserver",
        }),
      });
      this.map = new ol.Map({
        //地图容器div的ID
        target: "mapCon",
        //地图容器中加载的图层
        layers: [shamp],
        //地图视图设置
        view: new ol.View({
          //地图初始中心点
          center: [37473426.9, 3968134.2],
          projection: projection_2362,
          //地图初始显示级别
          zoom: 10,
        }),
        controls: ol.control.defaults().extend([
          new ol.control.MousePosition({
            target: document.getElementById("mouse-position"),
          }),
        ]),
      });



      this.setdata();
    },
    async getData() {
      // 获取服务器的数据, 对this.allData进行赋值之后, 调用updateChart方法更新图表
      // axios.post("http://127.0.0.1:8111/api/login", param)
      const { data: ret } = await axios.get("http://127.0.0.1:8000/api/pointdata")

      console.log(ret.data["geo"]);
      for (var i = 0; i < ret.data.length; i++) {
        var data = {
          id: ret.data[i]["id"],
          geo: ret.data[i]["geo"],
          data_time: ret.data[i]["create_time"],
          mine_code: "140211011523.00 ",
          point_code: "14021101152301MN000414214M10",
          point_location: ret.data[i]["point_location"],
          point_status_name: ret.data[i]["point_status_name"],
          point_value: ret.data[i]["point_value"],
          sensor_type_name: ret.data[i]["sensor_type_name"],
        };
        this.data.push(data);
      }
      console.log(this.data.length);

      this.createMark();
    },

    setdata() {
      this.data = [
        {
          geo: [37471559.8, 3967334.41],
          id:"10",
          data_time: "2020/8/2 23:44",
          mine_code: "140211011523.00 ",
          point_code: "14021101152301MN000414214M10",
          point_location: "CO 四风井副立井东侧工作面一氧化碳",
          point_status_name: "异常",
          point_value: "3.75",
          sensor_type_name: "一氧化碳",
        },
        {
          geo: [37471330.72, 3967280.86],
          data_time: "2020/8/2 23:44",
          mine_code: "140211011523.00 ",
          point_code: "14021101152301MN000414214M10",
          point_location: "CO 四风井副立井东侧工作面一氧化碳",
          point_status_name: "正常",
          point_value: "4.5",
          sensor_type_name: "一氧化碳",
          point_value2: "3",
          sensor_type_name2: "二氧华安",
        },
      ];
      console.log(this.data.length);
      // this.createMark();
    },
    setInnerText(element, text) {
      if (typeof element.textContent == "string") {
        element.textContent = text;
      } else {
        element.innerText = text;
      }
    },
    addFeatrueInfo(info) {
      var content = document.getElementById("popup-content");

      //新增a元素
      var elementA = document.createElement("a");
      elementA.className = "markerInfo";

      //elementA.innerText = info.att.title;
      this.setInnerText(elementA, "气体：" + info.name);
      // 新建的div元素添加a子节点
      content.appendChild(elementA);
      //新增div元素
      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      //elementDiv.innerText = info.att.text;
      this.setInnerText(elementDiv, "地点：" + info.pintName);
      // 为content添加div子节点
      content.appendChild(elementDiv);
      //新增div元素
      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      //elementDiv.innerText = info.att.text;
      this.setInnerText(elementDiv, "浓度：" + info.value);
      // 为content添加div子节点
      content.appendChild(elementDiv);
      //新增div元素
      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      //elementDiv.innerText = info.att.text;
      this.setInnerText(elementDiv, "状态：" + info.status);
      // 为content添加div子节点
      content.appendChild(elementDiv);
    },
    createMark() {
      var features = new Array();
      for (var i = 0; i < this.data.length; i++) {
        let Ary = new ol.Feature({
          id: this.data[i].id,
          geometry: new ol.geom.Point(this.data[i].geo),
          time: this.data[i].data_time,
          status: this.data[i].point_status_name,
          name: this.data[i].sensor_type_name,
          value: this.data[i].point_value,
          pintName: this.data[i].point_location,
        });
        features.push(Ary);
        // features.push(
        //   new ol.Feature({
        //     geometry: new ol.geom.Point(this.data[i].geo),
        //   })
        // );
      }

      // 矢量要素数据源
      var source = new ol.source.Vector({
        features: features,
      });

      // 聚合标注数据源
      var clusterSource = new ol.source.Cluster({
        distance: 0, //这个是通过 distance 来控制两个点聚合的间距
        source: source,
      });
      // 加载聚合标注的矢量图层
      var styleCache = {}; //用于保存特定数量的聚合群的要素样式
      var clusters = new ol.layer.Vector({
        source: source,
        style: (feature) => {
          var text = feature.get("name"); //这个是每个点位对应的id
          var color = "";
          // mark点的填充颜色判断
          if (feature.get("status") === "正常") {
            color = "#55ff00";
          } else {
            color = "#ff0000";
          }
          return new Style({
            image: new Circle({
              radius: 10,
              stroke: new Stroke({
                color: "#fff",
              }),
              fill: new Fill({
                color: color,
              }),
              opacity: 0.75,
            }),
            text: new Text({
              //位置
              textAlign: "center",
              //基准线
              textBaseline: "middle",
              //文字样式
              font: "normal 14px 微软雅黑",
              //文本内容
              text: feature.get("id"),
              //文本填充样式（即文字颜色）
              fill: new ol.style.Fill({ color: "#aa3300" }),
              stroke: new ol.style.Stroke({ color: "#ffcc33", width: 2 }),
            }),
          });
        },

        // style: function (feature, resolution) {
        //   var size = feature.get("features").length; //获取该要素所在聚合群的要素数量
        //   var style = styleCache[size];
        //   if (!style) {
        //     style = [
        //       new Style({
        //         image: new Circle({
        //           radius: 10,
        //           stroke: new Stroke({
        //             color: "#fff",
        //           }),
        //           fill: new Fill({
        //             color: "#3399CC",
        //           }),
        //         }),
        //       }),
        //     ];
        //   }
        //   return style;
        // },
        zIndex: 999,
      });

      this.map.addLayer(clusters);
      // 弹窗
      this.map.on("singleclick", (e) => {
        let elPopup = this.$refs.popup;
        var popup = new ol.Overlay({
          element: elPopup,
          positioning: "bottom-center",
          stopEvent: false,
          // 信息框的上下位置
          offset: [0, 30],
        });
        this.map.addOverlay(popup);
        let feature = this.map.forEachFeatureAtPixel(
          e.pixel,
          (feature) => feature
        );

        if (feature) {
          let coordinates = feature.getGeometry().getCoordinates();
          // console.log(coordinates)
          setTimeout(() => {
            var content = document.getElementById("popup-content");
            content.innerHTML = "";

            this.show = true;
             
            this.data.map((item, index) => {
              if (item.id === feature.values_.id)
                this.$store.commit("setpointValue", item);
          
            });
      
            this.$store.commit("setpointid", feature.values_.id);
            // console.log(this.$store.getters.getpointValue[feature.values_.id]["id"])
            //在popup中加载当前要素的具体信息
            this.addFeatrueInfo(feature.values_);

            popup.setPosition(coordinates);
          }, 0);
        } else {
          this.show = false;
        }
      });
    },
    // 聚合标注数据源
    clusters() {
      var features = new Array();
      for (var i = 0; i < this.data.length; i++) {
        console.log(this.data[i].point_status_name);
        let Ary = new ol.Feature({
          geometry: new ol.geom.Point(this.data[i].geo),
          time: this.data[i].data_time,
          status: this.data[i].point_status_name,
          name: this.data[i].sensor_type_name,
          value: this.data[i].point_value,
          pintName: this.data[i].point_location,
        });
        features.push(Ary);
        // features.push(
        //   new ol.Feature({
        //     geometry: new ol.geom.Point(this.data[i].geo),
        //   })
        // );
      }

      // 矢量要素数据源
      var source = new ol.source.Vector({
        features: features,
      });

      // 聚合标注数据源
      var clusterSource = new ol.source.Cluster({
        distance: 40, //这个是通过 distance 来控制两个点聚合的间距
        source: source,
      });
      // 加载聚合标注的矢量图层
      var styleCache = {}; //用于保存特定数量的聚合群的要素样式
      var clusters = new ol.layer.Vector({
        source: clusterSource,
        style: (feature) => {
          var text = feature.get("name"); //这个是每个点位对应的id
          var color = "";
          // mark点的填充颜色判断
          console.log(feature.get("status"));
          if (feature.get("status") === "正常") {
            color = "#55ff00";
          } else {
            color = "#ff0000";
          }
          return new Style({
            image: new ol.style.Icon(
              /** @type {olx.style.IconOptions} */ ({
                anchor: [0.5, 1],

                // offset: [0, 1], //偏移量设置
                scale: 0.8, //图标缩放比例
                opacity: 1, //透明度
                // src: img1,
              })
            ),
            text: new Text({
              //位置
              textAlign: "center",
              //基准线
              textBaseline: "middle",
              //文字样式
              font: "normal 14px 微软雅黑",
              //文本内容
              text: feature.get("name"),
              //文本填充样式（即文字颜色）
              fill: new ol.style.Fill({ color: "#aa3300" }),
              stroke: new ol.style.Stroke({ color: "#ffcc33", width: 2 }),
            }),
          });
        },
      });

      this.map.addLayer(clusters);

      // 弹窗
      this.map.on("singleclick", (e) => {
        let elPopup = this.$refs.popup;
        var popup = new ol.Overlay({
          element: elPopup,
          positioning: "bottom-center",
          stopEvent: false,
          // 信息框的上下位置
          offset: [0, 30],
        });
        this.map.addOverlay(popup);
        let feature = this.map.forEachFeatureAtPixel(
          e.pixel,
          (feature) => feature
        );

        if (feature) {
          let coordinates = feature.getGeometry().getCoordinates();
          if (feature.getProperties().features.length == 1) {
            setTimeout(() => {
              var content = document.getElementById("popup-content");
              content.innerHTML = "";
              this.show = true;
              //在popup中加载当前要素的具体信息
              this.addFeatrueInfo(feature.getProperties().features[0].values_);

              popup.setPosition(coordinates);
            }, 0);
            console.log(feature.getProperties().features[0].values_);
          } else {
            //有多个要素
            var content = document.getElementById("popup-content");
            content.innerHTML = "多标记聚合！";
            this.show = true;
            popup.setPosition(coordinates);
          }
        } else {
          this.show = false;
        }
      });
    },
  },
};
</script>
<style lang="less" scoped>
#mapCon {
  width: 100%;
  height: 95%;
  // position: absolute;
}

.ol-popup {
  // position: absolute;
  background-color: white;
  -webkit-filter: drop-shadow(0 1px 4px rgba(0, 0, 0, 0.2));
  filter: drop-shadow(0 1px 4px rgba(0, 0, 0, 0.2));
  padding: 15px;
  border-radius: 10px;
  border: 1px solid #cccccc;
  bottom: 45px;
  left: -50px;
}

.ol-popup:after,
.ol-popup:before {
  top: 100%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  // position: absolute;
  pointer-events: none;
}

.ol-popup:after {
  border-top-color: white;
  border-width: 10px;
  left: 48px;
  margin-left: -10px;
}

.ol-popup:before {
  border-top-color: #cccccc;
  border-width: 11px;
  left: 48px;
  margin-left: -11px;
}

.ol-popup-closer {
  text-decoration: none;
  // position: absolute;
  top: 2px;
  right: 8px;
}

.ol-popup-closer:after {
  content: "✖";
}

#popup-content {
  font-size: 14px;
  font-family: "微软雅黑";
  width: 300px;
}

#popup-content .markerInfo {
  font-weight: bold;
}
</style>