<template>
  <div>
    <div id="mapCon">
      <!-- <div class="column1" style="position: relative">
  
        <img
          src="./img/地图.png"
          alt=""
          style="position: relative"
        />
      </div> -->
      <!-- Popup -->
      <div id="popup" class="ol-popup" ref="popup" v-show="show">
        <a href="#" id="popup-closer" class="ol-popup-closer"></a>
        <div id="popup-content"></div>
      </div>
    </div>
    <div id="title">
      <div>
        <div style="top: 10%; left: 12%; font-size: 20px; text-align: left">
          今日信息
        </div>
      </div>

      <div style="left: 0%; hight: 20%; position: relative">
        <el-input
          placeholder="请输入地点/经纬度：113.25，30.53"
          v-model="input2"
          style="width: 80%; left: 10px; top: 15px; position: absolute"
        >
        </el-input>
        <i
          class="el-icon-search"
          style="float: right; right: 30px; top: 20px; position: relative"
        ></i>
      </div>
      <el-button
        type="primary"
        plain
        icon="el-icon-search"
        style="width: 35%; left: 15%; top: 85px; position: absolute"
        >兴趣区域/时间</el-button
      >
      <el-button
        type="primary"
        icon="el-icon-search"
        style="width: 30%; right: 15%; top: 85px; position: absolute"
        >高级搜索</el-button
      >

      <el-form
        ref="form"
        :model="form"
        label-width="80px"
        style="top: 120px; position: absolute"
      >
        <el-form-item label="用户检索" style="top: 50px; position: relative">
          <el-select
            placeholder="请选择行政区域"
            style="left: 0%; width: 60%; position: absolute"
          >
            <el-option label="71265"></el-option>
            <el-option label="71265" value="71265"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="行政区域" style="top: 50px; position: relative">
          <el-select
            v-model="form.region"
            placeholder="请选择行政区域"
            style="left: 0%; width: 60%; position: absolute"
          >
            <el-option label="上海" value="shanghai"></el-option>
            <el-option label="北京" value="beijing"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="时间范围" style="top: 60px; position: relative">
          <el-col :span="10">
            <el-date-picker
              type="date"
              placeholder="选择日期"
              v-model="form.date1"
              style="width: 100%"
            ></el-date-picker>
          </el-col>
          <el-col class="line" :span="2">-</el-col>
          <el-col :span="10">
            <el-date-picker
              placeholder="选择日期"
              v-model="form.date2"
              style="width: 100%"
            ></el-date-picker>
          </el-col>
        </el-form-item>

        <el-form-item label="地图资源" style="top: 70px; position: relative">
          <el-radio-group v-model="form.resource">
            <el-radio label="openstreemap"></el-radio>
            <el-radio label="百度地图"></el-radio>
            <el-radio label="高德地图"></el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item style="right: 50px; top: 80px; position: relative">
          <el-button type="primary" @click="onSubmit">查询</el-button>
          <el-button>取消</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
import "../assets/index.css";
import "../assets/flexible";
import "ol/ol.css";
import Map from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import TileWMS from "ol/source/TileWMS";
import XYZ from "ol/source/XYZ";
import OSM from "ol/source/OSM";
import ol from "../utils/ol5/ol";
import { Icon, Stroke, Style, Circle, Fill, Text } from "ol/style";
import proj4 from "proj4";
import LineString from "ol/geom/LineString";
export default {
  name: "",

  data() {
    return {
      form: {
        name: "",
        region: "",
        date1: "",
        date2: "",
        delivery: false,
        type: [],
        resource: "",
        desc: "",
      },

      show: false,
      map: {},
      data: {},
      url1: require("./img/84-虚线 (1).png"),
      url2: require("./img/直线.png"),
      url3: require("./img/84-虚线.png"),
      url4: require("./img/直线 (1).png"),
    };
  },
  mounted() {
    this.initMap();
  },
  methods: {
    initMap() {
      var shamp = new ol.layer.Image({
        //数据范围
        name: "注记图层",
        // extent: [37467916, 3964896.75, 37478080, 3972216.5],
        source: new ol.source.ImageWMS({
          //WMS服务基地址
          url: "http://127.0.0.1:8080/geoserver/wms",
          //图层参数123
          params: {
            LAYERS: "	beijing:中华人民共和国",
          },
          //服务类型
          serverType: "geoserver",
        }),
      });
      var gaodeMapLayer = new ol.layer.Tile({
        title: "高德地图",
        source: new ol.source.XYZ({
          //url:"http://t0.tianditu.com/DataServer?T=img_w&x={x}&y={y}&l={z}",
          url: "http://t4.tianditu.com/DataServer?T=img_w&tk=4a76fd399e76e3e984e82953755c3410&x={x}&y={y}&l={z}",
          //url: " https://tile.openstreetmap.org/{z}/{x}/{y}.png",
          wrapX: false,
        }),
      });

      this.map = new ol.Map({
        layers: [gaodeMapLayer, shamp],
        view: new ol.View({
          center: [116.3033105, 39.76206835],

          zoom: 8, // 设置初始化时的地图缩放层级
          projection: "EPSG:4326", // 坐标系
        }),
        target: "mapCon", // 地图dom
      });
      this.setdata();
      // this.showPoint();
    },
    showPoint() {
      var features = new Array();
      var routerline1 = [
        [116.2806817, 39.8043734],
        [116.282464, 39.80360237],
        [116.2842108, 39.80285155],
        [116.284378, 39.80427615],
        [116.2839092, 39.8055331],
        [116.2856848, 39.80621301],
        [116.2878576, 39.80609564],
        [116.2912864, 39.8054335],
        [116.2941725, 39.80535867],
        [116.2947095, 39.80379635],
        [116.2962653, 39.7993066],
        [116.2974985, 39.79609965],
        [116.2977674, 39.79617291],
        [116.3030222, 39.79747475],
        [116.3077744, 39.79531225],
        [116.3077634, 39.7917141],
        [116.307707, 39.78919265],
        [116.3076569, 39.78770395],
        [116.30971, 39.78503319],
        [116.3127417, 39.78297645],
        [116.314533, 39.78242761],
        [116.3163071, 39.7819045],
        [116.3163518, 39.7819527],
        [116.3163074, 39.78202085],
        [116.3160168, 39.78209926],
        [116.3143348, 39.78260295],
        [116.3128454, 39.78308325],
        [116.3127295, 39.7830612],
        [116.3107287, 39.78017583],
        [116.3092531, 39.776915],
        [116.3081801, 39.77428305],
        [116.3065658, 39.7702458],
        [116.3059543, 39.7686888],
        [116.3052799, 39.76705899],
        [116.3039856, 39.763803],

        [116.3033105, 39.76206835],
      ];
      var routerline2 = [
        [-73.95588028, 40.65137012],
        [-73.95580198, 40.65054242],
        [-73.95247241, 40.65069902],
        [-73.9529385, 40.655197],
        [-73.9471178, 40.6555738],
        [-73.9473585, 40.6572838],
      ];

      var routerline3 = [
        [-73.95591997, 40.65136838],
        [-73.95004012, 40.65515705],
        [-73.9473446, 40.6572663],
      ];
      var routerline4 = [
        [-73.95588028, 40.65137012],
        [-73.9504903, 40.6553856],
        [-73.9473585, 40.6572838],
      ];

      var routeFeature = new ol.Feature({
        type: "route1",
        geometry: new ol.geom.LineString(routerline2),
      });
      var routeFeature1 = new ol.Feature({
        type: "route2",
        geometry: new ol.geom.LineString(routerline1),
      });
      var routeFeature2 = new ol.Feature({
        type: "route3",
        geometry: new ol.geom.LineString(routerline3),
      });
      var routeFeature3 = new ol.Feature({
        type: "route4",
        geometry: new ol.geom.LineString(routerline4),
      });

      var startMarker = new ol.Feature({
        type: "iconStart",
        geometry: new ol.geom.Point(routerline2[0]),
      });

      var source = new ol.source.Vector({
        features: [
          routeFeature,
          startMarker,
          routeFeature1,
          routeFeature2,
          routeFeature3,
        ],
      });
      var styles = {
        route1: new Style({
          stroke: new Stroke({
            width: 4,
            color: "#009000",
          }),
        }),
        route2: new Style({
          stroke: new Stroke({
            width: 8,
            color: "#008000",
          }),
        }),
        route3: new Style({
          stroke: new Stroke({
            width: 4,
            color: "#0000ff",
            lineDash: [5, 5, 5, 5],
          }),
        }),
        route4: new Style({
          stroke: new Stroke({
            width: 4,
            color: "#fc0000",
            lineDash: [5, 5, 5, 5],
          }),
        }),
        iconStart: new Style({
          image: new Icon({
            anchor: [0.5, 0.5], // 图标中心
            src: require("./img/blueIcon.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
        }),
      };
      this.clusters = new ol.layer.Vector({
        source: new ol.source.Vector({
          features: [routeFeature, routeFeature1, routeFeature2, routeFeature3],
        }),
        style: function (feature) {
          return styles[feature.get("type")];
        },
      });
      this.map.addLayer(this.clusters);
    },
    setdata() {
      this.data = [
        {
          geo: [116.2806817, 39.8043734],
          point_location: "A3",

          point_status_name: "欣葆家园",
          point_value: "住宅",
          sensor_type_name: "71262",
        },
        {
          geo: [116.3033105, 39.76206835],
          point_location: "B3",
          point_status_name: "超市、商场。美食、电影院",
          point_value: "景区",
          sensor_type_name: "71265",
        },
        {
          geo: [116.797, 36.469],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
        {
          geo: [120.5207, 40.9485],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },

        {
          geo: [112.695, 42.265],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
        {
          geo: [112.41, 38.155],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
        {
          geo: [108.895, 39.908],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
        {
          geo: [105.977, 37.375],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
        {
          geo: [99.149, 36.0],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
        {
          geo: [89.168, 37.04],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
        {
          geo: [101.732, 32.46],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
        {
          geo: [108.191, 28.317],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
        {
          geo: [99.149, 36.0],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
        {
          geo: [118.172, 36.889],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
        {
          geo: [99.149, 36.0],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
        {
          geo: [125.0, 43.934],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "71285",
        },
      ];

      this.createMark();
    },
    setInnerText(element, text) {
      if (typeof element.textContent == "string") {
        element.textContent = text;
      } else {
        element.innerText = text;
      }
    },
    addFeatrueInfo(info) {
      var content = document.getElementById("popup-content");

      //新增a元素
      var elementA = document.createElement("a");
      elementA.className = "markerInfo";

      //elementA.innerText = info.att.title;
      this.setInnerText(elementA, "ID：" + info.name);
      // 新建的div元素添加a子节点
      content.appendChild(elementA);
      //新增div元素
      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      //elementDiv.innerText = info.att.text;
      this.setInnerText(elementDiv, "时间：" + info.time);
      // 为content添加div子节点
      content.appendChild(elementDiv);
      //新增div元素
      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      //elementDiv.innerText = info.att.text;
      this.setInnerText(elementDiv, "类别：" + info.value);
      // 为content添加div子节点
      content.appendChild(elementDiv);
      //新增div元素
      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      //elementDiv.innerText = info.att.text;
      this.setInnerText(elementDiv, "地点：" + info.status);
      // 为content添加div子节点
      content.appendChild(elementDiv);
    },
    createMark() {
      var features = new Array();
      for (var i = 0; i < this.data.length; i++) {
        let Ary = new ol.Feature({
          geometry: new ol.geom.Point(this.data[i].geo),

          status: this.data[i].point_status_name,
          name: this.data[i].sensor_type_name,
          value: this.data[i].point_value,
          pintName: this.data[i].point_location,
          time: "2022.12.15 17:53:08",
          type: this.data[i].point_location,
        });

        features.push(Ary);
        // features.push(
        //   new ol.Feature({
        //     geometry: new ol.geom.Point(this.data[i].geo),
        //   })
        // );
      }

      // 矢量要素数据源
      var source = new ol.source.Vector({
        features: features,
      });

      // 聚合标注数据源
      var clusterSource = new ol.source.Cluster({
        distance: 40, //这个是通过 distance 来控制两个点聚合的间距
        source: source,
      });
      var styles1 = {
        A1: new Style({
          image: new Circle({
            radius: 10,
            stroke: new Stroke({
              color: "#fff",
            }),
            fill: new Fill({
              color: "#55ff00",
            }),
            opacity: 0.75,
          }),
          text: new Text({
            //位置
            textAlign: "right",
            //基准线
            textBaseline: "bottom",
            //文字样式
            font: "normal 24px 微软雅黑",
            //文本内容
            offsetX: -20,
            //文本内容
            text: "A1",
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        B1: new Style({
          image: new Icon({
            anchor: [0.5, 0.5], // 图标中心
            src: require("./img/blueIcon.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
          text: new Text({
            //位置
            textAlign: "left",
            //基准线
            textBaseline: "bottom",
            font: "normal 24px 微软雅黑",
            //文本内容
            offsetX: 20,
            text: "B1",
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        A2: new Style({
          image: new Icon({
            anchor: [0.5, 0.7], // 图标中心
            src: require("./img/blueIcon.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
          text: new Text({
            //位置
            textAlign: "left",
            //基准线
            textBaseline: "middle",
            //文字样式
            font: "normal 24px 微软雅黑",
            //文本内容
            offsetX: 20,
            text: "A2",
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        B2: new Style({
          image: new Icon({
            anchor: [0.5, 0.7], // 图标中心
            src: require("./img/blueIcon.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
          text: new Text({
            //位置
            textAlign: "right",
            //基准线
            textBaseline: "middle",
            //文字样式
            font: "normal 24px 微软雅黑",
            //文本内容
            text: "  B2",
            offsetX: -20,
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        A3: new Style({
          image: new Circle({
            radius: 10,
            stroke: new Stroke({
              color: "#fff",
            }),
            fill: new Fill({
              color: "#ff0000",
            }),
            opacity: 0.75,
          }),
          text: new Text({
            //位置
            textAlign: "right",
            //基准线
            textBaseline: "bottom",
            //文字样式
            font: "normal 24px 微软雅黑",
            //文本内容
            offsetX: -20,
            text: "",
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        B3: new Style({
          image: new Circle({
            radius: 10,
            stroke: new Stroke({
              color: "#fff",
            }),
            fill: new Fill({
              color: "#55ff00",
            }),
            opacity: 0.75,
          }),
          text: new Text({
            //位置
            textAlign: "left",
            //基准线
            textBaseline: "bottom",
            //文字样式
            font: "normal 24px 微软雅黑",
            //文本内容
            offsetX: 20,
            text: " ",
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
      };

      var clusters = new ol.layer.Vector({
        // distance: 40, //这个是通过 distance 来控制两个点聚合的间距
        source: source,

        style: (feature) => {
          return styles1[feature.get("type")];
        },

        // {
        //   var text = feature.get("point_location"); //这个是每个点位对应的id
        //   var color = "";
        //   // mark点的填充颜色判断

        //   color = "#00ff00";

        //   return new Style({
        //     image: new Icon({
        //     anchor: [0.5, 0.5], // 图标中心
        //     src: require("./img/blueIcon.png"),
        //     scale: 0.5,

        //     rotateWithView: true,
        //   }),
        //     text: new Text({
        //       //位置
        //       textAlign: "bottom",
        //       //基准线
        //       textBaseline: "middle",
        //       //文字样式
        //       font: "normal 20px 微软雅黑",
        //       //文本内容
        //        text: feature.get('pintName'),
        //       //文本填充样式（即文字颜色）
        //       fill: new ol.style.Fill({ color: "#000000" }),
        //       stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
        //     }),
        //   });
        // },

        // style: function (feature, resolution) {
        //   var size = feature.get("features").length; //获取该要素所在聚合群的要素数量
        //   var style = styleCache[size];
        //   if (!style) {
        //     style = [
        //       new Style({
        //         image: new Circle({
        //           radius: 10,
        //           stroke: new Stroke({
        //             color: "#fff",
        //           }),
        //           fill: new Fill({
        //             color: "#3399CC",
        //           }),
        //         }),
        //       }),
        //     ];
        //   }
        //   return style;
        // },
        zIndex: 999,
      });

      this.map.addLayer(clusters);
      // 弹窗

      this.map.on("singleclick", (e) => {
        let elPopup = this.$refs.popup;
        var popup = new ol.Overlay({
          element: elPopup,
          positioning: "bottom-center",
          stopEvent: false,
          // 信息框的上下位置
          offset: [0, 30],
        });
        this.map.addOverlay(popup);
        console.log(e.pixel);
        let feature = this.map.forEachFeatureAtPixel(
          e.pixel,
          (feature) => feature
        );
        console.log(feature.values_);
        if (feature) {
          let coordinates = feature.getGeometry().getCoordinates();
          // console.log(coordinates)
          setTimeout(() => {
            var content = document.getElementById("popup-content");
            content.innerHTML = "";
            this.show = true;
            //在popup中加载当前要素的具体信息
            this.addFeatrueInfo(feature.values_);

            popup.setPosition(coordinates);
          }, 0);
        } else {
          this.show = false;
        }
      });
      //   this.map.on("singleclick", (e) => {
      //     let elPopup = this.$refs.popup;
      //     var popup = new ol.Overlay({
      //       element: elPopup,
      //       positioning: "bottom-center",
      //       stopEvent: false,
      //       // 信息框的上下位置
      //       offset: [0, 30],
      //     });
      //     this.map.addOverlay(popup);
      //     console.log(e.pixel)
      //     let feature = this.map.forEachFeatureAtPixel(
      //       e.pixel,
      //       (feature) => feature
      //     );
      //     console.log(feature.values_);
      //     if (feature) {
      //       let coordinates = feature.getGeometry().getCoordinates();
      //       // console.log(coordinates)
      //       setTimeout(() => {
      //         var content = document.getElementById("popup-content");
      //         content.innerHTML = "";
      //         this.show = true;
      //         //在popup中加载当前要素的具体信息
      //         this.addFeatrueInfo(feature.values_);

      //         popup.setPosition(coordinates);
      //       }, 0);
      //     } else {
      //       this.show = false;
      //     }
      //   });
    },

    // 初始化地图
    // initMap() {
    //   this.map = new Map({
    //     layers: [
    //       new TileLayer({
    //     extent: [37467916, 3964896.75, 37478080, 3972216.5],
    //      source: new TileWMS({
    //       url: "http://120.53.249.144:8080/geoserver/wms",
    //       params: { LAYERS: "webgis:cad_polyline" },
    //       serverType: "geoserver",
    //     }),

    //   })
    //     ],
    //     target: "map",
    //     view: new View({
    //        center: [37477916, 3968896.2],
    //        projection: 'EPSG:3857',
    //       zoom: 14,
    //     }),
    //   });
    // },

    addLayer() {
      // 加载 GeoServer 发布的 wms 服务
      let wmsLayer = new TileLayer({
        extent: [
          // 边界
          97.350096, 26.045865, 108.546488, 34.312446,
        ],
        source: new TileWMS({
          //上线后，记得要把url: 'http://localhost:8090/geoserver/ws-world/wms'中的localhost换成云服务器的ip地址！！
          url: "http://120.76.197.111:8090/geoserver/keshan/wms",
          params: { LAYERS: "keshan:sichuan", TILED: true },
          serverType: "geoserver",
        }),
        visible: true,
        zIndex: 2,
      });
      this.map.addLayer(wmsLayer);
    },
  },
};
</script>
<style lang="less" scoped>
.title_i {
  position: absolute;
  left: 10%;
  top: 50%;
  font-size: 30px;
  transform: translate(-50%, -50%);
  color: rgb(255, 255, 255);
}
#mapCon {
  top: 0px;
  width: 100%;
  height: 100%;
  position: relative;
  float: right;
}

#title {
  top: 10%;
  left: 2%;
  bottom: 3%;
  position: absolute;
  float: left;
  font-size: 30px;
  width: 25%;
  background-color: #fff;
  height: 70%;
  text-align: center;
}
.ol-popup {
  position: absolute;
  background-color: white;
  -webkit-filter: drop-shadow(0 1px 4px rgba(0, 0, 0, 0.2));
  filter: drop-shadow(0 1px 4px rgba(0, 0, 0, 0.2));
  padding: 15px;
  border-radius: 10px;
  border: 1px solid #cccccc;
  bottom: 45px;
  left: -50px;
}

.ol-popup:after,
.ol-popup:before {
  top: 100%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}

.ol-popup:after {
  border-top-color: white;
  border-width: 10px;
  left: 48px;
  margin-left: -10px;
}

.ol-popup:before {
  border-top-color: #cccccc;
  border-width: 11px;
  left: 48px;
  margin-left: -11px;
}

.ol-popup-closer {
  text-decoration: none;
  position: absolute;
  top: 2px;
  right: 8px;
}

.ol-popup-closer:after {
  content: "✖";
}

#popup-content {
  font-size: 14px;
  font-family: "微软雅黑";
  width: 200px;
}

#popup-content .markerInfo {
  font-weight: bold;
}
#popup-content1 {
  font-size: 14px;
  font-family: "微软雅黑";
  width: 300px;
}

#popup-content1 .markerInfo {
  font-weight: bold;
}
</style>