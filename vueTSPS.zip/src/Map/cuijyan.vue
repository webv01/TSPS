<template>
  <div>
    <div id="mapCon" style="background:#004368">
      <!-- <div class="column1" style="position: relative">
  
        <img
          src="./img/地图.png"
          alt=""
          style="position: relative"
        />
      </div> -->
      <!-- Popup -->
      <div id="popup" class="ol-popup" ref="popup" v-show="show">
        <a href="#" id="popup-closer" class="ol-popup-closer"></a>
        <div id="popup-content"></div>
      </div>
    </div>

    <div id="title" style="background:#002e42;color: white;">
      <div>
        <div
          style="
            position: relative;
            top: 20%;
            font-size: 20px;
            text-align: center;
          "
        >
          今日信息
        </div>
      </div>

      <div class="panel">
        <div class="quarter-div">
          <div
            class="quarter-divshu3"
           
          >
            308
            <br />
            <div class="txt_item">节点总数</div>
          </div>
          <div
            class="quarter-divshu3"
       
          >
            5
            <br />
            <div class="txt_item">超限次数</div>
          </div>
          <div
            class="quarter-divshu3"
  
          >
            1
            <br />
            <div class="txt_item">黄色风险</div>
          </div>
        </div>
        <div class="quarter-div">
          <div
            class="quarter-divshu3"

          >
            308
            <br />
            <div class="txt_item">已接入节点</div>
          </div>
          <div
            class="quarter-divshu3"

          >
            0
            <br />
            <div class="txt_item">橙色风险</div>
          </div>
          <div
            class="quarter-divshu3"
     
          >
            2
            <br />
            <div class="txt_item">蓝色风险</div>
          </div>
        </div>

        <div class="panel-footer"></div>
      </div>
      <div class="panel">
        <line1></line1>
        <div class="panel-footer"></div>
      </div>
      <div class="panel">
        <line2></line2>
        <div class="panel-footer"></div>
      </div>
    </div>
    <div id="title3">
      <!-- <div
        style="position: relative; top: 0%; font-size: 16px; text-align: center"
      >
        今日风险研判<br />
        车流量
      </div> -->
      <div class="quarter-div">
        <!-- <div class="circle" style="background: rgb(250, 3, 3)"></div>
       <div class="circle" style="background: rgb(250, 143, 3)"></div>
       <div class="circle" style="  background: rgb(252, 231, 44);"></div>
       <div class="circle" style="background: rgb(44, 110, 252);"></div>
       <div class="circle" style="background: rgb(68, 252, 44);"></div>
         <br> -->
      </div>
      <div class="quarter-div">
        <!-- <div style="position: relative; top: 0%; font-size: 16px; right: 50%">
          红色风险<br>橙色风险<br>黄色风险<br>蓝色风险<br>绿色风险<br>
        </div> -->
      </div>

      <!-- <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div> -->
    </div>
    <div id="title2" style="background:#002e42;color: white;">
      <div>
        <div
          style="
            position: relative;
            top: 20%;
            font-size: 20px;
            text-align: center;
          "
        >
          结果分析
          <!-- <div style="position: absolute; top: 20%; font-size: 20px; left: 10% ;">
                     <el-radio-group
            v-model="radio1"
            
          >
            <el-radio-button label="周" ></el-radio-button>
            <el-radio-button label="月"></el-radio-button>
          </el-radio-group>
          </div> -->
 
        </div>
      </div>

      <div class="panel">
        <div class="quarter-div-hen4">
          <div
            class="quarter-hen4"
            
          >
            <div
              class="txt_item"
              style="
                position: relative;
                top: 20%;
                font-size: 18px;
                text-align: center;
              "
            >
              起始
            </div>
            <br />
            <div
              class="txt_item"
              style="
                position: relative;
                top: 5%;
                font-size: 18px;
                text-align: center;
              "
            >
              节点
            </div>
            
          </div>
          
          <div class="quarter-hen4" style="font-size: 27px; width: 60%; ">
           <div class="quarter-shu2"  ><div     style="
                position: relative;
                top: 10%;
                font-size: 15px;
                text-align: center;
              ">ID</div>  <div     style="
                position: relative;
                top: 15%;
                font-size: 25px;
                text-align: center;
              ">276</div></div>
<div class="quarter-shu2" ><div     style="
                position: relative;
                top: 10%;
                font-size: 15px;
                text-align: center;
              ">名称</div> <div     style="
                position: relative;
                top: 15%;
                font-size: 20px;
                text-align: center;
              ">龙兴公交站</div></div>

          </div>
          <div
            class="quarter-hen4"
           
          >
            <div
              class="txt_item"
              style="
                position: relative;
                top: 20%;
                font-size: 18px;
                text-align: center;
              "
            >
              <!-- 拥堵 -->
            </div>
            <br />
            <div
              class="txt_item"
              style="
                position: relative;
                top: 9%;
                font-size: 18px;
                text-align: center;
              "
            >
              <!-- 超限 -->
            </div>
          </div>
           <div class="quarter-hen4" style="font-size: 27px;  ">
            
           <!-- <div class="quarter-shu2"  ><div     style="
                position: relative;
                top: 5%;
                font-size: 17px;

                text-align: center;
              ">已处理</div > <div     style="
                position: relative;
                top: 8%;
                font-size: 28px;
                text-align: center;
              ">53</div></div>
<div class="quarter-shu2" ><div     style="
                position: relative;
                top: 5%;
                font-size: 17px;
                text-align: center;
              ">未处理</div> <div     style="
                position: relative;
                top: 8%;
                font-size: 28px;
                text-align: center;
              ">3</div></div> -->

          </div>

        </div>

        <div class="panel-footer"></div>
      </div>
      <div class="panel">
        <div class="quarter-div-hen4">
          <div
            class="quarter-hen4"
            
          >
            <div
              class="txt_item"
              style="
                position: relative;
                top: 20%;
                font-size: 18px;
                text-align: center;
              "
            >
              目标
            </div>
            <br />
            <div
              class="txt_item"
              style="
                position: relative;
                top: 5%;
                font-size: 18px;
                text-align: center;
              "
            >
              节点
            </div>
            
          </div>
          
          <div class="quarter-hen4" style="font-size: 27px; width: 60%; ">
           <div class="quarter-shu2"  ><div     style="
                position: relative;
                top: 10%;
                font-size: 15px;
                text-align: center;
              ">ID</div>  <div     style="
                position: relative;
                top: 15%;
                font-size: 25px;
                text-align: center;
              "> 56</div></div>
<div class="quarter-shu2" ><div     style="
                position: relative;
                top: 10%;
                font-size: 15px;
                text-align: center;
              ">名称</div> <div     style="
                position: relative;
                top: 15%;
                font-size: 20px;
                text-align: center;
              "> 钓鱼台公交站</div></div>

          </div>
          <div
            class="quarter-hen4"
           
          >
            <div
              class="txt_item"
              style="
                position: relative;
                top: 20%;
                font-size: 18px;
                text-align: center;
              "
            >
              <!-- 拥堵 -->
            </div>
            <br />
            <div
              class="txt_item"
              style="
                position: relative;
                top: 9%;
                font-size: 18px;
                text-align: center;
              "
            >
            
              <!-- 超限 -->
            </div>
          </div>
           <div class="quarter-hen4" style="font-size: 27px;  ">
        
            
           <!-- <div class="quarter-shu2"  ><div     style="
                position: relative;
                top: 5%;
                font-size: 17px;

                text-align: center;
              ">已处理</div > <div     style="
                position: relative;
                top: 8%;
                font-size: 28px;
                text-align: center;
              ">53</div></div>
<div class="quarter-shu2" ><div     style="
                position: relative;
                top: 5%;
                font-size: 17px;
                text-align: center;
              ">未处理</div> <div     style="
                position: relative;
                top: 8%;
                font-size: 28px;
                text-align: center;
              ">3</div></div> -->

          </div>

        </div>

        <div class="panel-footer"></div>
      </div>
      <div class="panel">
        <div>
  <el-input placeholder="null" v-model="input1">
    <template slot="prepend">起始节点</template>
  </el-input>
    <el-input placeholder="null" v-model="input2">
    <template slot="prepend">目标节点</template>
  </el-input>
    <el-input placeholder="null" v-model="input3">
    <template slot="prepend">距离</template>
  </el-input>

        </div>
        <div style="  position: relative;
  width: 100%;
  height: 100%;

  float: left;
  top: 5%;">       <el-button type="info" round>信息按钮</el-button></div>
 
        <div class="panel-footer"></div>
      </div>
    </div>
  </div>
</template>
<script>

import line1 from "@/components/Echarts/line";
import plate from "@/components/Echarts/Plate";
import line2 from "@/components/Echarts/line_copy";
import "../assets/index.css";
import "../assets/flexible";

import "ol/ol.css";
import Map from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import TileWMS from "ol/source/TileWMS";
import XYZ from "ol/source/XYZ";
import OSM from "ol/source/OSM";
import ol from "../utils/ol5/ol";
import { Icon, Stroke, Style, Circle, Fill, Text } from "ol/style";
import proj4 from "proj4";
import LineString from "ol/geom/LineString";
import { none } from 'ol/centerconstraint';
export default {
  components: { line1, plate,line2 },
  name: "",

  data() {
    return {
        input1:null,
        input2:null,
        input3:null,
      tableData: [
       
      ],
      form: {
        name: "",
        region: "",
        date1: "",
        date2: "",
        delivery: false,
        type: [],
        resource: "",
        desc: "",
      },

      show: false,
      map: {},
      data: new Array(),
      url1: require("./img/84-虚线 (1).png"),
      url2: require("./img/直线.png"),
      url3: require("./img/84-虚线.png"),
      url4: require("./img/直线 (1).png"),
    };
  },

  mounted() {
    // this.getData();
    this.initMap();
    
  },
  methods: {

  
    initMap() {
      var shamp = new ol.layer.Image({
        //数据范围
        name: "注记图层",
        // extent: [37467916, 3964896.75, 37478080, 3972216.5],
        source: new ol.source.ImageWMS({
          //WMS服务基地址
          url: "http://127.0.0.1:8080/geoserver/wms",
          //图层参数123
          params: {
            LAYERS: "	beijing:eerduosi",
          },
          //服务类型
          serverType: "geoserver",
        }),
      });
      var xincheng = new ol.layer.Image({
        //数据范围
        name: "注记图层",
        // extent: [37467916, 3964896.75, 37478080, 3972216.5],
        source: new ol.source.ImageWMS({
          //WMS服务基地址
          url: "http://127.0.0.1:8083/geoserver/wms",
          //图层参数123
          params: {
            LAYERS: "	xingcheng:xingcheng",
          },
          //服务类型
          serverType: "geoserver",
        }),
      });
      var gaodeMapLayer = new ol.layer.Tile({
        title: "高德地图",
        source: new ol.source.XYZ({
          //url:"http://t0.tianditu.com/DataServer?T=img_w&x={x}&y={y}&l={z}",
          url: "http://t4.tianditu.com/DataServer?T=img_w&tk=4a76fd399e76e3e984e82953755c3410&x={x}&y={y}&l={z}",
          //url: " https://tile.openstreetmap.org/{z}/{x}/{y}.png",
          wrapX: false,
        }),
      });
// #004368
      this.map = new ol.Map({
        layers: [shamp,xincheng],
        view: new ol.View({
          center: [120.765808,40.611875],

          zoom: 13, // 设置初始化时的地图缩放层级
          projection: "EPSG:4326", // 坐标系
        }),
        target: "mapCon", // 地图dom
      });
      
      this.setdata();
      this.createMark();
    },
setdata() {
      this.data = [
        {
          geo: [120.7663896,40.6180495],
          id:"10",
          data_time: "2020/8/2 23:44",
          mine_code: "140211011523.00 ",
          point_code: "14021101152301MN000414214M10",
          point_location: "CO 四风井副立井东侧工作面一氧化碳",
          point_status_name: "异常",
          point_value: "3.75",
          sensor_type_name: "龙兴公交站",
        },
        {
          geo: [120.7663896,40.6180495],
          data_time: "2020/8/2 23:44",
          mine_code: "140211011523.00 ",
          point_code: "14021101152301MN000414214M10",
          point_location: "CO 四风井副立井东侧工作面一氧化碳",
          point_status_name: "正常",
          point_value: "276",
          sensor_type_name: "龙兴公交站",
          point_value2: "3",
          sensor_type_name2: "二氧华安",
        },
                {
          geo: [120.77791634,40.60867972],
          data_time: "2020/8/2 23:44",
          mine_code: "140211011523.00 ",
          point_code: "14021101152301MN000414214M10",
          point_location: "CO 四风井副立井东侧工作面一氧化碳",
          point_status_name: "正常",
          point_value: "56",
          sensor_type_name: "钓鱼台公交站",
          point_value2: "3",
          sensor_type_name2: "二氧华安",
        },
      ];
      console.log(this.data.length);
   this.showPoint();
    },
    showPoint() {
      var features = new Array();




      var routerline1 = [
        [120.7663896,40.6180495],
        [120.7663656,40.6169453],
        [120.7658800,40.6120080],
        [120.76544143,40.60743166],
        [120.77162499,40.60760775],

        [120.77791634,40.60867972],
      ];

      var routeFeature = new ol.Feature({
        type: "route1",
        geometry: new ol.geom.LineString(routerline1),
      });
     



      var source = new ol.source.Vector({
        features: [
          routeFeature,



        ],
      });
      var styles = {
        route1: new Style({
          stroke: new Stroke({
            width: 5,
            color: "#fc0000",
          }),
        }),
        route2: new Style({
          stroke: new Stroke({
            width: 8,
            color: "#008000",
          }),
        }),
        route3: new Style({
          stroke: new Stroke({
            width: 4,
            color: "#0000ff",
            lineDash: [5, 5, 5, 5],
          }),
        }),
        route4: new Style({
          stroke: new Stroke({
            width: 4,
            color: "#fc0000",
            lineDash: [5, 5, 5, 5],
          }),
        }),
        iconStart: new Style({
          image: new Icon({
            anchor: [0.5, 0.5], // 图标中心
            src: require("./img/blueIcon.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
        }),
      };
      this.clusters = new ol.layer.Vector({
        source: new ol.source.Vector({
          features: [routeFeature],
        }),
        style: function (feature) {
          return styles[feature.get("type")];
        },
      });
      this.map.addLayer(this.clusters);
    },

    setInnerText(element, text) {
      if (typeof element.textContent == "string") {
        element.textContent = text;
      } else {
        element.innerText = text;
      }
    },
    addFeatrueInfo(info) {
      var content = document.getElementById("popup-content");

      //新增a元素
      var elementA = document.createElement("a");
      elementA.className = "markerInfo";


      //elementA.innerText = info.att.title;
      // this.setInnerText(elementA, "ID：" + info.name);

      this.setInnerText(elementA, "节点信息" );
     
      // 新建的div元素添加a子节点
      content.appendChild(elementA);
      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      elementDiv.style.display = "flex";
      elementDiv.style.alignItems = "center";

    

      // // 新增10的元素
      // var elementSpan2 = document.createElement("span");
      // elementDiv.style.whiteSpace = "pre";
      // elementSpan2.innerText =  "\u2005CH₄\t  ";
      // elementSpan2.style.marginLeft = "92px"; // 调整与红色风险数的间距
      // elementDiv.appendChild(elementSpan2);

      // // 添加红色风险数和10的父元素div到content
      // content.appendChild(elementDiv);

      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      elementDiv.style.display = "flex";
      elementDiv.style.alignItems = "center";

      // 新增红色风险数的元素
      var elementSpan = document.createElement("span");
      elementSpan.innerText = "地点: ";
      elementDiv.appendChild(elementSpan);

      // 新增10的元素
      var elementSpan2 = document.createElement("span");
      elementDiv.style.whiteSpace = "pre";

       elementSpan2.innerText =  "\u2005 "+(info.name);
      // elementSpan2.innerText = "\t1 \t\t0";
      elementSpan2.style.marginLeft = "20px"; // 调整与红色风险数的间距
      elementDiv.appendChild(elementSpan2);

      // 添加红色风险数和10的父元素div到content
      content.appendChild(elementDiv);

// //

      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      elementDiv.style.display = "flex";
      elementDiv.style.alignItems = "center";

      // 新增红色风险数的元素
      var elementSpan = document.createElement("span");
      elementSpan.innerText = "ID:     ";
      elementDiv.appendChild(elementSpan);

      // 新增10的元素
      var elementSpan2 = document.createElement("span");
      elementDiv.style.whiteSpace = "pre";
       elementSpan2.innerText =  "\u2005"+(info.value);
      // elementSpan2.innerText = "\t1 \t\t0";
      elementSpan2.style.marginLeft = "20px"; // 调整与红色风险数的间距
      elementDiv.appendChild(elementSpan2);

      // 添加红色风险数和10的父元素div到content
      content.appendChild(elementDiv);

      //     var elementDiv = document.createElement("div");
      // elementDiv.className = "markerText";
      // elementDiv.style.display = "flex";
      // elementDiv.style.alignItems = "center";

      // // 新增红色风险数的元素
      // var elementSpan = document.createElement("span");
      // elementSpan.innerText = "黄色风险数: ";
      // elementDiv.appendChild(elementSpan);

      // // 新增10的元素
      // var elementSpan2 = document.createElement("span");
      // elementDiv.style.whiteSpace = "pre";
      //  elementSpan2.innerText =  "\u2005 0 ";
      // // elementSpan2.innerText = "\t1 \t\t0";
      // elementSpan2.style.marginLeft = "20px"; // 调整与红色风险数的间距
      // elementDiv.appendChild(elementSpan2);

      // // 添加红色风险数和10的父元素div到content
      // content.appendChild(elementDiv);
      //     var elementDiv = document.createElement("div");
      // elementDiv.className = "markerText";
      // elementDiv.style.display = "flex";
      // elementDiv.style.alignItems = "center";

      // // 新增红色风险数的元素
      // var elementSpan = document.createElement("span");
      // elementSpan.innerText = "蓝色风险数: ";
      // elementDiv.appendChild(elementSpan);

      // // 新增10的元素
      // var elementSpan2 = document.createElement("span");
      // elementDiv.style.whiteSpace = "pre";
      //  elementSpan2.innerText =  "\u2005 0 ";
      // // elementSpan2.innerText = "\t1 \t\t0";
      // elementSpan2.style.marginLeft = "20px"; // 调整与红色风险数的间距
      // elementDiv.appendChild(elementSpan2);

      // // 添加红色风险数和10的父元素div到content
      // content.appendChild(elementDiv);



 
      // //新增div元素
      // var elementDiv = document.createElement("div");
      // elementDiv.className = "markerText";
      // //elementDiv.innerText = info.att.text;
      // // this.setInnerText(elementDiv, "时间：" + info.time);
      // this.setInnerText(elementDiv, "红色风险数:" );
      
      // // 为content添加div子节点
      // content.appendChild(elementDiv);

      
      // //新增div元素
      // var elementDiv = document.createElement("div");
      // elementDiv.className = "markerText";
      // //elementDiv.innerText = info.att.text;
      // // this.setInnerText(elementDiv, "类别：" + info.value);
      // this.setInnerText(elementDiv, "红色风险数：" );
      // // 为content添加div子节点
      // content.appendChild(elementDiv);
      // //新增div元素
      // var elementDiv = document.createElement("div");
      // elementDiv.className = "markerText";
      
      // //elementDiv.innerText = info.att.text;
      // // this.setInnerText(elementDiv, "地点：" + info.status);
      // this.setInnerText(elementDiv, "红色风险数：" );
      // // 为content添加div子节点
      // content.appendChild(elementDiv);
    },
    createMark() {
      var features = new Array();
      for (var i = 0; i < this.data.length; i++) {
        let Ary = new ol.Feature({
          id: this.data[i].id,
          geometry: new ol.geom.Point(this.data[i].geo),
          time: this.data[i].data_time,
          status: this.data[i].point_status_name,
          name: this.data[i].sensor_type_name,
          value: this.data[i].point_value,
          pintName: this.data[i].point_location,
        });
        features.push(Ary);
        // features.push(
        //   new ol.Feature({
        //     geometry: new ol.geom.Point(this.data[i].geo),
        //   })
        // );
      }

      // 矢量要素数据源
      var source = new ol.source.Vector({
        features: features,
      });

      // 聚合标注数据源
      var clusterSource = new ol.source.Cluster({
        distance: 0, //这个是通过 distance 来控制两个点聚合的间距
        source: source,
      });
      // 加载聚合标注的矢量图层
      var styleCache = {}; //用于保存特定数量的聚合群的要素样式
      var clusters = new ol.layer.Vector({
        source: source,
        style: (feature) => {
          var text = feature.get("name"); //这个是每个点位对应的id
          var color = "";
          // mark点的填充颜色判断
          if (feature.get("status") === "正常") {
            color = "#55ff00";
          } else {
            color = "#ff0000";
          }
          return new Style({

                      image: new Icon({
            anchor: [0.5, 0.7], // 图标中心
            src: require("./img/blueIcon.png"),
            scale: 0.6,

            rotateWithView: true,
          }),
 
            
            // text: new Text({
            //   //位置
            //   textAlign: "center",
            //   //基准线
            //   textBaseline: "middle",
            //   //文字样式
            //   font: "normal 14px 微软雅黑",
            //   //文本内容
            //   text: feature.get("id"),
            //   //文本填充样式（即文字颜色）
            //   fill: new ol.style.Fill({ color: "#aa3300" }),
            //   stroke: new ol.style.Stroke({ color: "#ffcc33", width: 2 }),
            // }),
          });
        },

        // style: function (feature, resolution) {
        //   var size = feature.get("features").length; //获取该要素所在聚合群的要素数量
        //   var style = styleCache[size];
        //   if (!style) {
        //     style = [
        //       new Style({
        //         image: new Circle({
        //           radius: 10,
        //           stroke: new Stroke({
        //             color: "#fff",
        //           }),
        //           fill: new Fill({
        //             color: "#3399CC",
        //           }),
        //         }),
        //       }),
        //     ];
        //   }
        //   return style;
        // },
        zIndex: 999,
      });

      this.map.addLayer(clusters);
      // 弹窗
      this.map.on("singleclick", (e) => {
        let elPopup = this.$refs.popup;
        var popup = new ol.Overlay({
          element: elPopup,
          positioning: "bottom-center",
          stopEvent: false,
          // 信息框的上下位置
          offset: [0, 30],
        });
        this.map.addOverlay(popup);
        let feature = this.map.forEachFeatureAtPixel(
          e.pixel,
          (feature) => feature
        );

        if (feature) {
          let coordinates = feature.getGeometry().getCoordinates();
          // console.log(coordinates)
          setTimeout(() => {
            var content = document.getElementById("popup-content");
            content.innerHTML = "";

            this.show = true;
             
            this.data.map((item, index) => {
            //   if (item.id === feature.values_.id)
                // this.$store.commit("setpointValue", item);
          
            });
      
            // this.$store.commit("setpointid", feature.values_.id);
            // console.log(this.$store.getters.getpointValue[feature.values_.id]["id"])
            //在popup中加载当前要素的具体信息
            this.addFeatrueInfo(feature.values_);

            popup.setPosition(coordinates);
          }, 0);
        } else {
          this.show = false;
        }
      });
    },

    // 初始化地图
    // initMap() {
    //   this.map = new Map({
    //     layers: [
    //       new TileLayer({
    //     extent: [37467916, 3964896.75, 37478080, 3972216.5],
    //      source: new TileWMS({
    //       url: "http://120.53.249.144:8080/geoserver/wms",
    //       params: { LAYERS: "webgis:cad_polyline" },
    //       serverType: "geoserver",
    //     }),

    //   })
    //     ],
    //     target: "map",
    //     view: new View({
    //        center: [37477916, 3968896.2],
    //        projection: 'EPSG:3857',
    //       zoom: 14,
    //     }),
    //   });
    // },

    addLayer() {
      // 加载 GeoServer 发布的 wms 服务
      let wmsLayer = new TileLayer({
        extent: [
          // 边界
          97.350096, 26.045865, 108.546488, 34.312446,
        ],
        source: new TileWMS({
          //上线后，记得要把url: 'http://localhost:8090/geoserver/ws-world/wms'中的localhost换成云服务器的ip地址！！
          url: "http://120.76.197.111:8090/geoserver/keshan/wms",
          params: { LAYERS: "keshan:sichuan", TILED: true },
          serverType: "geoserver",
        }),
        visible: true,
        zIndex: 2,
      });
      this.map.addLayer(wmsLayer);
    },
  },
};
</script>
<style lang="less" scoped>
.el-table, .el-table__expanded-cell {background-color: transparent !important;}
.title_i {
  position: absolute;
  left: 10%;
  top: 50%;
  font-size: 30px;
  transform: translate(-50%, -50%);
  color: rgb(255, 255, 255);
}
#mapCon {
  top: 0px;
  width: 100%;
  height: 100%;
  position: relative;
  float: right;
}
#title2 {
  top: 10%;
  right: 2%;
  bottom: 3%;
  position: absolute;
  float: left;
  font-size: 30px;
  width: 19%;
  background-color: #fff;
  height: 85%;
  text-align: center;
}
#title {
  top: 10%;
  left: 2%;
  bottom: 3%;
  position: absolute;
  float: left;
  font-size: 30px;
  width: 19%;
  background-color: #fff;
  height: 85%;
  text-align: center;
}
#title3 {
  top: 70%;
  left: 25%;
  bottom: 3%;
  position: absolute;
  float: left;
  font-size: 30px;
  width: 10%;
color: white;
  height: 25%;
  text-align: center;
}
#zi_daohan {
  top: 10%;
  left: 28%;
  bottom: 3%;
  position: absolute;
  float: left;
  font-size: 30px;
  width: 44%;

  height: 5%;
  text-align: center;
}
.ol-popup {
  position: absolute;
  background-color: white;
  -webkit-filter: drop-shadow(0 1px 4px rgba(0, 0, 0, 0.2));
  filter: drop-shadow(0 1px 4px rgba(0, 0, 0, 0.2));
  padding: 15px;
  border-radius: 10px;
  border: 1px solid #cccccc;
  bottom: 45px;
  left: -50px;
}

.ol-popup:after,
.ol-popup:before {
  top: 100%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}

.ol-popup:after {
  border-top-color: white;
  border-width: 10px;
  left: 48px;
  margin-left: -10px;
}

.ol-popup:before {
  border-top-color: #cccccc;
  border-width: 11px;
  left: 48px;
  margin-left: -11px;
}

.ol-popup-closer {
  text-decoration: none;
  position: absolute;
  top: 2px;
  right: 8px;
}

.ol-popup-closer:after {
  content: "✖";
}

#popup-content {
  font-size: 14px;
  font-family: "微软雅黑";
  width: 200px;
}

#popup-content .markerInfo {
  font-weight: bold;
}
#popup-content1 {
  font-size: 14px;
  font-family: "微软雅黑";
  width: 300px;
}

#popup-content1 .markerInfo {
  font-weight: bold;
}
#line {
  top: 80%;
}
.txt_item {
  font-size: 14px;
  font-family: "微软雅黑";
  // width: 200px;
}
.quarter-div {
  position: relative;
  width: 50%;
  height: 100%;

  float: left;
  top: 15px;
  // background-color: black;
}
.quarter-div-hen4 {
  position: relative;
  width: 100%;
  height: 100%;

  float: left;
  top: 15px;
}
.quarter-divshu3 {
  position: relative;
  width: 100%;
  height: 33%;
  font-size: 22px;
  float: left;
}
.quarter-shu2{
 position: relative;
  width: 100%;
  height: 50%;

  float: left;
}
.quarter-hen4 {
  position: relative;
  width: 25%;
  height: 100%;

  float: left;
}
.circle {
  padding-top: 10px;
  position: relative;
  left: 10px;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: gray;
}
/deep/.el-table thead tr>th{
background:#0a364a;
color: rgb(255, 255, 255);

}
// 更改表格每行背景颜色
/deep/.el-table tbody tr>td{
   background:#0a364a;
   color: rgb(255, 255, 255);
}
// 设置鼠标经过时背景颜色
/deep/.el-table tbody tr:hover>td{
    background-color:#013d57!important;
}

</style>
