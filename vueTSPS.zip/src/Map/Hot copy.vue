<template>
         <div style="height:100%">
           <div id="map"></div>
             <div id="title">
      <div style="left: 0%; hight: 20%; position: relative">
        <el-input
          placeholder="搜索关键字，例如：covid-19"
          v-model="input2"
          style="width: 82%; left: 10px; top: 15px; position: absolute"
        >
        </el-input>
        <i
          class="el-icon-search"
          style="float: right; right: 30px; top: 20px; position: relative"
        ></i>
      </div>
     
    </div>
         </div>
         
</template>

<script>
  import Map from 'ol/Map'
  import View from 'ol/View'
  import { Heatmap as HeatmapLayer } from 'ol/layer'
  import VectorSource from 'ol/source/Vector'
  import { transform } from 'ol/proj'
  import GeoJSON from 'ol/format/GeoJSON'
  import ol from "../utils/ol5/ol"
  import proj4 from"proj4";
  export default {
        name: 'heatmap',
        data () {
          return {
            map: null,
            center: [37473426.9,3968134.2],
            // 热力图假数据
            heatData: {
              type: 'FeatureCollection',
              features: [
                { type: 'Point', 'coordinates': [37473426.9,3968134.2], count: 100 },
                { type: 'Point', 'coordinates': [37468400.9,3968134.2], count: 19 },
                { type: 'Point', 'coordinates': [120.775971,40.623456], count: 419 },
                { type: 'Point', 'coordinates': [37473426.9,3967134.2], count: 319 },
                { type: 'Point', 'coordinates': [37473426.9,3967094.2], count: 719 },
                { type: 'Point', 'coordinates': [120.775971,40.623456], count: 519 },
                { type: 'Point', 'coordinates': [37473426.9,3967334.2], count: 319 },
                { type: 'Point', 'coordinates':[37473426.9,3968134.2], count: 139 },
                { type: 'Point', 'coordinates':[37473426.9,3968134.2], count: 129 },
                { type: 'Point', 'coordinates': [37473426.9,3968134.2], count: 190 },
                { type: 'Point', 'coordinates': [37472426.9,3964134.2], count: 189 },
                { type: 'Point', 'coordinates': [37471126.9,3961134.2], count: 1 },
                { type: 'Point', 'coordinates':[37473426.9,3968134.2], count: 119 },
                { type: 'Point', 'coordinates': [37473426.9,3968134.2], count: 200 },
                { type: 'Point', 'coordinates': [37473426.9,3968134.2], count: 300 }
              ]
            }
          }
        },mounted () {
          this.initmap()
      }   ,    
methods: {

initmap() {
      var shamp =new ol.layer.Image({
               				//数据范围
               				name: "注记图层",
               				// extent: [37467916, 3964896.75, 37478080, 3972216.5],
               				source: new ol.source.ImageWMS({
               					//WMS服务基地址
               					url: 'http://127.0.0.1:8080/geoserver/wms',
               					//图层参数123
               					params: {
               						'LAYERS': '		beijing:beijinghot'
               					},
               					//服务类型
               					serverType: 'geoserver'
               				})
               			});
       var gaodeMapLayer = new ol.layer.Tile({
        title: "高德地图",
        source: new ol.source.XYZ({
          // url:"http://t4.tianditu.com/DataServer?T=vec_w&tk=4a76fd399e76e3e984e82953755c3410&x={x}&y={y}&l={z}",
          url: " https://tile.openstreetmap.org/{z}/{x}/{y}.png",
          wrapX: false,
        }),
      });
   this.map = new ol.Map({
        layers: [gaodeMapLayer,shamp],
        view: new ol.View({
          center: [116.3033105,	39.76206835],

          zoom: 8, // 设置初始化时的地图缩放层级
          projection: "EPSG:4326", // 坐标系
        }),
        target: "map", // 地图dom
      });

   
     this.setdata()
    },

 
          setdata () {
          // 创建一个热力图层
            let vector = new ol.layer.Heatmap({
            // 矢量数据源
              source: new VectorSource({
                features: (new GeoJSON()).readFeatures(this.heatData),
              }),
              blur: 20, // 模糊尺寸
              radius: 20 // 热点半径
            })
console.log((new GeoJSON()).readFeatures(this.heatData))
            this.map.addLayer(vector);
          }
      },

    }
</script>

<style scoped>
.label{
  font-size: 20px;
}
.title_i {
  position: absolute;
  left: 10%;
  top: 50%;
  font-size: 30px;
  transform: translate(-50%, -50%);
  color:  rgb(156, 149, 149);
    background-color: rgb(156, 149, 149);
}

#title {
  border-radius: 10px;
  top: 10%;
  left: 35%;
  bottom: 3%;
  position: absolute;
  float: left;
  font-size: 30px;
  width: 35%;
  background-color: rgb(255, 255, 255);
  height: 9%;
  text-align: center;
}
</style>

