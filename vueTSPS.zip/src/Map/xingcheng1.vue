<template>
  <div>
    <div id="mapCon" style="background:#004368">
      <!-- <div class="column1" style="position: relative">
  
        <img
          src="./img/地图.png"
          alt=""
          style="position: relative"
        />
      </div> -->
      <!-- Popup -->
      <div id="popup" class="ol-popup" ref="popup" v-show="show">
        <a href="#" id="popup-closer" class="ol-popup-closer"></a>
        <div id="popup-content"></div>
      </div>
    </div>

    <div id="title" style="background:#002e42;color: white;">
      <div>
        <div
          style="
            position: relative;
            top: 20%;
            font-size: 20px;
            text-align: center;
          "
        >
          今日信息
        </div>
      </div>

      <div class="panel">
        <div class="quarter-div">
          <div
            class="quarter-divshu3"
           
          >
            308
            <br />
            <div class="txt_item">节点总数</div>
          </div>
          <div
            class="quarter-divshu3"
       
          >
            5
            <br />
            <div class="txt_item">超限次数</div>
          </div>
          <div
            class="quarter-divshu3"
  
          >
            1
            <br />
            <div class="txt_item">黄色风险</div>
          </div>
        </div>
        <div class="quarter-div">
          <div
            class="quarter-divshu3"

          >
            308
            <br />
            <div class="txt_item">已接入节点</div>
          </div>
          <div
            class="quarter-divshu3"

          >
            0
            <br />
            <div class="txt_item">橙色风险</div>
          </div>
          <div
            class="quarter-divshu3"
     
          >
            2
            <br />
            <div class="txt_item">蓝色风险</div>
          </div>
        </div>

        <div class="panel-footer"></div>
      </div>
      <div class="panel">
        <line1></line1>
        <div class="panel-footer"></div>
      </div>
      <div class="panel">
        <line2></line2>
        <div class="panel-footer"></div>
      </div>
    </div>
    <div id="title3">
      <!-- <div
        style="position: relative; top: 0%; font-size: 16px; text-align: center"
      >
        今日风险研判<br />
        车流量
      </div> -->
      <div class="quarter-div">
        <!-- <div class="circle" style="background: rgb(250, 3, 3)"></div>
       <div class="circle" style="background: rgb(250, 143, 3)"></div>
       <div class="circle" style="  background: rgb(252, 231, 44);"></div>
       <div class="circle" style="background: rgb(44, 110, 252);"></div>
       <div class="circle" style="background: rgb(68, 252, 44);"></div>
         <br> -->
      </div>
      <div class="quarter-div">
        <!-- <div style="position: relative; top: 0%; font-size: 16px; right: 50%">
          红色风险<br>橙色风险<br>黄色风险<br>蓝色风险<br>绿色风险<br>
        </div> -->
      </div>

      <!-- <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div> -->
    </div>
    <div id="title2" style="background:#002e42;color: white;">
      <div>
        <div
          style="
            position: relative;
            top: 20%;
            font-size: 20px;
            text-align: center;
          "
        >
          结果分析
          <!-- <div style="position: absolute; top: 20%; font-size: 20px; left: 10% ;">
                     <el-radio-group
            v-model="radio1"
            
          >
            <el-radio-button label="周" ></el-radio-button>
            <el-radio-button label="月"></el-radio-button>
          </el-radio-group>
          </div> -->
 
        </div>
      </div>

      <div class="panel">
        <div class="quarter-div-hen4">
          <div
            class="quarter-hen4"
            
          >
            <div
              class="txt_item"
              style="
                position: relative;
                top: 20%;
                font-size: 18px;
                text-align: center;
              "
            >
              起始
            </div>
            <br />
            <div
              class="txt_item"
              style="
                position: relative;
                top: 5%;
                font-size: 18px;
                text-align: center;
              "
            >
              节点
            </div>
            
          </div>
          
          <div class="quarter-hen4" style="font-size: 27px; width: 60%; ">
           <div class="quarter-shu2"  ><div     style="
                position: relative;
                top: 10%;
                font-size: 15px;
                text-align: center;
              ">ID</div>  <div     style="
                position: relative;
                top: 15%;
                font-size: 25px;
                text-align: center;
              ">276</div></div>
<div class="quarter-shu2" ><div     style="
                position: relative;
                top: 10%;
                font-size: 15px;
                text-align: center;
              ">名称</div> <div     style="
                position: relative;
                top: 15%;
                font-size: 20px;
                text-align: center;
              ">龙兴公交站</div></div>

          </div>
          <div
            class="quarter-hen4"
           
          >
            <div
              class="txt_item"
              style="
                position: relative;
                top: 20%;
                font-size: 18px;
                text-align: center;
              "
            >
              <!-- 拥堵 -->
            </div>
            <br />
            <div
              class="txt_item"
              style="
                position: relative;
                top: 9%;
                font-size: 18px;
                text-align: center;
              "
            >
              <!-- 超限 -->
            </div>
          </div>
           <div class="quarter-hen4" style="font-size: 27px;  ">
           <!-- <div class="quarter-shu2"  ><div     style="
                position: relative;
                top: 5%;
                font-size: 17px;

                text-align: center;
              ">已处理</div > <div     style="
                position: relative;
                top: 8%;
                font-size: 28px;
                text-align: center;
              ">53</div></div>
<div class="quarter-shu2" ><div     style="
                position: relative;
                top: 5%;
                font-size: 17px;
                text-align: center;
              ">未处理</div> <div     style="
                position: relative;
                top: 8%;
                font-size: 28px;
                text-align: center;
              ">3</div></div> -->

          </div>

        </div>

        <div class="panel-footer"></div>
      </div>
      <div class="panel" >
        <!-- <el-table :data="tableData"   height="200" >
          <el-table-column prop="province" label="道路" width="150">
          </el-table-column>
    
          <el-table-column prop="city" label="车流情况" width="150">
          </el-table-column>
        </el-table> -->
        <div class="panel-footer"></div>
      </div>
      <!-- <div class="panel">
        <line2></line2>
        <div class="panel-footer"></div>
      </div> -->
    </div>
  </div>
</template>
<script>

import line1 from "@/components/Echarts/line";
import plate from "@/components/Echarts/Plate";
import line2 from "@/components/Echarts/line_copy";
import "../assets/index.css";
import "../assets/flexible";

import "ol/ol.css";
import Map from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import TileWMS from "ol/source/TileWMS";
import XYZ from "ol/source/XYZ";
import OSM from "ol/source/OSM";
import ol from "../utils/ol5/ol";
import { Icon, Stroke, Style, Circle, Fill, Text } from "ol/style";
import proj4 from "proj4";
import LineString from "ol/geom/LineString";
import { none } from 'ol/centerconstraint';
export default {
  components: { line1, plate,line2 },
  name: "",

  data() {
    return {
      tableData: [
       
      ],
      form: {
        name: "",
        region: "",
        date1: "",
        date2: "",
        delivery: false,
        type: [],
        resource: "",
        desc: "",
      },

      show: false,
      map: {},
      data: new Array(),
      url1: require("./img/84-虚线 (1).png"),
      url2: require("./img/直线.png"),
      url3: require("./img/84-虚线.png"),
      url4: require("./img/直线 (1).png"),
    };
  },

  mounted() {
    this.getData();
    this.initMap();
    
  },
  methods: {

  
    initMap() {
      var shamp = new ol.layer.Image({
        //数据范围
        name: "注记图层",
        // extent: [37467916, 3964896.75, 37478080, 3972216.5],
        source: new ol.source.ImageWMS({
          //WMS服务基地址
          url: "http://127.0.0.1:8080/geoserver/wms",
          //图层参数123
          params: {
            LAYERS: "	beijing:eerduosi",
          },
          //服务类型
          serverType: "geoserver",
        }),
      });
      var xincheng = new ol.layer.Image({
        //数据范围
        name: "注记图层",
        // extent: [37467916, 3964896.75, 37478080, 3972216.5],
        source: new ol.source.ImageWMS({
          //WMS服务基地址
          url: "http://127.0.0.1:8083/geoserver/wms",
          //图层参数123
          params: {
            LAYERS: "	xingcheng:xingcheng",
          },
          //服务类型
          serverType: "geoserver",
        }),
      });
      var gaodeMapLayer = new ol.layer.Tile({
        title: "高德地图",
        source: new ol.source.XYZ({
          //url:"http://t0.tianditu.com/DataServer?T=img_w&x={x}&y={y}&l={z}",
          url: "http://t4.tianditu.com/DataServer?T=img_w&tk=4a76fd399e76e3e984e82953755c3410&x={x}&y={y}&l={z}",
          //url: " https://tile.openstreetmap.org/{z}/{x}/{y}.png",
          wrapX: false,
        }),
      });
// #004368
      this.map = new ol.Map({
        layers: [shamp,xincheng],
        view: new ol.View({
          center: [120.765808,40.611875],

          zoom: 13, // 设置初始化时的地图缩放层级
          projection: "EPSG:4326", // 坐标系
        }),
        target: "mapCon", // 地图dom
      });
      
      this.getData();
      // this.showPoint();
    },
   async getData() {
      // 获取服务器的数据, 对this.allData进行赋值之后, 调用updateChart方法更新图表
      const { data: ret } = await this.$http.get("http://127.0.0.1:8000/api/xingchneg");
   
  
       
      
      for (var i = 0; i < ret.data.length; i++) {
        var data = {
       
          geo: ret.data[i]["geo"],
          value:ret.data[i]["value"],
          name:ret.data[i]["name"],
          province:ret.data[i]["name"],
          city:ret.data[i]["value"]

        };
        this.tableData.push(data);
        this.data.push(data);
      }
      console.log(this.data);
      console.log(this.data.length);
        this.createMark();

    
    },
    showPoint() {
      var features = new Array();
      var routerline1 = [
        [116.2806817, 39.8043734],
        [116.282464, 39.80360237],
        [116.2842108, 39.80285155],
        [116.284378, 39.80427615],
        [116.2839092, 39.8055331],
        [116.2856848, 39.80621301],
        [116.2878576, 39.80609564],
        [116.2912864, 39.8054335],
        [116.2941725, 39.80535867],
        [116.2947095, 39.80379635],
        [116.2962653, 39.7993066],
        [116.2974985, 39.79609965],
        [116.2977674, 39.79617291],
        [116.3030222, 39.79747475],
        [116.3077744, 39.79531225],
        [116.3077634, 39.7917141],
        [116.307707, 39.78919265],
        [116.3076569, 39.78770395],
        [116.30971, 39.78503319],
        [116.3127417, 39.78297645],
        [116.314533, 39.78242761],
        [116.3163071, 39.7819045],
        [116.3163518, 39.7819527],
        [116.3163074, 39.78202085],
        [116.3160168, 39.78209926],
        [116.3143348, 39.78260295],
        [116.3128454, 39.78308325],
        [116.3127295, 39.7830612],
        [116.3107287, 39.78017583],
        [116.3092531, 39.776915],
        [116.3081801, 39.77428305],
        [116.3065658, 39.7702458],
        [116.3059543, 39.7686888],
        [116.3052799, 39.76705899],
        [116.3039856, 39.763803],

        [116.3033105, 39.76206835],
      ];
      var routerline2 = [
        [-73.95588028, 40.65137012],
        [-73.95580198, 40.65054242],
        [-73.95247241, 40.65069902],
        [-73.9529385, 40.655197],
        [-73.9471178, 40.6555738],
        [-73.9473585, 40.6572838],
      ];

      var routerline3 = [
        [-73.95591997, 40.65136838],
        [-73.95004012, 40.65515705],
        [-73.9473446, 40.6572663],
      ];
      var routerline4 = [
        [-73.95588028, 40.65137012],
        [-73.9504903, 40.6553856],
        [-73.9473585, 40.6572838],
      ];

      var routeFeature = new ol.Feature({
        type: "route1",
        geometry: new ol.geom.LineString(routerline2),
      });
      var routeFeature1 = new ol.Feature({
        type: "route2",
        geometry: new ol.geom.LineString(routerline1),
      });
      var routeFeature2 = new ol.Feature({
        type: "route3",
        geometry: new ol.geom.LineString(routerline3),
      });
      var routeFeature3 = new ol.Feature({
        type: "route4",
        geometry: new ol.geom.LineString(routerline4),
      });

      var startMarker = new ol.Feature({
        type: "iconStart",
        geometry: new ol.geom.Point(routerline2[0]),
      });

      var source = new ol.source.Vector({
        features: [
          routeFeature,
          startMarker,
          routeFeature1,
          routeFeature2,
          routeFeature3,
        ],
      });
      var styles = {
        route1: new Style({
          stroke: new Stroke({
            width: 4,
            color: "#009000",
          }),
        }),
        route2: new Style({
          stroke: new Stroke({
            width: 8,
            color: "#008000",
          }),
        }),
        route3: new Style({
          stroke: new Stroke({
            width: 4,
            color: "#0000ff",
            lineDash: [5, 5, 5, 5],
          }),
        }),
        route4: new Style({
          stroke: new Stroke({
            width: 4,
            color: "#fc0000",
            lineDash: [5, 5, 5, 5],
          }),
        }),
        iconStart: new Style({
          image: new Icon({
            anchor: [0.5, 0.5], // 图标中心
            src: require("./img/blueIcon.png"),
            scale: 0.7,

            rotateWithView: true,
          }),
        }),
      };
      this.clusters = new ol.layer.Vector({
        source: new ol.source.Vector({
          features: [routeFeature, routeFeature1, routeFeature2, routeFeature3],
        }),
        style: function (feature) {
          return styles[feature.get("type")];
        },
      });
      this.map.addLayer(this.clusters);
    },
    setdata() {
      this.data = [{
          geo: [120.7662045,40.6169242],
          point_location: "B3",

          point_status_name: "欣葆家园",
          point_value: "住宅",
          sensor_type_name: "0",
        },
        {
          geo: [120.7663440,40.6169590],
          point_location: "A3",

          point_status_name: "重庆",
          point_value: "3",
          sensor_type_name: "3",
        },
        {
          geo: [120.7653218,40.6168849],
          point_location: "B3",
          point_status_name: "超市、商场。美食、电影院",
          point_value: "景区",
          sensor_type_name: "0",
        },
        {
          geo: [120.7644935,40.6168501],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "0",
        },
        {
          geo: [120.758981,40.616514],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "0",
        },

        {
          geo: [120.754169,40.617892],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "0",
        },
        {
          geo: [120.756941,40.616968],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "0",
        },
        {
          geo: [120.7675754,40.6170048],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "0",
        },
        {
          geo: [120.7723748,40.6172315],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "0",
        },
        {
          geo: [120.7739114,40.6173100],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "0",
        },
        {
          geo: [120.7758131,40.6174168],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "0",
        },
        {
          geo: [120.7801210,40.6179627],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "0",
        },
        {
          geo: [120.7840736,40.6182123],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "0",
        },
        {
          geo: [120.7890234,40.6181425],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "0",
        },
        {
          geo: [120.7945954,40.6177208],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "0",
        },
        {
          geo: [120.7943905,40.6177775],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "0",
        },
        {
          geo: [120.765808,40.611875],

          point_location: "B3",
          point_status_name: "沙滩、大海、海洋",
          point_value: "景区",
          sensor_type_name: "0",
        },
      ];

      this.createMark();
    },
    setInnerText(element, text) {
      if (typeof element.textContent == "string") {
        element.textContent = text;
      } else {
        element.innerText = text;
      }
    },
    addFeatrueInfo(info) {
      var content = document.getElementById("popup-content");

      //新增a元素
      var elementA = document.createElement("a");
      elementA.className = "markerInfo";


      //elementA.innerText = info.att.title;
      // this.setInnerText(elementA, "ID：" + info.name);

      this.setInnerText(elementA, "交通流量预测" );
     
      // 新建的div元素添加a子节点
      content.appendChild(elementA);
      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      elementDiv.style.display = "flex";
      elementDiv.style.alignItems = "center";

    

      // // 新增10的元素
      // var elementSpan2 = document.createElement("span");
      // elementDiv.style.whiteSpace = "pre";
      // elementSpan2.innerText =  "\u2005CH₄\t  ";
      // elementSpan2.style.marginLeft = "92px"; // 调整与红色风险数的间距
      // elementDiv.appendChild(elementSpan2);

      // // 添加红色风险数和10的父元素div到content
      // content.appendChild(elementDiv);

      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      elementDiv.style.display = "flex";
      elementDiv.style.alignItems = "center";

      // 新增红色风险数的元素
      var elementSpan = document.createElement("span");
      elementSpan.innerText = "地点: ";
      elementDiv.appendChild(elementSpan);

      // 新增10的元素
      var elementSpan2 = document.createElement("span");
      elementDiv.style.whiteSpace = "pre";

       elementSpan2.innerText =  "\u2005 "+(info.name);
      // elementSpan2.innerText = "\t1 \t\t0";
      elementSpan2.style.marginLeft = "20px"; // 调整与红色风险数的间距
      elementDiv.appendChild(elementSpan2);

      // 添加红色风险数和10的父元素div到content
      content.appendChild(elementDiv);

// //

      var elementDiv = document.createElement("div");
      elementDiv.className = "markerText";
      elementDiv.style.display = "flex";
      elementDiv.style.alignItems = "center";

      // 新增红色风险数的元素
      var elementSpan = document.createElement("span");
      elementSpan.innerText = "流量: ";
      elementDiv.appendChild(elementSpan);

      // 新增10的元素
      var elementSpan2 = document.createElement("span");
      elementDiv.style.whiteSpace = "pre";
       elementSpan2.innerText =  "\u2005"+(info.value);
      // elementSpan2.innerText = "\t1 \t\t0";
      elementSpan2.style.marginLeft = "20px"; // 调整与红色风险数的间距
      elementDiv.appendChild(elementSpan2);

      // 添加红色风险数和10的父元素div到content
      content.appendChild(elementDiv);

      //     var elementDiv = document.createElement("div");
      // elementDiv.className = "markerText";
      // elementDiv.style.display = "flex";
      // elementDiv.style.alignItems = "center";

      // // 新增红色风险数的元素
      // var elementSpan = document.createElement("span");
      // elementSpan.innerText = "黄色风险数: ";
      // elementDiv.appendChild(elementSpan);

      // // 新增10的元素
      // var elementSpan2 = document.createElement("span");
      // elementDiv.style.whiteSpace = "pre";
      //  elementSpan2.innerText =  "\u2005 0 ";
      // // elementSpan2.innerText = "\t1 \t\t0";
      // elementSpan2.style.marginLeft = "20px"; // 调整与红色风险数的间距
      // elementDiv.appendChild(elementSpan2);

      // // 添加红色风险数和10的父元素div到content
      // content.appendChild(elementDiv);
      //     var elementDiv = document.createElement("div");
      // elementDiv.className = "markerText";
      // elementDiv.style.display = "flex";
      // elementDiv.style.alignItems = "center";

      // // 新增红色风险数的元素
      // var elementSpan = document.createElement("span");
      // elementSpan.innerText = "蓝色风险数: ";
      // elementDiv.appendChild(elementSpan);

      // // 新增10的元素
      // var elementSpan2 = document.createElement("span");
      // elementDiv.style.whiteSpace = "pre";
      //  elementSpan2.innerText =  "\u2005 0 ";
      // // elementSpan2.innerText = "\t1 \t\t0";
      // elementSpan2.style.marginLeft = "20px"; // 调整与红色风险数的间距
      // elementDiv.appendChild(elementSpan2);

      // // 添加红色风险数和10的父元素div到content
      // content.appendChild(elementDiv);



 
      // //新增div元素
      // var elementDiv = document.createElement("div");
      // elementDiv.className = "markerText";
      // //elementDiv.innerText = info.att.text;
      // // this.setInnerText(elementDiv, "时间：" + info.time);
      // this.setInnerText(elementDiv, "红色风险数:" );
      
      // // 为content添加div子节点
      // content.appendChild(elementDiv);

      
      // //新增div元素
      // var elementDiv = document.createElement("div");
      // elementDiv.className = "markerText";
      // //elementDiv.innerText = info.att.text;
      // // this.setInnerText(elementDiv, "类别：" + info.value);
      // this.setInnerText(elementDiv, "红色风险数：" );
      // // 为content添加div子节点
      // content.appendChild(elementDiv);
      // //新增div元素
      // var elementDiv = document.createElement("div");
      // elementDiv.className = "markerText";
      
      // //elementDiv.innerText = info.att.text;
      // // this.setInnerText(elementDiv, "地点：" + info.status);
      // this.setInnerText(elementDiv, "红色风险数：" );
      // // 为content添加div子节点
      // content.appendChild(elementDiv);
    },
    createMark() {
      var features = new Array();

      // for (var i = 0; i < this.data.length; i++) {
      //   let Ary = new ol.Feature({
      //     geometry: new ol.geom.Point(this.data[i].geo),

      //     status: this.data[i].point_status_name,
      //     name: this.data[i].sensor_type_name,
      //     value: this.data[i].point_value,
      //     pintName: this.data[i].point_location,
      //     time: "2022.12.15 17:53:08",
      //     type: this.data[i].point_location,
      //   });
   
      var flag=none
      for (var i = 0; i < this.data.length; i++) {
          if(this.data[i].value > 150){
            flag="A3"
          }
          else{
            flag="B3"
          }
        let Ary = new ol.Feature({
          geometry: new ol.geom.Point(this.data[i].geo),
          value: this.data[i].value,
        

          status: "欣葆家园",
          name: this.data[i].name,
          
          pintName: flag,
          time: "2022.12.15 17:53:08",
          type: flag,
        });

        features.push(Ary);
        // features.push(
        //   new ol.Feature({
        //     geometry: new ol.geom.Point(this.data[i].geo),
        //   })
        // );
      }

      // 矢量要素数据源
      var source = new ol.source.Vector({
        features: features,
      });

      // 聚合标注数据源
      var clusterSource = new ol.source.Cluster({
        distance: 40, //这个是通过 distance 来控制两个点聚合的间距
        source: source,
      });
      var styles1 = {
        A3: new Style({
          image: new Circle({
            radius: 10,
            stroke: new Stroke({
              color: "#fff",
            }),
            fill: new Fill({
              color: "#ff0000",
            }),
            opacity: 0.75,
          }),
          text: new Text({
            //位置
            textAlign: "right",
            //基准线
            textBaseline: "bottom",
            //文字样式
            font: "normal 24px 微软雅黑",
            //文本内容
            offsetX: -20,
            text: "",
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
        B3: new Style({
          image: new Circle({
            radius: 10,
            stroke: new Stroke({
              color: "#fff",
            }),
            fill: new Fill({
              color: "#55ff00",
            }),
            opacity: 0.75,
          }),
          text: new Text({
            //位置
            textAlign: "left",
            //基准线
            textBaseline: "bottom",
            //文字样式
            font: "normal 24px 微软雅黑",
            //文本内容
            offsetX: 20,
            text: " ",
            //文本填充样式（即文字颜色）
            fill: new ol.style.Fill({ color: "#000000" }),
            stroke: new ol.style.Stroke({ color: "#000000", width: 1 }),
          }),
        }),
      };

      var clusters = new ol.layer.Vector({
        // distance: 40, //这个是通过 distance 来控制两个点聚合的间距
        source: source,

        style: (feature) => {
          return styles1[feature.get("type")];
        },

       
        zIndex: 999,
      });

      this.map.addLayer(clusters);
      // 弹窗

      this.map.on("singleclick", (e) => {
        let elPopup = this.$refs.popup;
        var popup = new ol.Overlay({
          element: elPopup,
          positioning: "bottom-center",
          stopEvent: false,
          // 信息框的上下位置
          offset: [0, 30],
        });
        this.map.addOverlay(popup);
        console.log(e.pixel);
        let feature = this.map.forEachFeatureAtPixel(
          e.pixel,
          (feature) => feature
        );
        console.log(feature.values_);
        if (feature) {
          let coordinates = feature.getGeometry().getCoordinates();
          // console.log(coordinates)
          setTimeout(() => {
            var content = document.getElementById("popup-content");
            content.innerHTML = "";
            this.show = true;
            //在popup中加载当前要素的具体信息
            this.addFeatrueInfo(feature.values_);

            popup.setPosition(coordinates);
          }, 0);
        } else {
          this.show = false;
        }
      });
      //   this.map.on("singleclick", (e) => {
      //     let elPopup = this.$refs.popup;
      //     var popup = new ol.Overlay({
      //       element: elPopup,
      //       positioning: "bottom-center",
      //       stopEvent: false,
      //       // 信息框的上下位置
      //       offset: [0, 30],
      //     });
      //     this.map.addOverlay(popup);
      //     console.log(e.pixel)
      //     let feature = this.map.forEachFeatureAtPixel(
      //       e.pixel,
      //       (feature) => feature
      //     );
      //     console.log(feature.values_);
      //     if (feature) {
      //       let coordinates = feature.getGeometry().getCoordinates();
      //       // console.log(coordinates)
      //       setTimeout(() => {
      //         var content = document.getElementById("popup-content");
      //         content.innerHTML = "";
      //         this.show = true;
      //         //在popup中加载当前要素的具体信息
      //         this.addFeatrueInfo(feature.values_);

      //         popup.setPosition(coordinates);
      //       }, 0);
      //     } else {
      //       this.show = false;
      //     }
      //   });
    },

    // 初始化地图
    // initMap() {
    //   this.map = new Map({
    //     layers: [
    //       new TileLayer({
    //     extent: [37467916, 3964896.75, 37478080, 3972216.5],
    //      source: new TileWMS({
    //       url: "http://120.53.249.144:8080/geoserver/wms",
    //       params: { LAYERS: "webgis:cad_polyline" },
    //       serverType: "geoserver",
    //     }),

    //   })
    //     ],
    //     target: "map",
    //     view: new View({
    //        center: [37477916, 3968896.2],
    //        projection: 'EPSG:3857',
    //       zoom: 14,
    //     }),
    //   });
    // },

    addLayer() {
      // 加载 GeoServer 发布的 wms 服务
      let wmsLayer = new TileLayer({
        extent: [
          // 边界
          97.350096, 26.045865, 108.546488, 34.312446,
        ],
        source: new TileWMS({
          //上线后，记得要把url: 'http://localhost:8090/geoserver/ws-world/wms'中的localhost换成云服务器的ip地址！！
          url: "http://120.76.197.111:8090/geoserver/keshan/wms",
          params: { LAYERS: "keshan:sichuan", TILED: true },
          serverType: "geoserver",
        }),
        visible: true,
        zIndex: 2,
      });
      this.map.addLayer(wmsLayer);
    },
  },
};
</script>
<style lang="less" scoped>
.el-table, .el-table__expanded-cell {background-color: transparent !important;}
.title_i {
  position: absolute;
  left: 10%;
  top: 50%;
  font-size: 30px;
  transform: translate(-50%, -50%);
  color: rgb(255, 255, 255);
}
#mapCon {
  top: 0px;
  width: 100%;
  height: 100%;
  position: relative;
  float: right;
}
#title2 {
  top: 10%;
  right: 2%;
  bottom: 3%;
  position: absolute;
  float: left;
  font-size: 30px;
  width: 19%;
  background-color: #fff;
  height: 85%;
  text-align: center;
}
#title {
  top: 10%;
  left: 2%;
  bottom: 3%;
  position: absolute;
  float: left;
  font-size: 30px;
  width: 19%;
  background-color: #fff;
  height: 85%;
  text-align: center;
}
#title3 {
  top: 70%;
  left: 25%;
  bottom: 3%;
  position: absolute;
  float: left;
  font-size: 30px;
  width: 10%;
color: white;
  height: 25%;
  text-align: center;
}
#zi_daohan {
  top: 10%;
  left: 28%;
  bottom: 3%;
  position: absolute;
  float: left;
  font-size: 30px;
  width: 44%;

  height: 5%;
  text-align: center;
}
.ol-popup {
  position: absolute;
  background-color: white;
  -webkit-filter: drop-shadow(0 1px 4px rgba(0, 0, 0, 0.2));
  filter: drop-shadow(0 1px 4px rgba(0, 0, 0, 0.2));
  padding: 15px;
  border-radius: 10px;
  border: 1px solid #cccccc;
  bottom: 45px;
  left: -50px;
}

.ol-popup:after,
.ol-popup:before {
  top: 100%;
  border: solid transparent;
  content: " ";
  height: 0;
  width: 0;
  position: absolute;
  pointer-events: none;
}

.ol-popup:after {
  border-top-color: white;
  border-width: 10px;
  left: 48px;
  margin-left: -10px;
}

.ol-popup:before {
  border-top-color: #cccccc;
  border-width: 11px;
  left: 48px;
  margin-left: -11px;
}

.ol-popup-closer {
  text-decoration: none;
  position: absolute;
  top: 2px;
  right: 8px;
}

.ol-popup-closer:after {
  content: "✖";
}

#popup-content {
  font-size: 14px;
  font-family: "微软雅黑";
  width: 200px;
}

#popup-content .markerInfo {
  font-weight: bold;
}
#popup-content1 {
  font-size: 14px;
  font-family: "微软雅黑";
  width: 300px;
}

#popup-content1 .markerInfo {
  font-weight: bold;
}
#line {
  top: 80%;
}
.txt_item {
  font-size: 14px;
  font-family: "微软雅黑";
  // width: 200px;
}
.quarter-div {
  position: relative;
  width: 50%;
  height: 100%;

  float: left;
  top: 15px;
  // background-color: black;
}
.quarter-div-hen4 {
  position: relative;
  width: 100%;
  height: 100%;

  float: left;
  top: 15px;
}
.quarter-divshu3 {
  position: relative;
  width: 100%;
  height: 33%;
  font-size: 22px;
  float: left;
}
.quarter-shu2{
 position: relative;
  width: 100%;
  height: 50%;

  float: left;
}
.quarter-hen4 {
  position: relative;
  width: 25%;
  height: 100%;

  float: left;
}
.circle {
  padding-top: 10px;
  position: relative;
  left: 10px;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: gray;
}
/deep/.el-table thead tr>th{
background:#0a364a;
color: rgb(255, 255, 255);

}
// 更改表格每行背景颜色
/deep/.el-table tbody tr>td{
   background:#0a364a;
   color: rgb(255, 255, 255);
}
// 设置鼠标经过时背景颜色
/deep/.el-table tbody tr:hover>td{
    background-color:#013d57!important;
}

</style>
