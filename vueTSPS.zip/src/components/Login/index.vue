<template>
  <div class="login">
    <el-card class="card">
      <div class="login-title">路网最短路径距离估计服务平台</div>
    <el-tabs class="login_tab" stretch v-model="activateName">
          <el-tab-pane label="用户登入" name="loginName" >
            <el-form
              :model="user"
              status-icon
              :rules="rules"
              ref="loginForm"
              class="login_form"
              style=""
              
            >
              <el-form-item label="用户名" prop="username">
                <el-input type="text" v-model="user.username" ></el-input>
              </el-form-item>
              <el-form-item label="密码" prop="password">
                <el-input type="password" v-model="user.password"></el-input>
              </el-form-item>
              
              <el-form-item label="验证码" >
                <el-input style="width: 20%;float: left;" v-model="user.valide_code"></el-input>
         <div style=" width: 20%; height: 30px;  background-image: url('http://127.0.0.1:8000/verify');float: left;"></div>

                <!-- <img src="http://127.0.0.1:8000/verify" style="width: 100px;clip: rect(0, 100px, 100px, 70px);"/> -->
              </el-form-item>
 
              
              <el-form-item>
                <el-button type="primary" @click="submitForm('loginForm')"
                  >登录</el-button
                ></el-form-item>

            </el-form>
          </el-tab-pane>
          <el-tab-pane label="用户注册" name="registerName">
            <el-form
              :model="user"
              status-icon
              :rules="rules"
              ref="registerForm"
              class="login_form"
            >
              <el-form-item label="用户名" prop="username">
                <el-input type="text" v-model="user.username"></el-input>
              </el-form-item>
              <el-form-item label="密码" prop="password">
                <el-input type="password" v-model="user.password"></el-input>
              </el-form-item>
              <el-form-item label="确认密码" prop="surePassword">
                <el-input
                  type="password"
                  v-model="user.surePassword"
                ></el-input>
              </el-form-item>

              <el-form-item>
                <el-button type="primary" @click="submitForm('registerForm')"
                  >注册</el-button
                ></el-form-item
              >
            </el-form>
          </el-tab-pane>
        </el-tabs>
    </el-card>
  </div>
</template>


<script>

export default {
  data() {
    var validateUsername = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请输入用户名"));
      }
      callback();
    };
    var validatePassword = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请输入密码"));
      }
      callback();
    };
    var validatesurePassword = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请输入密码"));
      } else if (value !== this.user.password) {
        callback(new Error("两次输入密码不一致!"));
      } else {
        callback();
      }
    };

    return {
      user: {
        username: "",
        password: "",
        surePassword: "",
        valide_code:""
      },
      rules: {
        username: [{ validator: validateUsername, trigger: "blur" }],
        password: [{ validator: validatePassword, trigger: "blur" }],
        surePassword: [{ validator: validatesurePassword, trigger: "blur" }],
      },
      activateName: "loginName",
    };
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          /**
           * 区分登入或者注册
           *
           */
          if (this.activateName === "loginName") {
            /**
             * 登入
             *
             */
            this.$api.user
              .userlogin(this.user.username, this.user.password,this.user.valide_code)
              .then((res) => {
                console.log(res.data);
                if (res.data.code == 200) {
                  
                   sessionStorage.setItem('username',this.user.username)
                   sessionStorage.setItem('password',this.user.password)
                    sessionStorage.setItem('nickname',res.data.data.user.nickname)
                    sessionStorage.setItem('update_time',res.data.data.user.update_at)
                    if(res.data.data.user.status>=6)
                       sessionStorage.setItem('status',"管理员")
                    else
                       sessionStorage.setItem('status',"普通用户")
                  //  console.log(sessionStorage.getItem('username')) 
                   this.$router.push("/xingcheng");
                } else {
                  window.alert(res.data.data.info);
                }
              });
          }
          if (this.activateName === "registerName") {
            /**
             * 注册
             *
             */
            this.$api.user
              .userregister(this.user.username, this.user.password)
              .then((res) => {
                console.log(res.data);
                if (res.data.code == 200) {
                  window.alert(res.data.data.info);
                  this.activateName = "loginName";
                } else {
                  window.alert(res.data.data.info);
                }
                //  清空表单内容
                this.$refs[formName].resetFields();
              });
          }
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
  },
};
</script>

<style lang="less" scoped>
.login_tab {
  width: 500px;
  
  // background-color: rgba(255,255,255,0.3);//设置透明度
}/* 登录页面背景图片样式 */
.login {
  width: 100%;
  height: 100%;
  background: url("../../assets/images/bg.jpg") no-repeat;
  background-size: 100% 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  
}
.login_form{
 
}
/* el-card卡片组件样式 */
.el-card {
  width: auto;
  height: auto;
  
  
  
}
.card{
  background-color: rgba(255,255,255,0.6);//设置透明度
}
/* 登录标题样式 */
.login-title {
  font-size: 24px;
  font-weight: bold;
  text-align: center;
  
  
  
 
}
/* 登录按钮 */
.login-btn {
  text-align: right;
  
}
/deep/ .el-input__inner {
    height: 47px;
    background-color: rgba(255, 255, 255, 0.3);
}
</style>
