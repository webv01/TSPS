<template>
  <div class="mainbox">
    
    <userpath></userpath>
  </div>
</template>

<script>
import Userpath from '../../Map/userpath.vue';
export default {
  data() {
    return {
      
    };
  },
   components: {
    
      Userpath
  }
};
</script>

<style>
.mainbox {
  height: 100%;
  width: 100%;
}
.left_contain {
  flex: 4;
  
}
.right_contain {
  flex: 6;
  /* background-color: black; */
  /* background: url("/dijkstra") no-repeat; */
}
</style>