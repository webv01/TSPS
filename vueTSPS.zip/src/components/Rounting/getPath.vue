<template>
  <div id="mapCon">
    <!-- Popup -->
    <div id="popup" class="ol-popup" ref="popup" v-show="show">
      <a href="#" id="popup-closer" class="ol-popup-closer"></a>
      <div id="popup-content"></div>
    </div>
  </div>
</template>
<script>
// import img1 from "../../src/assets/blueIcon.png";
import axios from 'axios'
import "ol/ol.css";
import Map from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import TileWMS from "ol/source/TileWMS";
import OSM from "ol/source/OSM";
import ol from "../../utils/ol5/ol";
import { Icon, Stroke, Style, Circle, Fill, Text } from "ol/style";
import proj4 from "proj4";
export default {
  name: "",

  data() {
    return {
      show: false,
      map: {},
      data: {},
    };
  },
  mounted() {
 
    this.initMap();
  },

  methods: {
    initMap() {
      /**
       *   // 自定义坐标系
       */
      var projection_2362 = new ol.proj.Projection({
        code: "EPSG:2362",
        extent: [38344577.81, 2381399.02, 38617340.68, 5036052.73],
        units: "m",
        axisOrientation: "neu",
      });
      proj4.defs(
        "EPSG:2362",
        "+proj=tmerc +lat_0=0 +lon_0=114 +k=1 +x_0=38500000 +y_0=0 +a=6378140 +b=6356755.288157528 +units=m +no_defs"
      );
      //结合proj4在ol3中自定义坐标系,以4326为例(3857同理)
      ol.proj.addProjection(projection_2362);
      ol.proj.addCoordinateTransforms(
        "EPSG:4326",
        "EPSG:2362",
        function (coordinate) {
          return proj4("EPSG:4326", "EPSG:2362", coordinate);
        },
        function (coordinate) {
          return proj4("EPSG:2362", "EPSG:4326", coordinate);
        }
      );
      console.log(
        ol.proj.transform([37473426.9, 3968134.2], "EPSG:2362", "EPSG:4326")
      );
      console.log(ol.proj.transform([118, 32], "EPSG:4326", "EPSG:2362"));

      var shamp = new ol.layer.Image({
        //数据范围
        name: "注记图层",
        // extent: [37467916, 3964896.75, 37478080, 3972216.5],
        source: new ol.source.ImageWMS({
          //WMS服务基地址
     				url: 'http://127.0.0.1:8080/geoserver/wms',
               					//图层参数123
               					params: {
               						'LAYERS': '	biyesheji:polyline'
          },
          //服务类型
          serverType: "geoserver",
        }),
      });
      this.map = new ol.Map({
        //地图容器div的ID
        target: "mapCon",
        //地图容器中加载的图层
        layers: [shamp],
        //地图视图设置
        view: new ol.View({
          //地图初始中心点
          center: [37473426.9, 3968134.2],
          projection: projection_2362,
          //地图初始显示级别
          zoom: 10,
        }),
        controls: ol.control.defaults().extend([
          new ol.control.MousePosition({
            target: document.getElementById("mouse-position"),
          }),
        ]),
      });
     
    },


    createMark() {
      var features = new Array();
      for (var i = 0; i < this.data.length; i++) {
        let Ary = new ol.Feature({
          id: this.data[i].id,
          geometry: new ol.geom.Point(this.data[i].geo),
          time: this.data[i].data_time,
          status: this.data[i].point_status_name,
          name: this.data[i].sensor_type_name,
          value: this.data[i].point_value,
          pintName: this.data[i].point_location,
        });
        features.push(Ary);
        // features.push(
        //   new ol.Feature({
        //     geometry: new ol.geom.Point(this.data[i].geo),
        //   })
        // );
      }

      // 矢量要素数据源
      var source = new ol.source.Vector({
        features: features,
      });

      // 聚合标注数据源
      var clusterSource = new ol.source.Cluster({
        distance: 0, //这个是通过 distance 来控制两个点聚合的间距
        source: source,
      });
      // 加载聚合标注的矢量图层
      var styleCache = {}; //用于保存特定数量的聚合群的要素样式
      var clusters = new ol.layer.Vector({
        source: source,
        style: (feature) => {
          var text = feature.get("name"); //这个是每个点位对应的id
          var color = "";
          // mark点的填充颜色判断
          if (feature.get("status") === "正常") {
            color = "#55ff00";
          } else {
            color = "#ff0000";
          }
          return new Style({
            image: new Circle({
              radius: 10,
              stroke: new Stroke({
                color: "#fff",
              }),
              fill: new Fill({
                color: color,
              }),
              opacity: 0.75,
            }),
            text: new Text({
              //位置
              textAlign: "center",
              //基准线
              textBaseline: "middle",
              //文字样式
              font: "normal 14px 微软雅黑",
              //文本内容
              text: feature.get("id"),
              //文本填充样式（即文字颜色）
              fill: new ol.style.Fill({ color: "#aa3300" }),
              stroke: new ol.style.Stroke({ color: "#ffcc33", width: 2 }),
            }),
          });
        },

        // style: function (feature, resolution) {
        //   var size = feature.get("features").length; //获取该要素所在聚合群的要素数量
        //   var style = styleCache[size];
        //   if (!style) {
        //     style = [
        //       new Style({
        //         image: new Circle({
        //           radius: 10,
        //           stroke: new Stroke({
        //             color: "#fff",
        //           }),
        //           fill: new Fill({
        //             color: "#3399CC",
        //           }),
        //         }),
        //       }),
        //     ];
        //   }
        //   return style;
        // },
        zIndex: 999,
      });

      this.map.addLayer(clusters);
      // 弹窗
      this.map.on("singleclick", (e) => {
        let elPopup = this.$refs.popup;
        var popup = new ol.Overlay({
          element: elPopup,
          positioning: "bottom-center",
          stopEvent: false,
          // 信息框的上下位置
          offset: [0, 30],
        });
        this.map.addOverlay(popup);
        let feature = this.map.forEachFeatureAtPixel(
          e.pixel,
          (feature) => feature
        );

        if (feature) {
          let coordinates = feature.getGeometry().getCoordinates();
          // console.log(coordinates)
          setTimeout(() => {
            var content = document.getElementById("popup-content");
            content.innerHTML = "";

            this.show = true;
             
            this.data.map((item, index) => {
              if (item.id === feature.values_.id)
                this.$store.commit("setpointValue", item);
          
            });
      
            this.$store.commit("setpointid", feature.values_.id);
            // console.log(this.$store.getters.getpointValue[feature.values_.id]["id"])
            //在popup中加载当前要素的具体信息
            this.addFeatrueInfo(feature.values_);

            popup.setPosition(coordinates);
          }, 0);
        } else {
          this.show = false;
        }
      });
    },

  },
};
</script>
<style lang="less" scoped>
#mapCon {
  width: 100%;
  height: 95%;
  position: absolute;
}

</style>