
<template>
  <div class="mainbox" style="background: #004368">
    <div class="left_contain">
      <el-tree
        :data="data"
        @node-click="handleNodeClick"
        style="background: #004368; color: white"
      ></el-tree>
    </div>

    <div class="right_contain_data">
      <el-table
        :data="tableData"
        style="width: 100%; height: 80%; background: #004368; color: white"
        :default-sort="{ prop: 'date', order: 'descending' }"
      >
        <el-table-column prop="name" label="地点" width="250">
        </el-table-column>
        <el-table-column prop="jiedian" label="ID" width="250">
        </el-table-column>
        <el-table-column prop="value" label="车流情况 " width="300">
        </el-table-column>
        <el-table-column prop="flag" label="类型" width="200">
        </el-table-column>
        <el-table-column prop="time" label="时间" width="200">
        </el-table-column>
      </el-table>

      <el-pagination
        background
        layout="prev, pager, next"
        :total="totalPage"
        :current-page="currentPage"
        @current-change="handleCurrentChange"
        v-if="show"
      >
      </el-pagination>
    </div>
  </div>
</template>
 <script>
import qs from "qs";
export default {
  data() {
    return {
      show: false,
      data: [],
      defaultProps: {
        children: "children",
        label: "label",
      },
      alldata: [],
      tableData: [],
      currentPage: 1,
      totalPage: 100,
      options: [
        {
          time: "10:30:00",
          value: "选项1",
          label: "CH4 1001皮带头瓦斯",
        },

        {
          time: "10:31:12",
          value: "选项2",
          label: "CH4 3-5号层主硐皮带头瓦斯",
        },
        {
          time: "10:33:23",
          value: "选项3",
          label: "CH4 3-5号层中央变电所瓦斯",
        },
        {
          time: "10:31:23",
          value: "选项4",
          label: "CH4 3-5号层一盘区回风联巷1瓦斯",
        },
        {
          time: "10:35:23",
          value: "选项5",
          label: "CO 3-5号层一盘区辅助回风巷总回风一氧化碳",
        },
      ],
      value: "CH4 1001皮带头瓦斯",
    };
  },
  mounted() {
    this.getData();
    this.handleCurrentChange();
  },
  methods: {
    handleNodeClick(data) {
   
        this.alldata = [];
        var da;
        var flag;
        var na;
        var jiedian;
        na=data["label"]
        flag='拥堵'
        for (var i = 0; i < 500; i++) {

          da=generateRandomNumber(50, 300);
          if (da>120){
            flag='拥堵'
          }
          else{
            flag='通畅'
          }
          var data = {
            geo: data["label"],
            value: da,
            name: na,
            jiedian:36,
            flag: flag,
            time: generateTime(i),
          };
          this.alldata.push(data);
        }

        function generateRandomNumber(min, max) {
          return Math.floor(Math.random() * (max - min + 1)) + min;
        }

    function generateTime(index) {
  var currentDate = new Date(new Date(2024, 3, 8));
  currentDate.setSeconds(0);
  currentDate.setMilliseconds(0);
  currentDate.setMinutes(currentDate.getMinutes() + index * 5);
  return  currentDate.toLocaleString();
}
        this.handleCurrentChange(1)

        
        this.show = true;
     
    },
    async getData() {
      var name = new Array();

      var param = qs.stringify({
        data: this.value,
      });
      // 获取服务器的数据, 对this.allData进行赋值之后, 调用updateChart方法更新图表
      const { data: ret } = await this.$http.get(
        "http://127.0.0.1:8000/api/xingchneg"
      );
      for (var i = 0; i < ret.data.length; i++) {
        var data = {
          geo: ret.data[i]["geo"],
          value: ret.data[i]["value"],
          name: ret.data[i]["name"],
          label: ret.data[i]["name"],
        };
        if (!name.includes(ret.data[i]["name"])) {
          this.data.push(data);
          name.push(ret.data[i]["name"]);
        }
      }

    },
    handleCurrentChange(val) {
      //val 为当前页数
      this.tableData = this.alldata.slice((val - 1) * 10, (val - 1) * 10 + 10);
    },
    changevalue(val) {
       this.totalPage = 100 * 2;
 

 
      //this.alldata= this.alldata.sort((a, b) => b.create_time- a.create_time)
      this.tableData = this.tableData.slice(0, 10);
      console.log(123)
    },
  },
};
</script>

<style lang="less" scoped>
#mainbox {
  display: flex;

  position: absolute;
  top: 10%;
  height: 100%;
  width: 100%;
}
.left_contain {
  flex: 2;
}
.right_contain_data {
  flex: 8;
}
/deep/.el-table thead tr > th {
  background: #004368;
  color: rgb(255, 255, 255);
}
// 更改表格每行背景颜色
/deep/.el-table tbody tr > td {
  background: #004368;
  color: rgb(255, 255, 255);
}
// 设置鼠标经过时背景颜色
/deep/.el-table tbody tr:hover > td {
  background-color: #013d57 !important;
}
/deep/.el-tree tbody tr > td {
  background-color: #013d57 !important;
}
/* 改变被点击节点背景颜色，字体颜色 */
/deep/.el-tree-node:focus > .el-tree-node__content {
  background-color: #266c8a !important;
  // color: rgb(180, 55, 55) !important;
}
/*节点失焦时的背景颜色*/
/deep/.el-tree--highlight-current
  .el-tree-node.is-current
  > .el-tree-node__content {
  background-color: #4a9de7 !important;
  color: rgb(41, 7, 7) !important;
}
/deep/.el-tree-node__content {
  &:hover {
    background-color: #266c8a !important;
  }
}
</style>

