<template>

 <div class="path">
    <div class="demo-input-suffix">

 
  <el-input
    placeholder="请输入车辆ID"
    prefix-icon="el-icon-search"
    v-model="input1"
    style="width: 20%"
    >
  </el-input>
   <el-input
    placeholder="请选择日期2008-02-03"
    suffix-icon="el-icon-date"
    v-model="input2"
    style="width: 20%"
    >
    
  </el-input>
   <el-button type="primary" @click="upload">查询</el-button>
</div>
<div class="map-box" id="map-box" ref="mapBox"></div>
  </div>
  
</template>

<script>
import "ol/ol.css";
import Map from "ol/Map";
import View from "ol/View";
import { Tile } from "ol/layer";
import OSM from "ol/source/OSM";
import ol from "../../utils/ol5/ol";
import LineString from "ol/geom/LineString";
import { Icon, Stroke, Style, Circle, Fill, Text } from "ol/style";
import qs from "qs";
  export default {
    data() {
      return {
        input1:'1',
        input2: '',
              map: null, 
            clusters: null,// 用来存储map对象
      data: null,
      route: null,
      
      };
    },
     mounted() {
    this.initMap();
  },
  methods: {
    upload(){
      if (this.input1=='' && this.input2==''){
          console.log("kong")

      }
      else{
        this.getTaxidata();
      }
    
    },
     initMap() {
      this.map = new ol.Map({
        layers: [
          new ol.layer.Tile({
            source: new ol.source.OSM(), // OSM在线瓦片地图
          }),
        ],
        view: new ol.View({
          center: [116.69171, 39.85184], // 成都
          zoom: 10, // 设置初始化时的地图缩放层级
          projection: "EPSG:4326", // 坐标系
        }),
        target: "map-box", // 地图dom
      });
      this.getTaxidata();
    },
    // initMap() {
    //   this.map = new ol.Map({
    //     layers: [
    //       new ol.layer.Image({
    //     //数据范围
    //     name: "注记图层",
    //     // extent: [37467916, 3964896.75, 37478080, 3972216.5],
    //     source: new ol.source.ImageWMS({
    //       //WMS服务基地址
    //  				url: 'http://127.0.0.1:8080/geoserver/wms',
    //            					//图层参数123
    //            					params: {
    //            						'LAYERS': '	beijing:beijing'
    //       },
    //       //服务类型
    //       serverType: "geoserver",
    //     }),
    //   }),
    //     ],
    //     view: new ol.View({
    //       center: [116.69171, 39.85184], // 成都
    //       zoom: 12, // 设置初始化时的地图缩放层级
    //       projection: "EPSG:4326", // 坐标系
    //     }),
    //     target: "map-box", // 地图dom
    //   });
    //   this.getTaxidata();
    // },
    async getTaxidata() {
       
this.map.removeLayer(this.clusters);
      // this.vectorLayer.getSource().clear();
        var param = qs.stringify({
        carid: this.input1,
      });

      const { data: ret } = await this.$http.post(
        "http://127.0.0.1:8111/api/beijing_data",
        param
      );
      this.data = ret.data;
      console.log(this.data);
      this.showPoint();
    },
    showPoint() {
      var features = new Array();
      var routerline = [];
      for (var i = 0; i < this.data.length; i++) {
        var point = [
          parseFloat(this.data[i].x),
          parseFloat(this.data[i].y),
        ];

        routerline.push(point);
      }



      var routeFeature = new ol.Feature({
        type: "route",
        geometry: new LineString(routerline),
      });

      var startMarker = new ol.Feature({
        type: "iconStart",
        geometry: new ol.geom.Point(routerline[0]),
      });
     
      var source = new ol.source.Vector({
        features: [routeFeature, startMarker],
      });
      var styles = {
        route: new Style({
          stroke: new Stroke({
            width: 6,
            color: "#fc0000",
          }),
        }),
        iconStart: new Style({
          image:new Circle({
              radius: 1,
              stroke: new Stroke({
                color: "#fc0000",
              }),
              fill: new Fill({
                color: "#fc0000",
              }),
              opacity: 0.75,
            })
        })
      };
      this.clusters = new ol.layer.Vector({
        source: new ol.source.Vector({
        features: [startMarker,routeFeature ],
      }),
        style: function (feature) {
        
          return styles[feature.get("type")];
        },
      });
      this.map.addLayer( this.clusters);
    },
  },
  };
</script>

<style>
.map-box {
  /* 若不在App.vue中设置html、body的width和height，此时这样写div高度则为0，地图不会显示 */
  width: 100%;
  height: 100%;
}
</style>