<template>
  <div class="map-box" id="map-box" ref="mapBox"></div>
</template>
<script>
import 'ol/ol.css';
import Map from 'ol/Map';
import View from 'ol/View';
import {Tile} from 'ol/layer';
import OSM from "ol/source/OSM";
import ol from "../../utils/ol5/ol";

import { Icon, Stroke, Style, Circle, Fill, Text } from "ol/style";

export default {
  data() {
    return {
      map: null, // 用来存储map对象
      data:null
    }
  },
  mounted() {
    this.initMap();
    
  },
  methods: {
    initMap() {
      this.map = new ol.Map({
        layers: [
          new ol.layer.Tile({
            source: new ol.source.OSM(), // OSM在线瓦片地图
          })
        ],
        view: new ol.View({
          center: [-73.97755,40.75386], // 成都
          zoom: 10, // 设置初始化时的地图缩放层级
          projection: 'EPSG:4326', // 坐标系
  
        }),
        target: 'map-box', // 地图dom
      });
      this.getTaxidata()
  
    },
   async getTaxidata(){
        const { data: ret } = await this.$http.post("http://127.0.0.1:8000/api/getNyc_taxi");
        this.data=ret.data
        console.log(this.data)
        this. showPoint()
   },
   showPoint(){
    var features = new Array();
      for (var i = 0; i < 3000; i++) {
        var point=[this.data[i].pickup_longitude,this.data[i].pickup_latitude]
        let Ary = new ol.Feature({
          id: this.data[i].id,
         
          geometry: new ol.geom.Point(point),
          time: this.data[i].data_time,
        });
        features.push(Ary)
      }
           // 矢量要素数据源
      var source = new ol.source.Vector({
        features: features,
      });
      var clusters = new  ol.layer.Vector({
        source: source,
        style:  (feature) => {
          return new Style({
            image: new Circle({
              radius: 4,
              stroke: new Stroke({
                color: "#fc0000",
              }),
              fill: new Fill({
                color: "#fc0000",
              }),
              opacity: 0.75,
            })
          });
        },
   
      });
         this.map.addLayer(clusters);
   

   }
  }
}
</script>
<style>
.map-box {
  /* 若不在App.vue中设置html、body的width和height，此时这样写div高度则为0，地图不会显示 */
  width: 100%;
  height: 100%;
}
</style>
