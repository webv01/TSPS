<template>
  <div class="mainbox">
    
    <showTrack></showTrack>
  </div>
</template>

<script>
import showTrack from './showTrack.vue';
export default {
  data() {
    return {
      
    };
  },
   components: {
    
      showTrack
  }
};
</script>

<style>
.mainbox {
  height: 100%;
  width: 100%;
}
.left_contain {
  flex: 4;
  
}
.right_contain {
  flex: 6;
  /* background-color: black; */
  /* background: url("/dijkstra") no-repeat; */
}
</style>