
<template>
   <div>   
    <section class="mainbox">
      <div class="column">
        <div class="panel bar">
          
          <mapchart></mapchart>
          <div class="panel-footer"></div>
        </div>
        <div class="panel line">
       
         <line1></line1>
          <div class="panel-footer"></div>
        </div>
        <div class="panel pie">
          <h2>仪表</h2>
          <plate></plate>
          <div class="panel-footer"></div>
        </div>
      </div>
      <div class="column1">
        <div class="no">
          <div class="no-hd">
            <ul> 
              <li>335</li>
              <li>1</li>
            </ul>
          </div>
          <div class="no-bd">
            <ul>
              <li>监测点</li>
              <li>报警</li>
            </ul>
          </div>
        </div>
        <div class="map">
         <olmap></olmap>
        </div>
      </div>
      <!-- <div class="column">
        <div class="panel bar1">
           <mapchart></mapchart>
          <div class="panel-footer"></div>
        </div>
        <div class="panel line1">
        
             <line1></line1>
      
          <div class="panel-footer"></div>
        </div>
        <div class="panel pie1">
               <plate></plate>
          <div class="panel-footer"></div>
        </div>
      </div> -->
    </section>
   

   
    
   
  </div>
</template>

<script>
import mapchart from '@/components/Echarts/zhuzhang.vue'
import olmap from '@/components/olmap.vue'
import plate from '@/components/Echarts/Plate'
import line1 from '@/components/Echarts/line'
import '../assets/images/flexible'
import '../assets/index.css'

name:"ceshi"
export default {
components: { olmap ,mapchart,plate,line1},}
</script>

<style>

</style>