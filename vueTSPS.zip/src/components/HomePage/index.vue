
<template>
   <div>   
    <section class="mainbox">
      <div class="column">
        <div class="panel">
          
          <mapchart></mapchart>
          <div class="panel-footer"></div>
        </div>
        <div class="panel">
         <line1></line1>
          <div class="panel-footer"></div>
        </div>
        <div class="panel">
       
          <plate></plate>
          <div class="panel-footer"></div>
        </div>
      </div>
      <div class="column1">
        <div class="no">
          <div class="no-hd">
            <ul>
              <li>335</li>
              <li>4</li>
            </ul>
          </div>
          <div class="no-bd">
            <ul>
              <li>监测点</li>
              <li>报警</li>
            </ul>
          </div>
        </div>
        <div class="map">
         <olmap></olmap>
        </div>
      </div>
      <!-- <div class="column">
        <div class="panel bar1">
           <mapchart></mapchart>
          <div class="panel-footer"></div>
        </div>
        <div class="panel line1">
        
             <line1></line1>
      
          <div class="panel-footer"></div>
        </div>
        <div class="panel pie1">
               <plate></plate>
          <div class="panel-footer"></div>
        </div>
      </div> -->
    </section>
   

   
    
   
  </div>
</template>

<script>
import mapchart from '@/components/Echarts/zhuzhang.vue'
import olmap from '@/Map/Mark.vue'
import plate from '@/components/Echarts/Plate'
import line1 from '@/components/Echarts/line'

import '../../assets/index.css'
import '../../assets/flexible'
name:"homePage"
export default {

components: { olmap ,mapchart,plate,line1},}


</script>

<style>

</style>