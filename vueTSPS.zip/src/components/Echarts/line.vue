<!-- 销量趋势图表 -->
<template>
  <div class='com-container'>
    <div class="title" :style="comStyle">

      <span style="color:white;  font-size: 16px;font-family: '微软雅黑';">{{ '▎ ' +  showTitle }}</span>
    
    </div>
    <div class='com-chart' ref='trend_ref' ></div>
  </div>
</template>
<script>
import qs from "qs";
import { mapState } from 'vuex'
export default {
  data () {
    return {
      chartInstance: null,
      allData: null,
      titleFontSize:null
    }
  },
  mounted () {
    this.initChart()
    this.getData()
    window.addEventListener('resize', this.screenAdapter)
    this.screenAdapter()
  },
  destroyed () {
    window.removeEventListener('resize', this.screenAdapter)
  },
 watch: {
  //此时我监听的是对象，当$store.state.userInfo.Name发生修改时，此时需要深度监听才能监听到数据变化
  "$store.state.point":{
    deep:true,//深度监听设置为 true
    handler:function(newVal,oldVal){
      console.log("数据发生sdg变化啦"); //修改数据时，能看到输出结果
      this.allData[0]["point_location"]=this.$store.getters.getpointValue["point_location"]
        this.allData[0]["point_value"]=this.$store.getters.getpointValue["point_value"]
        this.allData[0]["point_value2"]=this.allData[0]["point_value"]* 1.2
        
        this.allData[1]["point_value"]=Math.round(Math.random()*(this.$store.getters.getpointValue["point_value"]+5))+1
        this.allData[1]["point_value2"]=Math.round(Math.random()*(this.$store.getters.getpointValue["point_value"]+5)) 
      this.updateChart()
    }
  }
},
  methods: {
    initChart () {
      this.chartInstance = this.$echarts.init(this.$refs.trend_ref,this.theme)
      const initOption = { 
            grid: {
          left: '5%',
          top: '40%',
          right: '5%',
          bottom: '0%',
          containLabel: true
        },
        tooltip: {
          trigger: 'axis'
        },
        
        legend: {
          left: 50,
          top: '25%',
          icon: 'circle',
          
        },
           xAxis: {
          type: 'category',
          boundaryGap: false
        },
        yAxis: {
          type: 'value'
        }}
      this.chartInstance.setOption(initOption)
    },
    async getData () {
    this.allData=[{
        "geo":[120.779516,40.620481],
        "data_time": "2023/8/23",
        "mine_code": "140211011523.00 ",
        "point_code": "14021101152301MN000414214M10",
        "point_location": "事故次数",
        "point_status_name": "异常",
        "point_value": "0",
        "sensor_type_name": "橙色风险",
        "point_value2": "1",
        "sensor_type_name2": "黄色风险",
        "point_value3": "0",
        "sensor_type_name3": "蓝色风险"
    },
    {
        "geo":[120.779381,40.624778],
        "data_time": "2023/8/23 ",
        "mine_code": "140211011523.00 ",
        "point_code": "14021101152301MN000414214M10",
        "point_location": "事故次数",
        "point_status_name": "异常",
        "point_value": "1",
        "sensor_type_name": "橙色风险",
        "point_value2": "1",
        "sensor_type_name2": "黄色风险",
        "point_value3": "0",
        "sensor_type_name3": "蓝色风险"
    }
    ,
    {
        "geo":[120.779381,40.624778],
        "data_time": "2023/8/23",
        "mine_code": "140211011523.00 ",
        "point_code": "14021101152301MN000414214M10",
         "point_location": "风险次数",
        "point_status_name": "异常",
        "point_value": "0",
        "sensor_type_name": "橙色风险",
        "point_value2": "1",
        "sensor_type_name2": "黄色风险",
        "point_value3": "2",
        "sensor_type_name3": "蓝色风险"
    }
    ]
      // 获取服务器的数据, 对this.allData进行赋值之后, 调用updateChart方法更新图表
      this.updateChart()
    },
    updateChart () {
   // 半透明的颜色值
      const colorArr1 = [
        'rgb(255, 145, 0)',
        'rgba(253, 228, 0)',
        'rgb(44, 110, 252)',
        'rgba(135, 165, 248)',
        'rgba(250, 105, 0, 0.5)'
      ]
      // 全透明的颜色值
      const colorArr2 = [
        'rgb(255, 145, 0)',
        'rgba(253, 228, 0)',
        'rgba(0, 68, 255)',
        'rgba(254, 33, 30, 0)',
        'rgba(250, 105, 0, 0)'
      ]

   var features = new Array();
      for (var i = 0; i < this.allData.length; i++) {
         let Ary={
            // geometry: this.allData[i].geo,
            time:this.allData[i].data_time,
            status:this.allData[i].point_status_name,
            name1:this.allData[i].sensor_type_name,
            value1:this.allData[i].point_value,
             name2:this.allData[i].sensor_type_name2,
            value2:this.allData[i].point_value2,
            name3:this.allData[i].sensor_type_name3,
            value3:this.allData[i].point_value3,
          }
           features.push(Ary);
      }
      // 类目轴的数据
      const time=features.map(item=>{
          return item.time
      })
    
  
      var data = [{
            "value":features.map(item=>{
          return item.value1
      }),
            "name": features[0].name1
    //         features.map(item=>{
    //       return item.name1
    //   })
        
        },{
         "value": features.map(item=>{
          return item.value2
      }),
         "name":features[0].name2,
    //       features.map(item=>{
    //       return item.name2
    //   })
        },
        {
            "value":features.map(item=>{
          return item.value3
      }),
            "name": features[0].name3
    //         features.map(item=>{
    //       return item.name1
    //   })
        
        }
        ];
     
      console.log(data)
      // 处理图表需要的数据
         // 处理数据
      // 类目轴的数据
    //   const timeArr = this.allData.common.month
    //   // y轴的数据 series下的数据
    //   const valueArr = this.allData[this.choiceType].data
      const seriesArr = data.map((item, index) => {
        return {
          name: item.name,
          type: 'line',
          data:item.value,
          
           color: colorArr1[index]
        }
      })
           // 图例的数据
      const legendArr =data.map(item => {
        return item.name
      })
    console.log(legendArr)
      const dataOption = {
        xAxis: {
          data: time
        }, 
        legend: {
          data: legendArr  ,
          textStyle: {
    color: 'white'
  },
        },
        textStyle: {
    color: 'white'
  },
        series: seriesArr
      }
      
      this.chartInstance.setOption(dataOption)
    },
     screenAdapter () {
    this.titleFontSize = this.$refs.trend_ref.offsetWidth / 100 * 3.6
    const adapterOption = {
        legend: {
          itemWidth: this.titleFontSize,
          itemHeight: this.titleFontSize,
          itemGap: this.titleFontSize,
          textStyle: {
            fontSize: this.titleFontSize
          }
        }
      }
        this.chartInstance.setOption(adapterOption)
        this.chartInstance.resize()
   },

  },
  
  computed:{
         // 设置给标题的样式
        
    comStyle () {
      return {
        fontSize: this.titleFontSize + 'px'
      }
    },
     showTitle () {
      if (!this.allData) {
        return ''
      } else {
        return this.allData[0].point_location
      }
    },
  }
}
</script>
<style lang='less' scoped>
.title {
  font-size: 16px;
  position: absolute;
  left: 20px;
  top: 20px;
  z-index: 10;
  color: rgb(255, 255, 255);
 
}
</style>
