<!-- 销量趋势图表 -->
<template>
  <div class='com-container'>
    <div class="title" :style="comStyle">
      <span>{{ '▎ ' +  showTitle }}</span>
      <span class="iconfont title-icon" :style="comStyle"  @click="showChoice = !showChoice">&#xe6eb;</span>
   
    </div>
    <div class='com-chart' ref='trend_ref'></div>
  </div>
</template>
<script>
import qs from "qs";
import { mapState } from 'vuex'
export default {
  data () {
    return {
      chartInstance: null,
      allData: null,
      titleFontSize:null
    }
  },
  mounted () {
    this.initChart()
    this.getData()
    window.addEventListener('resize', this.screenAdapter)
    this.screenAdapter()
  },
  destroyed () {
    window.removeEventListener('resize', this.screenAdapter)
  },
   watch: {
  //此时我监听的是对象，当$store.state.userInfo.Name发生修改时，此时需要深度监听才能监听到数据变化
  "$store.state.point":{
    deep:true,//深度监听设置为 true
    handler:function(newVal,oldVal){
      console.log("数据发生sdg变化啦"); //修改数据时，能看到输出结果
      this.allData[0]["point_location"]=this.$store.getters.getpointValue["point_location"]
          this.allData[0]["point_value"]=this.$store.getters.getpointValue["point_value"]
             this.allData[0]["point_value2"]=this.allData[0]["point_value"]* 0.75
        
        this.allData[1]["point_value"]=Math.round(Math.random()*(this.$store.getters.getpointValue["point_value"]+5))+0.5
        this.allData[1]["point_value2"]=this.allData[1]["point_value"]*1.3
      this.updateChart()
    }
  }
},
  methods: {
    initChart () {
      this.chartInstance = this.$echarts.init(this.$refs.trend_ref,this.theme)
      const initOption = { 
            grid: {
          left: '3%',
          top: '30%',
          right: '4%',
          bottom: '5%',
          containLabel: true
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          left: 50,
          top: '20%',
          icon: 'circle'
        },
           xAxis: {
          type: 'category'
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            type: 'bar'
          }]}
      this.chartInstance.setOption(initOption)
    },
    async getData () {
     this.allData=[{
        "geo":[120.779516,40.620481],
        "data_time": "2020/8/2 23:44",
        "mine_code": "140211011523.00 ",
        "point_code": "14021101152301MN000414214M10",
        "point_location": "CO 四风井副立井东侧工作面一氧化碳",
        "point_status_name": "异常",
        "point_value": "3.75",
        "sensor_type_name": "一氧化碳",
        "point_value2": "3",
        "sensor_type_name2": "瓦斯"
    },
    {
        "geo":[120.779381,40.624778],
        "data_time": "2020/8/3 2:04",
        "mine_code": "140211011523.00 ",
        "point_code": "14021101152301MN000414214M10",
        "point_location": "CO 四风井副立井东侧工作面一氧化碳",
        "point_status_name": "正常",
        "point_value": "4.5",
        "sensor_type_name": "一氧化碳",
        "point_value2": "2",
        "sensor_type_name2": "瓦斯"
    }
    ,
    {
        "geo":[120.779381,40.624778],
        "data_time": "2020/8/4 12:44",
        "mine_code": "140211011523.00 ",
        "point_code": "14021101152301MN000414214M10",
        "point_location": "CO 四风井副立井东侧工作面一氧化碳",
        "point_status_name": "正常",
        "point_value": "5",
        "sensor_type_name": "一氧化碳",
        "point_value2": "3.5",
        "sensor_type_name2": "瓦斯"
    }
    ]
      // 获取服务器的数据, 对this.allData进行赋值之后, 调用updateChart方法更新图表
      this.updateChart()
    },
    updateChart () {
   // 半透明的颜色值
      const colorArr1 = [
        'rgba(11, 168, 44, 0.5)',
        'rgba(44, 110, 255, 0.5)',
        'rgba(22, 242, 217, 0.5)',
        'rgba(254, 33, 30, 0.5)',
        'rgba(250, 105, 0, 0.5)'
      ]
      // 全透明的颜色值
      const colorArr2 = [
        'rgba(11, 168, 44, 0)',
        'rgba(44, 110, 255, 0)',
        'rgba(22, 242, 217, 0)',
        'rgba(254, 33, 30, 0)',
        'rgba(250, 105, 0, 0)'
      ]

   var features = new Array();
      for (var i = 0; i < this.allData.length; i++) {
         let Ary={
            // geometry: this.allData[i].geo,
            time:this.allData[i].data_time,
            status:this.allData[i].point_status_name,
            name1:this.allData[i].sensor_type_name,
            value1:this.allData[i].point_value,
             name2:this.allData[i].sensor_type_name2,
            value2:this.allData[i].point_value2,
          }
           features.push(Ary);
      }
      // 类目轴的数据
      const time=features.map(item=>{
          return item.time
      })
    
  
      var data = [{
            "value":features.map(item=>{
          return item.value1
      }),
            "name": features[0].name1
    //         features.map(item=>{
    //       return item.name1
    //   })
        
        },{
         "value": features.map(item=>{
          return item.value2
      }),
         "name":features[0].name2,
    //       features.map(item=>{
    //       return item.name2
    //   })
        }];
     
      console.log(data)
      // 处理图表需要的数据
         // 处理数据
      // 类目轴的数据
    //   const timeArr = this.allData.common.month
    //   // y轴的数据 series下的数据
    //   const valueArr = this.allData[this.choiceType].data
      const seriesArr = data.map((item, index) => {
        return {
          name: item.name,
          type: 'bar',
          data:item.value,
          
             areaStyle: {
            color: new this.$echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: colorArr1[index]
              }, // %0的颜色值
              {
                offset: 1,
                color: colorArr2[index]
              } // 100%的颜色值
            ])
          }
        }
      })
           // 图例的数据
      const legendArr =data.map(item => {
        return item.name
      })
    console.log(legendArr)
      const dataOption = {
        xAxis: {
          data: time
        }, 
        legend: {
          data: legendArr
        },
        series: seriesArr
      }
      
      this.chartInstance.setOption(dataOption)
    },
     screenAdapter () {
    this.titleFontSize = this.$refs.trend_ref.offsetWidth / 100 * 3.6
    const adapterOption = {
        legend: {
          itemWidth: this.titleFontSize,
          itemHeight: this.titleFontSize,
          itemGap: this.titleFontSize,
          textStyle: {
            fontSize: this.titleFontSize
          }
        }
      }
        this.chartInstance.setOption(adapterOption)
        this.chartInstance.resize()
   },

  },
  
  computed:{
         // 设置给标题的样式
        
    comStyle () {
      return {
        fontSize: this.titleFontSize + 'px'
      }
    },
     showTitle () {
      if (!this.allData) {
        return ''
      } else {
        return this.allData[0].point_location
      }
    },
  }
}
</script>
<style lang='less' scoped>
.title {
  position: absolute;
  left: 20px;
  top: 20px;
  z-index: 10;
  color: rgb(5, 5, 5);
 
}
</style>
