<template>
  <div class="com-container">
    <div class="title">
      <span style="color:white;  font-size: 16px;font-family: '微软雅黑';">{{ "▎ " + this.allData["point_location"] }}</span>
    </div>
    <div class="com-chart" ref="plate_ref" style="padding-top: 10%;"></div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      chartInstance: null,
      allData: {
        geo: [120.779516, 40.620481],
        data_time: "2020/8/2 23:44",
        mine_code: "140211011523.00 ",
        point_code: "14021101152301MN000414214M10",
        point_location: "ID",
        point_status_name: "异常",
        point_value: "",
        sensor_type_name: "一氧化碳",
        point_value2: "3",
        sensor_type_name2: "瓦斯",
      },
      titleFontSize: null,
    };
  },

  mounted() {
    this.initChart();

    this.getData();
    this.updateChart();
    // window.addEventListener("resize", this.screenAdapter);
    // let that = this;

    // setInterval(() => {
    //   setTimeout(function () {
    //     that.data = sessionStorage.getItem("pointValue");
    //     that.allData["point_value"] = sessionStorage.getItem("pointValue");
    //     that.updateChart();
    //   }, 2000);
    // }, 2000);
    // window.addEventListener("setItem", () => {
    //   this.data = sessionStorage.getItem("pointValue");
    // });

    // this.screenAdapter();
    titleFontSize: 0;
  },
  destroyed() {
    window.removeEventListener("resize", this.screenAdapter);
    clearInterval(this.timerId);
  },
  watch: {
    //此时我监听的是对象，当$store.state.userInfo.Name发生修改时，此时需要深度监听才能监听到数据变化
    "$store.state.point": {
      deep: true, //深度监听设置为 true
      handler: function (newVal, oldVal) {
        console.log("数据发生sdg变化啦"); //修改数据时，能看到输出结果
        this.allData["point_location"] =
          this.$store.getters.getpointid;
        this.allData["point_value"] =
          this.$store.getters.getpointValue;
          console.log("sada"+this.$store.getters.getpointValue )
        this.updateChart();
      },
    },
  },
  methods: {
    initChart() {
      this.chartInstance = this.$echarts.init(this.$refs.plate_ref, this.theme);
      const initOption = {
        grid: {
          left: "3%",
          top: "35%",
          right: "4%",
          bottom: "1%",
          containLabel: true,
        },
        tooltip: {
          trigger: "axis",
        },
        textStyle: {
    color: 'white'
  },
        legend: {
          left: 0,
          top: "10%",
          icon: "circle",
        },
      };
      this.chartInstance.setOption(initOption);
    },
    getData() {
      // this.allData=this.$store.getters.getpointValue

      this.updateChart();
    },
    updateChart() {
      var option = {
        series: [
          {
            type: "gauge",
            data: [
              {
                value: this.allData["point_value"],
                itemStyle: {
                  // 指针的样式
                  color: "pink", // 指针的颜色
                },
              }, // 每一个对象就代表一个指针
            ],
            min: 0, // min max 控制仪表盘数值范围
            max: 100,
          },
        ],
      };
      this.chartInstance.setOption(option);
    },
    screenAdapter() {},
    startInterval() {
      if (this.timerId) {
        clearInterval(this.timerId);
      }
      this.timerId = setInterval(() => {
        this.startValue++;
        this.endValue++;
        if (this.endValue > this.allData.length - 1) {
          this.startValue = 0;
          this.endValue = 9;
        }
        this.updateChart();
      }, 2000);
    },
  },
  computed: {
    // 设置给标题的样式

    comStyle() {
      return {
        fontSize: this.titleFontSize + "px",
      };
    },
    showTitle() {
      if (!this.allData) {
        return "";
      } else {
        return this.allData[0].point_location;
      }
    },
  },
};
</script>

<style>
.title {
  font-size: 14px;
  position: absolute;
  left: 20px;
  top: 20px;
  z-index: 10;
  color: rgb(5, 5, 5);
}

</style>