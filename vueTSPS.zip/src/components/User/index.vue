<template>
  <div class="mainbox">
    <div class="left_contain">
      <div class="avatar-div">
        <el-avatar
          src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png"
          :size="150"
        ></el-avatar>
        <div style="margin-top: 10px; text-size: 150px; left: 50%">
          昵称:{{ this.form.nickname }}
        </div>
      </div>
    </div>

    <div class="right_contain">
      <div v-show="showGroup & updatepassword" class="user_contain">
        <el-descriptions
          title="用户信息"
          :column="3"
          border
          style="text-align: center"
        >
          <el-descriptions-item>
            <template slot="label">
              <i class="el-icon-user"></i>
              用户名
            </template>
            {{ this.form.username }}
          </el-descriptions-item>
          <el-descriptions-item>
            <template slot="label">
              
              权限
            </template>
           {{this.form.status }}
          </el-descriptions-item>
          <el-descriptions-item>
            <template slot="label">
              <i class="el-icon-location-outline"></i>
              更新时间
            </template>
            {{this.form.update_time }}
          </el-descriptions-item>
          <el-descriptions-item>
            <template slot="label">
              <i class="el-icon-tickets"></i>
              昵称
            </template>
            {{this.form.nickname}}
          </el-descriptions-item>
          <el-descriptions-item>
            <template slot="label">
              <i class="el-icon-office-building"></i>
              联系地址
            </template>
            江苏省苏州市吴中区吴中大道 1188 号
          </el-descriptions-item>
        </el-descriptions>
        <el-button
          type="primary"
          @click="transfer('信息修改')"
          class="button_position"
        style="margin-top: 50px"
          >信息修改</el-button
        >
          <el-button
          type="primary"
          @click="transfer('密码修改')"
          class="button_position"
         style="margin-top: 50px"
          >密码修改</el-button
        >
      </div>
      <div class="user_contain">
        <el-form label-width="10%" style="margin-top: 50px" v-show="!updatepassword">
          <el-form-item label="用户名">
            <el-col :span="6">
              <el-input
                v-model="form.username"
                disabled
                placeholder="请输入用户名"
              ></el-input>
            </el-col>
          </el-form-item>

          <el-form-item label="密码">
            <el-col :span="10">
              <el-input v-model="form.password" placeholder="请输入新密码"></el-input>
            </el-col>
          </el-form-item>

          <el-form-item label="验证码">
            <el-col :span="4">
              <el-input v-model="form.valide_code" placeholder="请输入验证码"></el-input>
            </el-col>
            <img
              style="width: 135px; height: 50px"
              src="http://127.0.0.1:8111/verify"
            />
          </el-form-item>
          <el-form-item>
            <el-button type="success" @click="updatepass('密码修改')" round
              >密码修改</el-button
            ><el-button round @click="transfer('密码修改')">返回</el-button>
          </el-form-item>
        </el-form>
      </div>
        <div class="user_contain">
        <el-form label-width="10%" style="margin-top: 50px" v-show="!showGroup">
                   <el-form-item label="用户名">
            <el-col :span="6">
              <el-input
                v-model="form.username"
                disabled
                placeholder="请输入用户名"
              ></el-input>
            </el-col>
          </el-form-item>
            <el-form-item label="昵称">
            <el-col :span="6">
              <el-input v-model="form.nickname" placeholder="请输入新昵称"></el-input>
            </el-col>
          </el-form-item>
            <!-- <el-form-item label="昵称">
            <el-col :span="6">
              <el-input
                v-model="form.nickname"
                placeholder="请输入昵称"
              ></el-input>
            </el-col>
          </el-form-item> -->
          
          <el-form-item>
            <el-button type="success" @click="save('信息修改')" round
              >更 新</el-button
            ><el-button round @click="transfer('信息修改')">返回</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
 import qs from "qs";
export default {
  data() {
    return {
      showGroup: true,
      updatepassword:true,
      form: {
         username: '',
        nickname: '',
        status: '',
        update_time:'',
        valide_code:''
      },
    };
  },
  created() {
    const CheckId = this.$cookies.get("use");
    console.log(CheckId);
    this.form.username = sessionStorage.getItem("username");
    this.form.nickname = sessionStorage.getItem("nickname");
this.form.status = sessionStorage.getItem("status");
    this.form.update_time = sessionStorage.getItem("update_time");
  },
  methods: {
    transfer(info) {
      if (info=='密码修改')
         
         this.updatepassword=!this.updatepassword
      else if (info=='信息修改')
        {
          
          this.showGroup = !this.showGroup
        }
         
    },
    async save(info) {
          var param = qs.stringify({
                     username: this.form.username,
        nickname: this.form.nickname
    
         
        });
        // console.log(res.data);
        // const { data: ret } = await this.$http.post("http://127.0.0.1:8111/api/updateuser",param);
       const { data: res } = await axios.post("http://127.0.0.1:8111/api/updateuser",param) 
                console.log(res);
                if (res.code == 200) {
                  
                  
                   
                    sessionStorage.setItem('nickname',res.data.user.nickname)
                    sessionStorage.setItem('update_time',res.data.user.update_at)


                } else {
                  window.alert(res.data.info);
                }

      this.transfer(info)
    },
        async updatepass(info) {
          var param = qs.stringify({
                     username: this.form.username,
                     password: this.form.password,
                     valide_code:this.form.valide_code
    
         
        });
        // console.log(res.data);
        // const { data: ret } = await this.$http.post("http://127.0.0.1:8111/api/updateuser",param);
       const { data: res } = await axios.post("http://127.0.0.1:8111/api/password",param) 
                console.log(res);
                if (res.code == 200) {
                  
                  
                   
                         window.alert(res.data.info);


                } else {
                  window.alert(res.data.info);
                }

      this.transfer(info)
    },
  },
};
</script>

<style>
.mainbox {
  height: 100%;
  width: 100%;
}
.left_contain {
  flex: 3;
}
.right_contain {
  flex: 7;
}
.avatar-div {
  font-size: 50px;
  display: block;
  text-align: center;
  margin-top: 20%;
}
.user_contain {
  margin-top: 15%;
}

</style>