<!-- 销量趋势图表 -->
<template>
  <div class='com-container'  >
    <div class="title" :style="comStyle">
      <span>{{ '▎ 实时监控'  }}</span>
      <!-- <span class="iconfont title-icon" :style="comStyle"  @click="showChoice = !showChoice">&#xe6eb;</span> -->
   
    </div>
    <div class='com-chart' ref='trend_ref' ></div>
  </div>
</template>
<script>
import qs from "qs";
import { mapState } from 'vuex'
export default {
  data () {
    return {
      chartInstance: null,
      allData: [{"id": "177", "chunnel1": "5054", "chunnel2": "6613", "chunnel3": "17454", "chunnel4": "10197", "chunnel5": "15080", "chunnel6": "20508", "chunnel7": "12808", "chunnel8": "16626", "chunnel9": "15928", "chunnel10": "16179", "chunnel11": "15506", "chunnel12": "14471", "time": "2022-11-25T17:21:36"},{"id": "177", "chunnel1": "5054", "chunnel2": "6613", "chunnel3": "17454", "chunnel4": "10197", "chunnel5": "15080", "chunnel6": "20508", "chunnel7": "12808", "chunnel8": "16626", "chunnel9": "15928", "chunnel10": "16179", "chunnel11": "15506", "chunnel12": "14471", "time": "2022-11-25T17:21:36"}],
      titleFontSize:null,
      flag:0
    }
  },
  mounted () {
    this.getData()
    this.initChart()
    this.getData()
    window.addEventListener('resize', this.screenAdapter)
    this.screenAdapter()
    setInterval(() => {
      this.getData()
  }, 3500)
  },
  destroyed () {
    window.removeEventListener('resize', this.screenAdapter)
  },

  methods: {
    initChart () {
      this.chartInstance = this.$echarts.init(this.$refs.trend_ref,this.theme)
      const initOption = { 
          grid: {
          left: '3%',
          top: '30%',
          right: '4%',
          bottom: '5%',
          containLabel: true
        },
        tooltip: {
          trigger: 'axis',
          textStyle: {
      fontSize: 50 // 字体大小
    },
  
          
        },
        legend: {
          left: 50,
          top: '10%',
          icon: 'circle'
        },
           xAxis: {
          type: 'category',
          boundaryGap: false,
          axisLabel: {
            textStyle: {
              fontSize: "80",
            },
          },
        },
        yAxis: {
          type: 'value'          ,
          axisLabel: {
            textStyle: {
              fontSize: "80",
            },
          },
        }}
      this.chartInstance.setOption(initOption)
    },
    async getData () {
      const { data: ret } = await this.$http.get(
        "http://127.0.0.1:8111/api/data_time"
      );
      let that=this
      if(ret.id!=this.allData[this.allData.length-1].id){
        that.flag++
         console.log('that.flag'+that.flag)
        if (parseInt(that.flag)%2==0){
         console.log('删除')
          this.allData.shift()
        }
this.allData.push(ret)
      }
      
      
   
      // 获取服务器的数据, 对this.allData进行赋值之后, 调用updateChart方法更新图表
      this.updateChart()
    },
    updateChart () {
   // 半透明的颜色值
      const colorArr1 = [
        'rgba(11, 168, 44, 0.5)',
        'rgba(44, 110, 255, 0.5)',
        'rgba(22, 242, 217, 0.5)',
        'rgba(254, 33, 30, 0.5)',
        'rgba(250, 105, 0, 0.5)'
        ,
        'rgba(250, 105, 0, 0.5)'
        ,
        'rgba(250, 105, 0, 0.5)'
      ]
      // 全透明的颜色值
      const colorArr2 = [
        'rgba(11, 168, 44, 0)',
        'rgba(44, 110, 255, 0)',
        'rgba(22, 242, 217, 0)',
        'rgba(254, 33, 30, 0)',
        'rgba(250, 105, 0, 0)'
        ,'rgba(250, 105, 12, 0)',
        'rgba(250, 105, 0, 12)'
      ]

   var features = new Array();
      for (var i = 0; i < this.allData.length; i++) {
         let Ary={
            // geometry: this.allData[i].geo,
            time:this.allData[i].time.substring(11,20),
            chunnel1:this.allData[i].chunnel1,
            chunnel2:this.allData[i].chunnel2,
            chunnel3:this.allData[i].chunnel3,
             chunnel4:this.allData[i].chunnel4,
            chunnel5:this.allData[i].chunnel5,
                        chunnel6:this.allData[i].chunnel6,
            chunnel7:this.allData[i].chunnel7,
            chunnel8:this.allData[i].chunnel8,
             chunnel9:this.allData[i].chunnel9,
            chunnel10:this.allData[i].chunnel10,

             chunnel11:this.allData[i].chunnel11,
              chunnel12:this.allData[i].chunnel12,
          }
           features.push(Ary);
      }
      // 类目轴的数据
      const time=features.map(item=>{ 
          return item.time
      })
    
  
      var data = [{
            "value":features.map(item=>{
          return item.chunnel1
      }),
       "name": "chunnel1",
            // "name": features[len(features)-1].time
    //         features.map(item=>{
    //       return item.name1
    //   })
        
        },{
         "value": features.map(item=>{
          return item.chunnel2
      }),
      
         "name": "chunnel2",
    //       features.map(item=>{
    //       return item.name2
    //   })
        }
        ,{
         "value": features.map(item=>{
          return item.chunnel3
      }),
       "name": "chunnel3",
        //  "name": features[len(features)-1].time,
    //       features.map(item=>{
    //       return item.name2
    //   })
        },{
         "value": features.map(item=>{
          return item.chunnel4
      }),
       "name": "chunnel4",
        //  "name": features[len(features)-1].time,
    //       features.map(item=>{
    //       return item.name2
    //   })
        },
    //     {
    //      "value": features.map(item=>{
    //       return item.chunnel5
    //   }),
    //    "name": "chunnel5",
    //     //  "name": features[len(features)-1].time,
    // //       features.map(item=>{
    // //       return item.name2
    // //   })
    //     },{
    //      "value": features.map(item=>{
    //       return item.chunnel6
    //   }),
    //    "name": "chunnel6",
    //     //  "name": features[len(features)-1].time,
    // //       features.map(item=>{
    // //       return item.name2
    // //   })
    //     }
        
        
        ];
     
      console.log(data)
      // 处理图表需要的数据
         // 处理数据
      // 类目轴的数据
    //   const timeArr = this.allData.common.month
    //   // y轴的数据 series下的数据
    //   const valueArr = this.allData[this.choiceType].data
      const seriesArr = data.map((item, index) => {
        return {
          name: item.name,
          type: 'line',
          data:item.value,
          
             areaStyle: {
            color: new this.$echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: colorArr1[index]
              }, // %0的颜色值
              {
                offset: 1,
                color: colorArr2[index]
              } // 100%的颜色值
            ])
          }
        }
      })
           // 图例的数据
      const legendArr =data.map(item => {
        return item.name
      })
    console.log(legendArr)
      const dataOption = {
        xAxis: {
          data: time
        }, 
        legend: {
          data: legendArr 
        },
        series: seriesArr
      }
      
      this.chartInstance.setOption(dataOption)
    },
     screenAdapter () {
    this.titleFontSize = this.$refs.trend_ref.offsetWidth / 100 * 1.6
    const adapterOption = {
        legend: {
          itemWidth: this.titleFontSize,
          itemHeight: this.titleFontSize,
          itemGap: this.titleFontSize,
          textStyle: {
            fontSize: this.titleFontSize
          }
        },axisLabel: {
            textStyle: {
              fontSize: "25",
            },
          },
      }
        this.chartInstance.setOption(adapterOption)
        this.chartInstance.resize()
   },

  },
  
  computed:{
         // 设置给标题的样式
        
    comStyle () {
      return {
        fontSize: this.titleFontSize*1.5 + 'px'
      }
    },
     showTitle () {
      if (!this.allData) {
        return ''
      } else {
        return this.allData[0].point_location
      }
    },
  }
}
</script>
<style lang='less' scoped>
.title {
  position: absolute;
  left: 20px;
  top: 100px;
  z-index: 10;
  color: rgb(5, 5, 5);
 
}
.com-chart {
  width: 100%;
  height: 100%;
  overflow: hidden;
  font-size: 100px;
}
</style>
