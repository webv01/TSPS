
<template>
   <div>   
    <section class="mainbox">
      <div class="column">
        <div class="panel">
          
          <mapchart></mapchart>
          <div class="panel-footer"></div>
        </div>
        <div class="panel">
         <line1></line1>
          <div class="panel-footer"></div>
        </div>
        <div class="panel">
       
          <!-- <plate></plate> -->
          <div class="panel-footer"></div>
        </div>
      </div>
      <div class="column1">
        <div class="no">
          <div class="no-hd">
            <ul>
              <li>335</li>
              <li>4</li>
            </ul>
          </div>
          <div class="no-bd">
            <ul>
              <li>监测点</li>
              <li>报警</li>
            </ul>
          </div>
        </div>
        <div class="map">
         <plate></plate>
        </div>
      </div>
      <!-- <div class="column">
        <div class="panel bar1">
           <mapchart></mapchart>
          <div class="panel-footer"></div>
        </div>
        <div class="panel line1">
        
             <line1></line1>
      
          <div class="panel-footer"></div>
        </div>
        <div class="panel pie1">
               <plate></plate>
          <div class="panel-footer"></div>
        </div>
      </div> -->
    </section>
   

   
    
   
  </div>
</template>

<script>
import plate from '@/components/Echarts/Plate'

import '../../assets/index.css'
import '../../assets/flexible'
  export default {
    components: {plate},
    name : 'test',
    data() {
      return {
        websock: null,
    actions: { "action": "ping", "Authorization": "Bearer N2EzMzU3NDMzMDU5MzAzNzUxNmU2ODZjNTM2OTJmNTQ0Mzc3NmEzNDZmMzQ2NDRlMzU1OTQyNGQ1MDM5Njk0ZDc0NTczMzRlMzk0NzZkNTc3NDRjNTU2NzVhNzI0NTU2NmE2YzRiNDk0Nzc1MzU1OTYyNmM2YTYyNGYzNzcwMzMzMTRkMzYyZjYzNmU3MTY0MmY3NDJmNDkzMTU2MzY3MDc4MmI0ZDM2NDk0NjJmNmQyYjYxNzg3NjczNzE3OTMyNGY1MTQyNGM2ZDcxMmY2ODZlNGQ3MzNk" },
msg:{ "action":"get_last_mosaic", "keys": ["wenshidu", "wenshidu2"], "object_id": "OBJ1865657700007" }
      }
    },
    created() {
      this.initWebSocket();
      this.sendSock()


 
   
      
    },
    destroyed() {
      this.websock.close() //离开路由之后断开websocket连接
    },
    methods: {
    
      initWebSocket(){ //初始化weosocket
        const wsuri = 'ws:lntu.mixiot.top:31503/apiproxy/api';
        this.websock = new WebSocket(wsuri);
        this.websock.onmessage = this.websocketonmessage;
        this.websock.onopen = this.websocketonopen;
        this.websock.onerror = this.websocketonerror;
        this.websock.onclose = this.websocketclose;
           
      },
sendSock(agentData) {

  let that=this

  setInterval(() => {
    setTimeout(function () {
        if( that.websock.readyState==that.websock.OPEN){
            that.websock.send(JSON.stringify(that.msg))
            
        }
     
    }, 2000
    )
  }, 2000)
    
},




      websocketonopen(){ //连接建立之后执行send方法发送数据
        let actions = {
    "action": "ping",
    "Authorization": "Bearer N2EzMzU3NDMzMDU5MzAzNzUxNmU2ODZjNTM2OTJmNTQ0Mzc3NmEzNDZmMmY0ZTQzNDU2MTM5NjQ2YjQ1Mzg0ODc4NTQ0NjZkNTY0YzMyNzc3YTU1NmI1MjQzNTU0MTc1NGI3MjMxNWEzMDRhNmY1MTZiMzA3YTc2NTU0MzMwMzg3OTM1NTg2MzQ0NzkzODc1NzQ1ODYyNzI1ODU4MzQ1NDUzMzA2ZjZkNjM2Mzc2NzU2YjUxNDYzNjU2MzM1MzQxMmI2OTM2NjE1MjZlNDE0MTQxNmM0OTNk"
};
this.websock.send(JSON.stringify(this.actions));
        
        console.log('打开')
      },
      websocketonerror(){//连接建立失败重连
        this.initWebSocket();
      },
      websocketonmessage(e){ //数据接收
        const redata = JSON.parse(e.data);
        // console.log("123",redata)
        if (redata.result.data[0]["wenshidu"]){
          // sessionStorage.setItem('pointValue',redata.result.data[0]["wenshidu"]+0.1)
          // this.$store.getters.getpointValue["point_value"]=redata.result.data[0]["wenshidu"]+0.1
          sessionStorage.setItem('pointValue',redata.result.data[0]["wenshidu"])
  
        console.log(sessionStorage.getItem('pointValue'))
        }
      
        
      },
      websocketsend(Data){//数据发送
        this.websock.send(Data);
      },
      websocketclose(e){  //关闭
        console.log('断开连接',e);
      },
    },
  }
</script>
<style lang='less'>
 
</style>
