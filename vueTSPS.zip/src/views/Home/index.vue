<template>
  <el-container class="screen-container">
    <el-header style=" width: 102%;
">
      <el-menu
        :default-active="activeIndex"
        class="el-menu-demo"
        mode="horizontal"
        @select="handleSelect"
        background-color="#002e65"
        text-color="#ffffff"
        active-text-color="#ffd04b"
        router
        
      >
        <!-- <el-menu-item index="/HomePage">首页</el-menu-item> -->
        <el-menu-item index="/xingcheng">首页</el-menu-item>
        <el-menu-item index="/Hot">服务资源</el-menu-item>
        <!-- <el-menu-item index="/user">用户模块</el-menu-item> -->
        <el-menu-item index="/data">数据检索</el-menu-item>
        <el-menu-item index="/TrackPlay">轨迹查询</el-menu-item>
        <el-menu-item index="/Information">信息公告</el-menu-item>
        <el-menu-item index="/test">test</el-menu-item>
        <!-- <el-menu-item index="/road">信息公告</el-menu-item> -->
        <!-- <el-menu-item  index="Nyc_taxi">nyc</el-menu-item>
             <el-menu-item  index="showline">showline</el-menu-item> -->
        <!-- <el-menu-item index="beijing">服务资源</el-menu-item> -->
        <!-- <el-menu-item  index="xingcheng">首页</el-menu-item> -->

        <!-- <el-menu-item index="#/ceshi">测试</el-menu-item> -->
       
        <div class="title">
 <img  :src="url1" alt="" />
        </div>
        <span class="title_i">>>>>>>>>服务平台
</span>
        <div class="user" style="color:white">
     
消息
设置
退出
          <img class="user_name" src="../../Map/img/地图 (1).png" alt="" >

          <!-- <span class="user_name"></span> -->
          <!-- <el-button type="danger" round @click="signout()">退出</el-button> -->
        </div>
      </el-menu></el-header
    >
    
    <router-view style="overflow: hidden   width: 102%;
  height: 100%;">
  
  </router-view>
   <div v-if="isHomePage">
    <!-- 瓦斯防治、火灾防治、冲击地压 -->
      <div id="zi_daohan"  >
             <el-button @click="checkHomePage('/data')" style="background:#0a364a;color:white">
             <router-link to="/data" style="background:#0a364a;color:white">安全监管</router-link>
             </el-button>
                        <el-button @click="checkHomePage('/data')" style="background:#0a364a;color:white">
             <router-link to="/data" style="background:#0a364a;color:white">人员定位</router-link>
             </el-button>             <el-button @click="checkHomePage('/data')" style="background:#0a364a;color:white">
             <router-link to="/data" style="background:#0a364a;color:white">视频监管</router-link>
             </el-button>  <el-button @click="checkHomePage('/data')" style="background:#0a364a;color:white">
             <router-link to="/data" style="background:#0a364a;color:white">事故查询</router-link>
             </el-button>  
             <!-- <el-button @click="checkHomePage('/data')" style="background:#0a364a;color:white">
             <router-link to="/data" style="background:#0a364a;color:white">重大设备</router-link>
             </el-button>
             <el-button @click="checkHomePage('/data')" style="background:#0a364a;color:white">
             <router-link to="/data" style="background:#0a364a;color:white">瓦斯防治</router-link>
             </el-button>
             <el-button @click="checkHomePage('/data')" style="background:#0a364a;color:white">
             <router-link to="/data" style="background:#0a364a;color:white">火灾防治</router-link>
             </el-button>
              <el-button @click="checkHomePage('/data')" style="background:#0a364a;color:white">
             <router-link to="/data" style="background:#0a364a;color:white">冲击地压</router-link>
             </el-button> -->
 
    </div>
    </div>
  </el-container>
</template>

<script>
export default {
  data() {
    return {
       isHomePage: false ,// 默认不是首页,,
      iframe_src: "/HomePage",
      activeIndex: "/HomePage",
      url1: require("../../Map/img/轨迹.png"),
    };
  },
    mounted() {
    this.checkHomePage();
  },
  methods: {
    checkHomePage() {

      this.isHomePage = this.$route.path === '/xingcheng'; // 检查当前路由是否为首页
    },
    
       
    handleSelect(key, keyPath) {
    
      this.iframe_src = keyPath;
       this.isHomePage = keyPath[0] === '/xingcheng';
   
      
    },
    signout() {
      sessionStorage.setItem("username", "");
      sessionStorage.setItem("password", "");
      this.$router.push("/");
    },
  },



};

</script>

<style lang="less" scoped>
.user {
  float: right;
  margin-right: 20px;
  line-height: 60px;
   font-size: 15px;
  .user_name {

    top:7px;
    margin-right: 8px;
    font-size: 15px;


    border-radius: 25px;
    width: 50px;
    height:50px;
    display: inline-block;
    line-height: 30px;
    inline-size: fit-content;
  }
}
.title_i {
   position: absolute;
  left: 20%;
  top: 50%;
  font-size: 30px;
  transform: translate(-50%, -50%);
  color: rgb(255, 255, 255);
}
.title {
  position: absolute;
  top: 0%;

}
.screen-container {
  // position: absolute;
  width: 100%;
  height: 100%;

  background-color: #ffffff;
  color: rgb(0, 0, 0);
}
.el-header {
  padding-left: 0;
}
.el-menu-demo {
  padding-left: 35%;
}
#zi_daohan{
   top: 10%;
  left: 20%;
  bottom: 3%;
  position: absolute;
  float: left;
  font-size: 30px;
  width: 60%;

  height: 5%;
  text-align: center;
}
</style>